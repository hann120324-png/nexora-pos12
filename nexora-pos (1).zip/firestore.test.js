const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_uid_1";
const BOB_UID = "bob_uid_2";
const ADMIN_UID = "admin_uid_0";
const ADMIN_EMAIL = "hptra112@gmail.com";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

function pastDate(ms = 2000) {
  return new Date(Date.now() - ms);
}

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated access: only public app_settings/config get is allowed", async () => {
  await testEnv.withSecurityRulesDisabled(async (ctx) => {
    await ctx.firestore().collection("app_settings").doc("config").set({
      appName: "NEXORA POS",
      tagline: "Manage Smart. Sell Faster.",
      description: "POS Modern",
      premiumPrice: 30000,
      paymentInstructions: "Transfer BCA 123456",
      whatsappNumber: "6283854160449",
      supportContact: "cs@nexorapos.id",
      maintenanceMode: false,
      updatedAt: pastDate(),
    });
  });

  const unauth = testEnv.unauthenticatedContext().firestore();
  await assertSucceeds(unauth.collection("app_settings").doc("config").get());
  await assertFails(unauth.collection("app_settings").get());
  await assertFails(unauth.collection("users").doc(ALICE_UID).get());
  await assertFails(unauth.collection("products").get());
  await assertFails(unauth.collection("transactions").get());
});

test("User registration & privilege escalation prevention", async () => {
  const alice = testEnv.authenticatedContext(ALICE_UID, {
    email: "alice@example.com",
    email_verified: true,
  }).firestore();

  const ts = pastDate();
  // Cannot self-assign ADMIN or active premium
  await assertFails(
    alice.collection("users").doc(ALICE_UID).set({
      userId: ALICE_UID,
      name: "Alice",
      email: "alice@example.com",
      role: "ADMIN",
      accountStatus: "active",
      premiumStatus: "free",
      premiumType: "none",
      createdAt: ts,
      updatedAt: ts,
    })
  );
  await assertFails(
    alice.collection("users").doc(ALICE_UID).set({
      userId: ALICE_UID,
      name: "Alice",
      email: "alice@example.com",
      role: "USER",
      accountStatus: "active",
      premiumStatus: "active",
      premiumType: "lifetime",
      createdAt: ts,
      updatedAt: ts,
    })
  );

  // Valid free user creation succeeds
  await assertSucceeds(
    alice.collection("users").doc(ALICE_UID).set({
      userId: ALICE_UID,
      name: "Alice Store",
      email: "alice@example.com",
      role: "USER",
      accountStatus: "active",
      premiumStatus: "free",
      premiumType: "none",
      createdAt: ts,
      updatedAt: pastDate(1000),
    })
  );

  // Cannot escalate role or premiumStatus on update
  await assertFails(
    alice.collection("users").doc(ALICE_UID).update({
      premiumStatus: "active",
      premiumType: "lifetime",
      updatedAt: pastDate(500),
    })
  );
  await assertFails(
    alice.collection("users").doc(ALICE_UID).update({
      role: "ADMIN",
      updatedAt: pastDate(500),
    })
  );

  // Can update profile fields
  await assertSucceeds(
    alice.collection("users").doc(ALICE_UID).update({
      storeName: "Toko Alice",
      storePhone: "08123456789",
      updatedAt: pastDate(500),
    })
  );
});

test("Cross-user isolation on users, products, and queries", async () => {
  const ts = pastDate(5000);
  await testEnv.withSecurityRulesDisabled(async (ctx) => {
    const db = ctx.firestore();
    await db.collection("users").doc(BOB_UID).set({
      userId: BOB_UID,
      name: "Bob",
      email: "bob@example.com",
      role: "USER",
      accountStatus: "active",
      premiumStatus: "free",
      premiumType: "none",
      createdAt: ts,
      updatedAt: ts,
    });
    await db.collection("products").doc("bob_prod").set({
      userId: BOB_UID,
      name: "Kopi Susu",
      sku: "KS-01",
      category: "Minuman",
      costPrice: 8000,
      sellPrice: 15000,
      stock: 20,
      lowStockThreshold: 5,
      unit: "cup",
      createdAt: ts,
      updatedAt: ts,
    });
  });

  const alice = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertFails(alice.collection("users").doc(BOB_UID).get());
  await assertFails(alice.collection("users").get());
  await assertFails(alice.collection("products").doc("bob_prod").get());
  await assertFails(alice.collection("products").get());

  // Alice creates & queries own product
  await assertSucceeds(
    alice.collection("products").doc("alice_prod_1").set({
      userId: ALICE_UID,
      name: "Teh Tarik",
      sku: "TT-01",
      category: "Minuman",
      costPrice: 5000,
      sellPrice: 12000,
      stock: 50,
      lowStockThreshold: 5,
      unit: "cup",
      createdAt: ts,
      updatedAt: ts,
    })
  );
  await assertSucceeds(
    alice.collection("products").where("userId", "==", ALICE_UID).get()
  );
  // Reject extra @DocumentId 'id' field
  await assertFails(
    alice.collection("products").doc("alice_prod_2").set({
      id: "alice_prod_2",
      userId: ALICE_UID,
      name: "Matcha",
      sku: "MT-01",
      category: "Minuman",
      costPrice: 10000,
      sellPrice: 20000,
      stock: 10,
      lowStockThreshold: 2,
      unit: "cup",
      createdAt: ts,
      updatedAt: ts,
    })
  );
});

test("Free vs Premium gating for POS transactions and AI CS", async () => {
  const ts = pastDate(5000);
  await testEnv.withSecurityRulesDisabled(async (ctx) => {
    const db = ctx.firestore();
    await db.collection("users").doc(ALICE_UID).set({
      userId: ALICE_UID,
      name: "Alice Free",
      email: "alice@example.com",
      role: "USER",
      accountStatus: "active",
      premiumStatus: "free",
      premiumType: "none",
      createdAt: ts,
      updatedAt: ts,
    });
    await db.collection("users").doc(BOB_UID).set({
      userId: BOB_UID,
      name: "Bob Premium",
      email: "bob@example.com",
      role: "USER",
      accountStatus: "active",
      premiumStatus: "active",
      premiumType: "lifetime",
      createdAt: ts,
      updatedAt: ts,
    });
  });

  const alice = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bob = testEnv.authenticatedContext(BOB_UID).firestore();

  const txPayload = (uid) => ({
    userId: uid,
    cashierName: "Kasir 1",
    subtotal: 24000,
    discount: 0,
    tax: 0,
    total: 24000,
    totalProfit: 14000,
    paidAmount: 25000,
    changeAmount: 1000,
    paymentMethod: "CASH",
    paymentStatus: "PAID",
    itemsCount: 2,
    itemsSummary: "2x Teh Tarik",
    createdAt: pastDate(1000),
    updatedAt: pastDate(1000),
  });

  // Free user rejected
  await assertFails(alice.collection("transactions").doc("tx_1").set(txPayload(ALICE_UID)));
  await assertFails(
    alice.collection("ai_conversations").doc("conv_1").set({
      userId: ALICE_UID,
      title: "Bantuan",
      lastMessage: "Halo",
      createdAt: pastDate(1000),
      updatedAt: pastDate(1000),
    })
  );

  // Premium user allowed
  await assertSucceeds(bob.collection("transactions").doc("tx_2").set(txPayload(BOB_UID)));
  await assertSucceeds(
    bob.collection("ai_conversations").doc("conv_2").set({
      userId: BOB_UID,
      title: "Bantuan",
      lastMessage: "Halo",
      createdAt: pastDate(1000),
      updatedAt: pastDate(1000),
    })
  );
});

test("Email spoofing & Admin Premium approval workflow with idempotency", async () => {
  const ts = pastDate(5000);
  await testEnv.withSecurityRulesDisabled(async (ctx) => {
    const db = ctx.firestore();
    await db.collection("users").doc(ALICE_UID).set({
      userId: ALICE_UID,
      name: "Alice",
      email: "alice@example.com",
      role: "USER",
      accountStatus: "active",
      premiumStatus: "free",
      premiumType: "none",
      createdAt: ts,
      updatedAt: ts,
    });
  });

  const alice = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertSucceeds(
    alice.collection("premium_requests").doc("req_1").set({
      userId: ALICE_UID,
      userName: "Alice",
      userEmail: "alice@example.com",
      amount: 30000,
      paymentMethod: "Transfer Bank",
      status: "PENDING",
      createdAt: pastDate(2000),
      updatedAt: pastDate(2000),
    })
  );

  // Alice cannot approve own request
  await assertFails(
    alice.collection("premium_requests").doc("req_1").update({
      status: "APPROVED",
      updatedAt: pastDate(1000),
    })
  );

  // Unverified spoofed admin email cannot approve or list users
  const spoofedAdmin = testEnv.authenticatedContext("spoof_uid", {
    email: ADMIN_EMAIL,
    email_verified: false,
  }).firestore();
  await assertFails(spoofedAdmin.collection("users").get());
  await assertFails(
    spoofedAdmin.collection("premium_requests").doc("req_1").update({
      status: "APPROVED",
      reviewedBy: "spoof_uid",
      reviewedAt: pastDate(1000),
      updatedAt: pastDate(1000),
    })
  );

  // Verified bootstrap admin can approve once and activate user
  const admin = testEnv.authenticatedContext(ADMIN_UID, {
    email: ADMIN_EMAIL,
    email_verified: true,
  }).firestore();

  await assertSucceeds(admin.collection("users").get());
  await assertSucceeds(
    admin.collection("premium_requests").doc("req_1").update({
      status: "APPROVED",
      reviewedBy: ADMIN_UID,
      reviewedAt: pastDate(1000),
      updatedAt: pastDate(1000),
    })
  );
  // Terminal state lock: cannot re-approve or re-reject an already APPROVED request
  await assertFails(
    admin.collection("premium_requests").doc("req_1").update({
      status: "REJECTED",
      rejectionReason: "Double test",
      reviewedBy: ADMIN_UID,
      reviewedAt: pastDate(500),
      updatedAt: pastDate(500),
    })
  );
  await assertSucceeds(
    admin.collection("users").doc(ALICE_UID).update({
      premiumStatus: "active",
      premiumType: "lifetime",
      premiumActivatedAt: pastDate(1000),
      premiumExpiresAt: null,
      premiumRequestId: "req_1",
      updatedAt: pastDate(1000),
    })
  );
});

test("User Beli Premium Rp30.000 WriteBatch succeeds from free/rejected, blocks self-activation, and appears on Admin dashboard", async () => {
  const ts = pastDate(5000);
  await testEnv.withSecurityRulesDisabled(async (ctx) => {
    const db = ctx.firestore();
    await db.collection("users").doc(ALICE_UID).set({
      userId: ALICE_UID,
      name: "Alice Toko",
      email: "alice@example.com",
      role: "USER",
      accountStatus: "active",
      premiumStatus: "free",
      premiumType: "none",
      createdAt: ts,
      updatedAt: ts,
    });
  });

  const alice = testEnv.authenticatedContext(ALICE_UID, {
    email: "alice@example.com",
    email_verified: true,
  }).firestore();

  // Exact 3-write WriteBatch executed by SupportPremiumRepository.submitPremiumRequest
  const batchTs = pastDate(1000);
  const batch = alice.batch();
  const reqRef = alice.collection("premium_requests").doc("req_batch_30k");
  batch.set(reqRef, {
    userId: ALICE_UID,
    userName: "Alice Toko",
    userEmail: "alice@example.com",
    amount: 30000,
    paymentMethod: "Transfer Bank",
    note: "Transfer BCA a.n. Alice",
    status: "PENDING",
    createdAt: batchTs,
    updatedAt: batchTs,
  });
  batch.update(alice.collection("users").doc(ALICE_UID), {
    premiumStatus: "pending",
    premiumRequestId: "req_batch_30k",
    updatedAt: batchTs,
  });
  batch.set(alice.collection("notifications").doc("notif_batch_30k"), {
    userId: ALICE_UID,
    title: "Permintaan Premium Diterima",
    body: "Permintaan upgrade Premium Lifetime (req_batc) menunggu verifikasi Admin.",
    type: "PREMIUM_REQUESTED",
    read: false,
    referenceId: "req_batch_30k",
    createdAt: batchTs,
  });
  await assertSucceeds(batch.commit());

  // User still cannot self-activate premium or change premiumType
  await assertFails(
    alice.collection("users").doc(ALICE_UID).update({
      premiumStatus: "active",
      updatedAt: pastDate(500),
    })
  );
  await assertFails(
    alice.collection("users").doc(ALICE_UID).update({
      premiumType: "lifetime",
      updatedAt: pastDate(500),
    })
  );
  // User cannot create a request for another UID or with APPROVED status
  await assertFails(
    alice.collection("premium_requests").doc("req_for_bob").set({
      userId: BOB_UID,
      userName: "Alice Toko",
      userEmail: "alice@example.com",
      amount: 30000,
      paymentMethod: "Transfer Bank",
      status: "PENDING",
      createdAt: pastDate(500),
      updatedAt: pastDate(500),
    })
  );
  await assertFails(
    alice.collection("premium_requests").doc("req_auto_approved").set({
      userId: ALICE_UID,
      userName: "Alice Toko",
      userEmail: "alice@example.com",
      amount: 30000,
      paymentMethod: "Transfer Bank",
      status: "APPROVED",
      createdAt: pastDate(500),
      updatedAt: pastDate(500),
    })
  );

  // User sees own request, Admin sees it in Admin dashboard (observeAllPremiumRequestsAdmin)
  const userList = await assertSucceeds(
    alice.collection("premium_requests").where("userId", "==", ALICE_UID).get()
  );
  if (userList.size !== 1) {
    throw new Error(`Expected 1 user premium request, got ${userList.size}`);
  }

  const admin = testEnv.authenticatedContext(ADMIN_UID, {
    email: ADMIN_EMAIL,
    email_verified: true,
  }).firestore();
  const adminList = await assertSucceeds(admin.collection("premium_requests").get());
  const found = adminList.docs.find((d) => d.id === "req_batch_30k");
  if (!found || found.data().status !== "PENDING" || found.data().amount !== 30000) {
    throw new Error("Admin dashboard query did not find pending Rp30.000 request");
  }
});

