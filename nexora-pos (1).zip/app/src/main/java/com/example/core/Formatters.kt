package com.example.core

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import android.util.Base64
import com.example.model.PosTransaction
import com.example.model.TransactionItem
import com.example.model.UserProfile
import com.google.firebase.Timestamp
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import java.io.ByteArrayOutputStream
import java.io.FileOutputStream
import java.net.URLEncoder
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object RupiahFormatter {
    private val indonesiaLocale = Locale("in", "ID")
    private val currencyFormat: NumberFormat = NumberFormat.getCurrencyInstance(indonesiaLocale).apply {
        maximumFractionDigits = 0
        minimumFractionDigits = 0
    }

    fun format(amount: Double): String {
        val raw = currencyFormat.format(amount)
        return raw.replace("Rp ", "Rp").replace(",00", "")
    }

    fun format(amount: Long): String = format(amount.toDouble())
}

object DateFormatter {
    private val fullFormat = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale("in", "ID"))
    private val shortDate = SimpleDateFormat("dd/MM/yy", Locale("in", "ID"))

    fun format(timestamp: Timestamp?): String {
        val date = timestamp?.toDate() ?: Date()
        return fullFormat.format(date)
    }

    fun formatShort(timestamp: Timestamp?): String {
        val date = timestamp?.toDate() ?: Date()
        return shortDate.format(date)
    }
}

object WhatsAppHelper {
    const val DEFAULT_WHATSAPP_NUMBER = "6283854160449"

    fun openComplaint(
        context: Context,
        whatsappNumber: String = DEFAULT_WHATSAPP_NUMBER,
        name: String,
        email: String,
        uid: String,
        transactionId: String = "-",
        detail: String = ""
    ) {
        val message = """
            Halo Admin NEXORA POS.
            Saya ingin menyampaikan komplain.
            Nama: $name
            Email: $email
            UID: $uid
            ID Transaksi: $transactionId
            Detail Komplain: $detail
            Mohon bantuannya.
        """.trimIndent()
        launchWhatsApp(context, whatsappNumber, message)
    }

    fun openCs(
        context: Context,
        whatsappNumber: String = DEFAULT_WHATSAPP_NUMBER,
        name: String,
        email: String,
        accountStatus: String,
        issue: String = ""
    ) {
        val message = """
            Halo CS NEXORA POS.
            Saya membutuhkan bantuan.
            Nama: $name
            Email: $email
            Status Akun: $accountStatus
            Kendala: $issue
            Terima kasih.
        """.trimIndent()
        launchWhatsApp(context, whatsappNumber, message)
    }

    private fun launchWhatsApp(context: Context, rawPhone: String, message: String) {
        val cleanPhone = rawPhone.filter { it.isDigit() }.let {
            if (it.startsWith("0")) "62${it.drop(1)}" else it.ifBlank { DEFAULT_WHATSAPP_NUMBER }
        }
        val encoded = URLEncoder.encode(message, "UTF-8").replace("+", "%20")
        val uri = Uri.parse("https://wa.me/$cleanPhone?text=$encoded")
        val intent = Intent(Intent.ACTION_VIEW, uri).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            context.startActivity(intent)
        } catch (_: Exception) {
            // Browser / WhatsApp unavailable gracefully
        }
    }
}

object ImageEncodingHelper {
    fun uriToCompressedDataUri(context: Context, uri: Uri, maxDim: Int = 512, maxChars: Int = 180_000): String? {
        return try {
            val input = context.contentResolver.openInputStream(uri) ?: return null
            val original = input.use { BitmapFactory.decodeStream(it) } ?: return null
            val scale = minOf(1f, maxDim.toFloat() / maxOf(original.width, original.height).toFloat())
            val w = (original.width * scale).toInt().coerceAtLeast(1)
            val h = (original.height * scale).toInt().coerceAtLeast(1)
            val resized = if (scale < 1f) Bitmap.createScaledBitmap(original, w, h, true) else original

            var quality = 80
            var encoded: String
            do {
                val out = ByteArrayOutputStream()
                resized.compress(Bitmap.CompressFormat.JPEG, quality, out)
                val bytes = out.toByteArray()
                encoded = "data:image/jpeg;base64," + Base64.encodeToString(bytes, Base64.NO_WRAP)
                quality -= 15
            } while (encoded.length > maxChars && quality >= 20)

            if (encoded.length > maxChars) null else encoded
        } catch (_: Exception) {
            null
        }
    }

    fun decodeBase64DataUri(dataUri: String?): Bitmap? {
        if (dataUri.isNullOrBlank() || !dataUri.startsWith("data:image")) return null
        return try {
            val base64Part = dataUri.substringAfter("base64,", "")
            if (base64Part.isBlank()) return null
            val bytes = Base64.decode(base64Part, Base64.DEFAULT)
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
        } catch (_: Exception) {
            null
        }
    }
}

object QrCodeHelper {
    fun generateQrBitmap(content: String, sizePx: Int = 512): Bitmap? {
        if (content.isBlank()) return null
        return try {
            val hints = mapOf(
                EncodeHintType.MARGIN to 1,
                EncodeHintType.CHARACTER_SET to "UTF-8"
            )
            val bitMatrix = QRCodeWriter().encode(content, BarcodeFormat.QR_CODE, sizePx, sizePx, hints)
            val bmp = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
            for (x in 0 until sizePx) {
                for (y in 0 until sizePx) {
                    bmp.setPixel(x, y, if (bitMatrix.get(x, y)) Color.BLACK else Color.WHITE)
                }
            }
            bmp
        } catch (_: Exception) {
            null
        }
    }

    fun saveBitmapPngToUri(context: Context, uri: Uri, bitmap: Bitmap): Boolean {
        return try {
            context.contentResolver.openOutputStream(uri)?.use { out ->
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
            } ?: false
        } catch (_: Exception) {
            false
        }
    }

    fun printQrBitmap(context: Context, title: String, subtitle: String, bitmap: Bitmap) {
        val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager ?: return
        val adapter = object : PrintDocumentAdapter() {
            override fun onLayout(
                oldAttributes: PrintAttributes?,
                newAttributes: PrintAttributes,
                cancellationSignal: CancellationSignal?,
                callback: LayoutResultCallback,
                extras: Bundle?
            ) {
                if (cancellationSignal?.isCanceled == true) {
                    callback.onLayoutCancelled()
                    return
                }
                val info = PrintDocumentInfo.Builder("QR_$title.pdf")
                    .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                    .setPageCount(1)
                    .build()
                callback.onLayoutFinished(info, true)
            }

            override fun onWrite(
                pages: Array<out PageRange>?,
                destination: ParcelFileDescriptor,
                cancellationSignal: CancellationSignal?,
                callback: WriteResultCallback
            ) {
                val doc = PdfDocument()
                val pageInfo = PdfDocument.PageInfo.Builder(300, 380, 1).create()
                val page = doc.startPage(pageInfo)
                val canvas = page.canvas
                canvas.drawColor(Color.WHITE)

                val titlePaint = Paint().apply {
                    color = Color.BLACK
                    textSize = 14f
                    typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                    textAlign = Paint.Align.CENTER
                }
                val subPaint = Paint().apply {
                    color = Color.DKGRAY
                    textSize = 10f
                    textAlign = Paint.Align.CENTER
                }

                canvas.drawText(title.take(28), 150f, 34f, titlePaint)
                val scaled = Bitmap.createScaledBitmap(bitmap, 220, 220, false)
                canvas.drawBitmap(scaled, 40f, 52f, null)
                canvas.drawText(subtitle.take(36), 150f, 300f, subPaint)
                canvas.drawText("NEXORA POS", 150f, 326f, subPaint)

                doc.finishPage(page)
                try {
                    FileOutputStream(destination.fileDescriptor).use { out -> doc.writeTo(out) }
                    callback.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
                } catch (e: Exception) {
                    callback.onWriteFailed(e.message)
                } finally {
                    doc.close()
                }
            }
        }
        printManager.print("QR_$title", adapter, PrintAttributes.Builder().build())
    }
}

object ReceiptPrintHelper {
    enum class PaperWidth(val widthPoints: Int, val label: String) {
        MM_58(164, "58mm"),
        MM_80(226, "80mm")
    }

    fun buildReceiptLines(
        user: UserProfile,
        tx: PosTransaction,
        items: List<TransactionItem>
    ): List<String> {
        val storeName = user.storeName.ifBlank { "NEXORA POS" }
        val lines = mutableListOf<String>()
        lines += storeName.uppercase(Locale("in", "ID"))
        if (user.storeAddress.isNotBlank()) lines += user.storeAddress
        if (user.storePhone.isNotBlank()) lines += "Telp: ${user.storePhone}"
        lines += "--------------------------------"
        lines += "ID: ${tx.id.take(16)}"
        lines += "Tgl: ${DateFormatter.format(tx.createdAt)}"
        lines += "Kasir: ${tx.cashierName}"
        lines += "--------------------------------"
        if (items.isNotEmpty()) {
            items.forEach { item ->
                lines += item.productName
                lines += "  ${item.quantity} x ${RupiahFormatter.format(item.unitPrice)} = ${RupiahFormatter.format(item.lineTotal)}"
            }
        } else {
            lines += tx.itemsSummary
        }
        lines += "--------------------------------"
        lines += "Subtotal : ${RupiahFormatter.format(tx.subtotal)}"
        if (tx.discount > 0) lines += "Diskon   : -${RupiahFormatter.format(tx.discount)}"
        if (tx.tax > 0) lines += "Pajak    : ${RupiahFormatter.format(tx.tax)}"
        lines += "TOTAL    : ${RupiahFormatter.format(tx.total)}"
        lines += "Bayar (${tx.paymentMethod}): ${RupiahFormatter.format(tx.paidAmount)}"
        lines += "Kembali  : ${RupiahFormatter.format(tx.changeAmount)}"
        lines += "Status   : ${tx.paymentStatus}"
        lines += "--------------------------------"
        lines += "Terima kasih telah berbelanja!"
        lines += "NEXORA POS — Manage Smart. Sell Faster."
        return lines
    }

    fun createReceiptPdfDocument(
        lines: List<String>,
        paperWidth: PaperWidth
    ): PdfDocument {
        val doc = PdfDocument()
        val lineHeight = 14f
        val pageWidth = paperWidth.widthPoints
        val pageHeight = (60 + lines.size * lineHeight.toInt()).coerceAtLeast(240)
        val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
        val page = doc.startPage(pageInfo)
        val canvas: Canvas = page.canvas
        canvas.drawColor(Color.WHITE)

        val paint = Paint().apply {
            color = Color.BLACK
            textSize = if (paperWidth == PaperWidth.MM_58) 7.5f else 9f
            typeface = Typeface.MONOSPACE
        }
        var y = 24f
        lines.forEach { line ->
            canvas.drawText(line, 10f, y, paint)
            y += lineHeight
        }
        doc.finishPage(page)
        return doc
    }

    fun exportReceiptPdfToUri(
        context: Context,
        uri: Uri,
        lines: List<String>,
        paperWidth: PaperWidth
    ): Boolean {
        val doc = createReceiptPdfDocument(lines, paperWidth)
        return try {
            context.contentResolver.openOutputStream(uri)?.use { out ->
                doc.writeTo(out)
            }
            true
        } catch (_: Exception) {
            false
        } finally {
            doc.close()
        }
    }

    fun printReceipt(
        context: Context,
        txId: String,
        lines: List<String>,
        paperWidth: PaperWidth
    ) {
        val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager ?: return
        val adapter = object : PrintDocumentAdapter() {
            override fun onLayout(
                oldAttributes: PrintAttributes?,
                newAttributes: PrintAttributes,
                cancellationSignal: CancellationSignal?,
                callback: LayoutResultCallback,
                extras: Bundle?
            ) {
                if (cancellationSignal?.isCanceled == true) {
                    callback.onLayoutCancelled()
                    return
                }
                val info = PrintDocumentInfo.Builder("Struk_$txId.pdf")
                    .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                    .setPageCount(1)
                    .build()
                callback.onLayoutFinished(info, true)
            }

            override fun onWrite(
                pages: Array<out PageRange>?,
                destination: ParcelFileDescriptor,
                cancellationSignal: CancellationSignal?,
                callback: WriteResultCallback
            ) {
                val doc = createReceiptPdfDocument(lines, paperWidth)
                try {
                    FileOutputStream(destination.fileDescriptor).use { out -> doc.writeTo(out) }
                    callback.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
                } catch (e: Exception) {
                    callback.onWriteFailed(e.message)
                } finally {
                    doc.close()
                }
            }
        }
        printManager.print("Struk_NEXORA_$txId", adapter, PrintAttributes.Builder().build())
    }
}
