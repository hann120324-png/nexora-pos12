package com.example.core

import android.content.Context
import com.example.R
import com.google.firebase.firestore.FirebaseFirestore

fun getNexoraFirestore(context: Context): FirebaseFirestore {
    val dbId = context.applicationContext.getString(R.string.firestore_database_id).trim()
    return if (dbId.isEmpty() || dbId == "(default)") {
        FirebaseFirestore.getInstance()
    } else {
        FirebaseFirestore.getInstance(dbId)
    }
}
