package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.annotation.DrawableRes
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.core.DateFormatter
import com.example.core.RupiahFormatter
import com.example.model.ApiSettings
import com.example.model.AppSettings
import com.example.model.AuditLog
import com.example.model.Complaint
import com.example.model.PosTransaction
import com.example.model.PremiumHistory
import com.example.model.PremiumRequest
import com.example.model.Product
import com.example.model.UserProfile
import com.example.ui.components.BrutalBadge
import com.example.ui.components.BrutalButton
import com.example.ui.components.BrutalCard
import com.example.ui.components.BrutalDangerButton
import com.example.ui.components.BrutalIconButton
import com.example.ui.components.BrutalOutlinedButton
import com.example.ui.components.BrutalStatCard
import com.example.ui.components.BrutalTextField
import com.example.ui.components.Lucide
import com.example.ui.components.LucideIcon
import com.example.ui.components.StatusBadge
import com.example.ui.components.StoredImage
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.BrutalBlack
import com.example.ui.theme.CrimsonError
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.PrimaryYellow
import com.example.ui.theme.brutalAccentText

enum class AdminTab(val label: String, @DrawableRes val icon: Int) {
    OVERVIEW("Dashboard", Lucide.LayoutDashboard),
    USERS("Users", Lucide.UserRound),
    PREMIUM("Premium", Lucide.Crown),
    PRODUCTS("Produk", Lucide.Package),
    TRANSACTIONS("Transaksi", Lucide.Receipt),
    COMPLAINTS("Komplain", Lucide.MessageSquareWarning),
    API_SETTINGS("API Settings", Lucide.Wrench),
    APP_SETTINGS("App Settings", Lucide.Settings),
    AUDIT_LOGS("Audit Log", Lucide.History)
}

@Composable
fun AdminDashboardScreen(
    adminUser: UserProfile,
    allUsers: List<UserProfile>,
    allRequests: List<PremiumRequest>,
    premiumHistory: List<PremiumHistory>,
    allProducts: List<Product>,
    allTransactions: List<PosTransaction>,
    allComplaints: List<Complaint>,
    auditLogs: List<AuditLog>,
    appSettings: AppSettings,
    apiSettings: ApiSettings,
    isBusy: Boolean,
    onBackToUserMode: () -> Unit,
    onApprovePremium: (PremiumRequest) -> Unit,
    onRejectPremium: (PremiumRequest, String) -> Unit,
    onUpdateUserStatus: (uid: String, role: String, accountStatus: String, premiumStatus: String, premiumType: String) -> Unit,
    onReplyComplaint: (Complaint, String, String, String?) -> Unit,
    onSaveAppSettings: (AppSettings) -> Unit,
    onSaveApiSettings: (ApiSettings) -> Unit,
    onBroadcastAnnouncement: (String, String) -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onBackToUserMode() }

    var activeTab by remember { mutableStateOf(AdminTab.OVERVIEW) }
    var userSearch by remember { mutableStateOf("") }
    var rejectTarget by remember { mutableStateOf<PremiumRequest?>(null) }
    var rejectReason by remember { mutableStateOf("") }
    var complaintTarget by remember { mutableStateOf<Complaint?>(null) }
    var complaintReply by remember { mutableStateOf("") }
    var complaintNewStatus by remember { mutableStateOf("RESOLVED") }

    val freeUsersCount = allUsers.count { !it.isPremiumActive }
    val premiumUsersCount = allUsers.count { it.isPremiumActive }
    val totalSales = allTransactions.sumOf { it.total }
    val totalPremiumRevenue = premiumHistory.filter { it.action == "APPROVED" }.sumOf { it.amount }
    val pendingComplaints = allComplaints.count { it.status == "PENDING" }
    val pendingPremiums = allRequests.count { it.status == "PENDING" }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .widthIn(max = 1000.dp),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    BrutalIconButton(
                        icon = Lucide.ArrowLeft,
                        contentDescription = "Mode User",
                        onClick = onBackToUserMode
                    )
                    LucideIcon(Lucide.ShieldCheck, contentDescription = null, tint = MaterialTheme.colorScheme.brutalAccentText, modifier = Modifier.size(22.dp))
                    Text("Admin Panel", style = MaterialTheme.typography.headlineMedium)
                }
                BrutalBadge("OWNER", icon = Lucide.ShieldCheck)
            }
        }

        // Dedicated Admin Navigation Tabs
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                AdminTab.entries.forEach { tab ->
                    FilterChip(
                        selected = activeTab == tab,
                        onClick = { activeTab = tab },
                        shape = MaterialTheme.shapes.small,
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = PrimaryYellow,
                            selectedLabelColor = BrutalBlack,
                            selectedLeadingIconColor = BrutalBlack
                        ),
                        leadingIcon = {
                            LucideIcon(tab.icon, contentDescription = null, modifier = Modifier.size(16.dp))
                        },
                        label = { Text(tab.label) }
                    )
                }
            }
        }

        when (activeTab) {
            AdminTab.OVERVIEW -> {
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            BrutalStatCard(
                                title = "Total Pengguna",
                                value = "${allUsers.size}",
                                icon = Lucide.UserRound,
                                accentColor = PrimaryYellow,
                                subtitle = "Free: $freeUsersCount | Prem: $premiumUsersCount",
                                modifier = Modifier.weight(1f)
                            )
                            BrutalStatCard(
                                title = "Total Transaksi",
                                value = "${allTransactions.size}",
                                icon = Lucide.Receipt,
                                modifier = Modifier.weight(1f)
                            )
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            BrutalStatCard(
                                title = "Penjualan User",
                                value = RupiahFormatter.format(totalSales),
                                icon = Lucide.Banknote,
                                accentColor = EmeraldSuccess,
                                modifier = Modifier.weight(1f)
                            )
                            BrutalStatCard(
                                title = "Omzet Premium",
                                value = RupiahFormatter.format(totalPremiumRevenue),
                                icon = Lucide.Crown,
                                accentColor = PrimaryYellow,
                                modifier = Modifier.weight(1f)
                            )
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            BrutalStatCard(
                                title = "Premium Pending",
                                value = "$pendingPremiums",
                                icon = Lucide.Clock,
                                accentColor = AmberWarning,
                                onClick = { activeTab = AdminTab.PREMIUM },
                                modifier = Modifier.weight(1f)
                            )
                            BrutalStatCard(
                                title = "Komplain Pending",
                                value = "$pendingComplaints",
                                icon = Lucide.MessageSquareWarning,
                                accentColor = CrimsonError,
                                onClick = { activeTab = AdminTab.COMPLAINTS },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            AdminTab.USERS -> {
                item {
                    BrutalTextField(
                        value = userSearch,
                        onValueChange = { userSearch = it },
                        label = "Cari nama, email, atau UID user...",
                        leadingIcon = Lucide.Search
                    )
                }
                val filteredUsers = allUsers.filter { u ->
                    val q = userSearch.trim().lowercase()
                    q.isEmpty() || u.name.lowercase().contains(q) || u.email.lowercase().contains(q) || u.userId.lowercase().contains(q)
                }
                items(filteredUsers, key = { it.userId }) { u ->
                    BrutalCard {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(u.name, style = MaterialTheme.typography.titleMedium)
                                    Text(u.email, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text("UID: ${u.userId}", style = MaterialTheme.typography.labelSmall)
                                }
                                Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    StatusBadge(u.accountStatus)
                                    StatusBadge(u.premiumStatus)
                                }
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                if (!u.isPremiumActive) {
                                    BrutalButton(
                                        text = "Aktifkan Premium",
                                        icon = Lucide.Crown,
                                        enabled = !isBusy,
                                        onClick = { onUpdateUserStatus(u.userId, u.role, u.accountStatus, "active", "lifetime") },
                                        modifier = Modifier.weight(1f)
                                    )
                                } else if (!u.isAdminRole) {
                                    BrutalOutlinedButton(
                                        text = "Cabut Premium",
                                        enabled = !isBusy,
                                        onClick = { onUpdateUserStatus(u.userId, u.role, u.accountStatus, "free", "none") },
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                                if (u.userId != adminUser.userId) {
                                    val nextAcc = if (u.isDisabledAccount) "active" else "disabled"
                                    if (u.isDisabledAccount) {
                                        BrutalOutlinedButton(
                                            text = "Aktifkan Akun",
                                            borderColor = EmeraldSuccess,
                                            contentColor = EmeraldSuccess,
                                            enabled = !isBusy,
                                            onClick = { onUpdateUserStatus(u.userId, u.role, nextAcc, u.premiumStatus, u.premiumType) },
                                            modifier = Modifier.weight(1f)
                                        )
                                    } else {
                                        BrutalDangerButton(
                                            text = "Nonaktifkan",
                                            enabled = !isBusy,
                                            onClick = { onUpdateUserStatus(u.userId, u.role, nextAcc, u.premiumStatus, u.premiumType) },
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            AdminTab.PREMIUM -> {
                items(allRequests, key = { it.id }) { req ->
                    BrutalCard(borderColor = if (req.status == "PENDING") AmberWarning else MaterialTheme.colorScheme.outlineVariant) {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("${req.userName} (${req.userEmail})", style = MaterialTheme.typography.titleMedium)
                                    Text("${req.paymentMethod} | ${RupiahFormatter.format(req.amount)}", style = MaterialTheme.typography.bodyMedium)
                                    Text(DateFormatter.format(req.createdAt), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                StatusBadge(req.status)
                            }
                            if (req.note.isNotBlank()) {
                                Text("Catatan: ${req.note}", style = MaterialTheme.typography.bodyMedium)
                            }
                            if (req.proofUrl.isNotBlank()) {
                                StoredImage(
                                    imageSource = req.proofUrl,
                                    contentDescription = "Bukti Bayar",
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(160.dp)
                                        .clip(MaterialTheme.shapes.small)
                                )
                            }
                            if (req.status == "PENDING") {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    BrutalButton(
                                        text = "Setujui",
                                        icon = Lucide.CircleCheck,
                                        containerColor = EmeraldSuccess,
                                        enabled = !isBusy,
                                        onClick = { onApprovePremium(req) },
                                        modifier = Modifier.weight(1f),
                                        testTag = "admin_approve_${req.id}"
                                    )
                                    BrutalDangerButton(
                                        text = "Tolak",
                                        icon = Lucide.CircleX,
                                        enabled = !isBusy,
                                        onClick = {
                                            rejectTarget = req
                                            rejectReason = ""
                                        },
                                        modifier = Modifier.weight(1f),
                                        testTag = "admin_reject_${req.id}"
                                    )
                                }
                            } else if (req.rejectionReason.isNotBlank()) {
                                Text("Alasan penolakan: ${req.rejectionReason}", style = MaterialTheme.typography.bodyMedium, color = CrimsonError)
                            }
                        }
                    }
                }
            }

            AdminTab.PRODUCTS -> {
                items(allProducts, key = { it.id }) { prod ->
                    BrutalCard {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(prod.name, style = MaterialTheme.typography.titleMedium)
                                Text("SKU: ${prod.sku} | Owner: ${prod.userId.take(8)}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(RupiahFormatter.format(prod.sellPrice), style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.brutalAccentText)
                                Text("Stok: ${prod.stock}", style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
            }

            AdminTab.TRANSACTIONS -> {
                items(allTransactions, key = { it.id }) { tx ->
                    BrutalCard {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("#${tx.id.take(10)} - ${tx.cashierName}", style = MaterialTheme.typography.titleMedium)
                                Text(tx.itemsSummary, style = MaterialTheme.typography.bodyMedium, maxLines = 1)
                                Text("${tx.paymentMethod} | ${DateFormatter.format(tx.createdAt)}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(RupiahFormatter.format(tx.total), style = MaterialTheme.typography.titleMedium)
                                StatusBadge(tx.paymentStatus)
                            }
                        }
                    }
                }
            }

            AdminTab.COMPLAINTS -> {
                items(allComplaints, key = { it.id }) { comp ->
                    BrutalCard {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(comp.title, style = MaterialTheme.typography.titleMedium)
                                    Text("${comp.userName} (${comp.category})", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                StatusBadge(comp.status)
                            }
                            Text(comp.detail, style = MaterialTheme.typography.bodyMedium)
                            if (comp.attachmentUrl.isNotBlank()) {
                                StoredImage(
                                    imageSource = comp.attachmentUrl,
                                    contentDescription = "Lampiran",
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(140.dp)
                                        .clip(MaterialTheme.shapes.small)
                                )
                            }
                            BrutalButton(
                                text = "Balas & Ubah Status",
                                icon = Lucide.Send,
                                onClick = {
                                    complaintTarget = comp
                                    complaintReply = ""
                                    complaintNewStatus = if (comp.status == "PENDING") "IN_PROGRESS" else "RESOLVED"
                                },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
            }

            AdminTab.API_SETTINGS -> {
                item {
                    AdminApiSettingsCard(
                        apiSettings = apiSettings,
                        isBusy = isBusy,
                        onSave = onSaveApiSettings
                    )
                }
            }

            AdminTab.APP_SETTINGS -> {
                item {
                    AdminAppSettingsCard(
                        appSettings = appSettings,
                        isBusy = isBusy,
                        onSave = onSaveAppSettings,
                        onBroadcast = onBroadcastAnnouncement
                    )
                }
            }

            AdminTab.AUDIT_LOGS -> {
                items(auditLogs, key = { it.id }) { log ->
                    BrutalCard {
                        Text("${log.action} - ${log.actorEmail}", style = MaterialTheme.typography.titleMedium)
                        Text("Target: ${log.targetId} — ${log.detail}", style = MaterialTheme.typography.bodyMedium)
                        Text(DateFormatter.format(log.createdAt), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
        item { Spacer(Modifier.height(64.dp)) }
    }

    if (rejectTarget != null) {
        AlertDialog(
            shape = MaterialTheme.shapes.medium,
            onDismissRequest = { rejectTarget = null },
            title = { Text("Tolak Permintaan Premium") },
            text = {
                BrutalTextField(
                    value = rejectReason,
                    onValueChange = { rejectReason = it },
                    label = "Alasan Penolakan (Wajib)",
                    singleLine = false
                )
            },
            confirmButton = {
                BrutalDangerButton(
                    text = "Tolak Permintaan",
                    enabled = rejectReason.isNotBlank(),
                    onClick = {
                        val target = rejectTarget!!
                        rejectTarget = null
                        onRejectPremium(target, rejectReason)
                    }
                )
            },
            dismissButton = {
                BrutalOutlinedButton(text = "Batal", onClick = { rejectTarget = null })
            }
        )
    }

    if (complaintTarget != null) {
        AlertDialog(
            shape = MaterialTheme.shapes.medium,
            onDismissRequest = { complaintTarget = null },
            title = { Text("Tanggapi Komplain") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf("IN_PROGRESS", "RESOLVED", "REJECTED").forEach { st ->
                            FilterChip(
                                selected = complaintNewStatus == st,
                                onClick = { complaintNewStatus = st },
                                shape = MaterialTheme.shapes.small,
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = PrimaryYellow,
                                    selectedLabelColor = BrutalBlack
                                ),
                                label = { Text(st) }
                            )
                        }
                    }
                    BrutalTextField(
                        value = complaintReply,
                        onValueChange = { complaintReply = it },
                        label = "Balasan Admin *",
                        singleLine = false
                    )
                }
            },
            confirmButton = {
                BrutalButton(
                    text = "Kirim Tanggapan",
                    icon = Lucide.Send,
                    enabled = complaintReply.isNotBlank(),
                    onClick = {
                        val target = complaintTarget!!
                        complaintTarget = null
                        onReplyComplaint(
                            target,
                            complaintReply,
                            complaintNewStatus,
                            if (complaintNewStatus == "REJECTED") complaintReply else null
                        )
                    }
                )
            },
            dismissButton = {
                BrutalOutlinedButton(text = "Batal", onClick = { complaintTarget = null })
            }
        )
    }
}

@Composable
private fun AdminApiSettingsCard(
    apiSettings: ApiSettings,
    isBusy: Boolean,
    onSave: (ApiSettings) -> Unit
) {
    var nexaSendConfigured by remember(apiSettings) { mutableStateOf(apiSettings.nexaSendConfigured) }
    var nexaSendEndpoint by remember(apiSettings) { mutableStateOf(apiSettings.nexaSendEndpoint) }
    var reactionConfigured by remember(apiSettings) { mutableStateOf(apiSettings.reactionConfigured) }
    var reactionEndpoint by remember(apiSettings) { mutableStateOf(apiSettings.reactionEndpoint) }
    var voteConfigured by remember(apiSettings) { mutableStateOf(apiSettings.voteConfigured) }
    var voteEndpoint by remember(apiSettings) { mutableStateOf(apiSettings.voteEndpoint) }
    var qrisConfigured by remember(apiSettings) { mutableStateOf(apiSettings.qrisConfigured) }
    var qrisProvider by remember(apiSettings) { mutableStateOf(apiSettings.qrisProviderName) }
    var aiCsConfigured by remember(apiSettings) { mutableStateOf(apiSettings.aiCsConfigured) }
    var aiModel by remember(apiSettings) { mutableStateOf(apiSettings.aiModelName) }
    var aiPrompt by remember(apiSettings) { mutableStateOf(apiSettings.aiSystemPrompt) }

    BrutalCard {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Manajemen Konfigurasi API (Non-Secret)", style = MaterialTheme.typography.titleLarge)
            Text(
                "Kunci rahasia (API Key & Secret Payment Gateway) disimpan di Firebase Functions Secrets / backend proxy dan tidak pernah disimpan di Firestore.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            SwitchRow("Aktifkan Generation AM Proxy", nexaSendConfigured) { nexaSendConfigured = it }
            BrutalTextField(value = nexaSendEndpoint, onValueChange = { nexaSendEndpoint = it }, label = "Endpoint Generation AM")
            SwitchRow("Aktifkan Reaction Channel", reactionConfigured) { reactionConfigured = it }
            BrutalTextField(value = reactionEndpoint, onValueChange = { reactionEndpoint = it }, label = "Endpoint Reaction Channel")
            SwitchRow("Aktifkan Vote Channel", voteConfigured) { voteConfigured = it }
            BrutalTextField(value = voteEndpoint, onValueChange = { voteEndpoint = it }, label = "Endpoint Vote Channel")
            SwitchRow("Aktifkan Payment Gateway QRIS", qrisConfigured) { qrisConfigured = it }
            BrutalTextField(value = qrisProvider, onValueChange = { qrisProvider = it }, label = "Nama Provider QRIS")
            SwitchRow("Aktifkan AI Customer Service", aiCsConfigured) { aiCsConfigured = it }
            BrutalTextField(value = aiModel, onValueChange = { aiModel = it }, label = "Label Model AI CS (Backend: NexaDev GPT-4)")
            BrutalTextField(value = aiPrompt, onValueChange = { aiPrompt = it }, label = "System Prompt AI CS", singleLine = false)

            BrutalButton(
                text = if (isBusy) "Menyimpan..." else "Simpan Konfigurasi API",
                enabled = !isBusy,
                onClick = {
                    onSave(
                        apiSettings.copy(
                            nexaSendConfigured = nexaSendConfigured,
                            nexaSendEndpoint = nexaSendEndpoint,
                            reactionConfigured = reactionConfigured,
                            reactionEndpoint = reactionEndpoint,
                            voteConfigured = voteConfigured,
                            voteEndpoint = voteEndpoint,
                            qrisConfigured = qrisConfigured,
                            qrisProviderName = qrisProvider,
                            aiCsConfigured = aiCsConfigured,
                            aiModelName = aiModel,
                            aiSystemPrompt = aiPrompt
                        )
                    )
                },
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
private fun AdminAppSettingsCard(
    appSettings: AppSettings,
    isBusy: Boolean,
    onSave: (AppSettings) -> Unit,
    onBroadcast: (String, String) -> Unit
) {
    var appName by remember(appSettings) { mutableStateOf(appSettings.appName) }
    var tagline by remember(appSettings) { mutableStateOf(appSettings.tagline) }
    var price by remember(appSettings) { mutableStateOf(appSettings.premiumPrice.toLong().toString()) }
    var instructions by remember(appSettings) { mutableStateOf(appSettings.paymentInstructions) }
    var waNumber by remember(appSettings) { mutableStateOf(appSettings.whatsappNumber) }
    var announcement by remember(appSettings) { mutableStateOf(appSettings.announcement) }
    var maintenance by remember(appSettings) { mutableStateOf(appSettings.maintenanceMode) }
    var broadcastTitle by remember { mutableStateOf("") }
    var broadcastBody by remember { mutableStateOf("") }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        BrutalCard {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Pengaturan Aplikasi", style = MaterialTheme.typography.titleLarge)
                BrutalTextField(value = appName, onValueChange = { appName = it }, label = "Nama Aplikasi")
                BrutalTextField(value = tagline, onValueChange = { tagline = it }, label = "Tagline")
                BrutalTextField(
                    value = price,
                    onValueChange = { price = it.filter { c -> c.isDigit() } },
                    label = "Harga Premium Lifetime (Rp)",
                    leadingIcon = Lucide.Banknote,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
                BrutalTextField(value = instructions, onValueChange = { instructions = it }, label = "Instruksi Pembayaran", singleLine = false)
                BrutalTextField(value = waNumber, onValueChange = { waNumber = it }, label = "Nomor WhatsApp Admin (62...)")
                BrutalTextField(value = announcement, onValueChange = { announcement = it }, label = "Banner Pengumuman", singleLine = false)
                SwitchRow("Mode Pemeliharaan (Maintenance)", maintenance) { maintenance = it }

                BrutalButton(
                    text = if (isBusy) "Menyimpan..." else "Simpan Pengaturan Aplikasi",
                    enabled = !isBusy,
                    onClick = {
                        onSave(
                            appSettings.copy(
                                appName = appName,
                                tagline = tagline,
                                premiumPrice = price.toDoubleOrNull() ?: 30000.0,
                                paymentInstructions = instructions,
                                whatsappNumber = waNumber,
                                announcement = announcement,
                                maintenanceMode = maintenance
                            )
                        )
                    },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        BrutalCard {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Kirim Notifikasi Pengumuman Massal", style = MaterialTheme.typography.titleLarge)
                BrutalTextField(value = broadcastTitle, onValueChange = { broadcastTitle = it }, label = "Judul Pengumuman", leadingIcon = Lucide.Bell)
                BrutalTextField(value = broadcastBody, onValueChange = { broadcastBody = it }, label = "Isi Pengumuman", singleLine = false)
                BrutalButton(
                    text = "Kirim ke Semua Pengguna",
                    icon = Lucide.Bell,
                    enabled = !isBusy && broadcastTitle.isNotBlank() && broadcastBody.isNotBlank(),
                    onClick = {
                        onBroadcast(broadcastTitle, broadcastBody)
                        broadcastTitle = ""
                        broadcastBody = ""
                    },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}
