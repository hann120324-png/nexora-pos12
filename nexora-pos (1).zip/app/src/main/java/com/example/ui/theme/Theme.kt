package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val NexoraLightColorScheme = lightColorScheme(
    primary = PrimaryYellow,
    onPrimary = BrutalBlack,
    primaryContainer = PrimaryYellow,
    onPrimaryContainer = BrutalBlack,
    secondary = SecondaryYellow,
    onSecondary = BrutalBlack,
    secondaryContainer = LightGray,
    onSecondaryContainer = BrutalBlack,
    tertiary = BrutalBlack,
    onTertiary = PrimaryYellow,
    background = BrutalWhite,
    onBackground = BrutalBlack,
    surface = BrutalWhite,
    onSurface = BrutalBlack,
    surfaceVariant = LightGray,
    onSurfaceVariant = MutedText,
    outline = BrutalBlack,
    outlineVariant = GrayBorder,
    error = CrimsonError,
    onError = BrutalWhite,
)

private val NexoraDarkColorScheme = darkColorScheme(
    primary = PrimaryYellow,
    onPrimary = BrutalBlack,
    primaryContainer = YellowDarkTint,
    onPrimaryContainer = PrimaryYellow,
    secondary = SecondaryYellow,
    onSecondary = BrutalBlack,
    secondaryContainer = DarkSurfaceElevated,
    onSecondaryContainer = BrutalWhite,
    tertiary = PrimaryYellow,
    onTertiary = BrutalBlack,
    background = DarkBackground,
    onBackground = BrutalWhite,
    surface = DarkCard,
    onSurface = BrutalWhite,
    surfaceVariant = DarkSurfaceElevated,
    onSurfaceVariant = DarkMutedText,
    outline = PrimaryYellow,
    outlineVariant = DarkBorder,
    error = CrimsonError,
    onError = BrutalWhite,
)

val ColorScheme.isDarkBrutal: Boolean
    get() = background == DarkBackground

/** High-contrast accent text: Black (#111111) on light surfaces, Primary Yellow (#FACC15) on dark surfaces. */
val ColorScheme.brutalAccentText: Color
    get() = if (isDarkBrutal) PrimaryYellow else BrutalBlack

/** Crisp accent border: Black (#111111) in light mode, Primary Yellow (#FACC15) in dark mode. */
val ColorScheme.brutalHighlightBorder: Color
    get() = if (isDarkBrutal) PrimaryYellow else BrutalBlack

// Clean Modern Brutalism: sharp geometric corners
val NexoraShapes = Shapes(
    extraSmall = RoundedCornerShape(2.dp),
    small = RoundedCornerShape(4.dp),
    medium = RoundedCornerShape(4.dp),
    large = RoundedCornerShape(6.dp),
    extraLarge = RoundedCornerShape(8.dp),
)

@Composable
fun NexoraPosTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) NexoraDarkColorScheme else NexoraLightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = NexoraTypography,
        shapes = NexoraShapes,
        content = content
    )
}
