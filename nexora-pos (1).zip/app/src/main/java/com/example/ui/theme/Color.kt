package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// NEXORA POS — FINAL COLOR SYSTEM (YELLOW + BLACK + WHITE)
val PrimaryYellow = Color(0xFFFACC15)
val SecondaryYellow = Color(0xFFEAB308)
val YellowSoftTint = Color(0xFFFEF9C3)
val YellowDarkTint = Color(0xFF262008)

val BrutalBlack = Color(0xFF111111)
val BrutalWhite = Color(0xFFFFFFFF)
val LightGray = Color(0xFFF4F4F5)
val GrayBorder = Color(0xFFD4D4D4)
val MutedText = Color(0xFF737373)

val DarkBackground = Color(0xFF090909)
val DarkCard = Color(0xFF181818)
val DarkSurfaceElevated = Color(0xFF222222)
val DarkBorder = Color(0xFF333333)
val DarkMutedText = Color(0xFFA1A1AA)

// Semantic High-Contrast Status Tokens
val EmeraldSuccess = Color(0xFF16A34A)
val AmberWarning = SecondaryYellow
val CrimsonError = Color(0xFFDC2626)
val WhatsAppGreen = Color(0xFF16A34A)
