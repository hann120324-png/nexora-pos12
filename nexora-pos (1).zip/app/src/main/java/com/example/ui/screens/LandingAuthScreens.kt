package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.annotation.DrawableRes
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import com.example.R
import com.example.core.DateFormatter
import com.example.core.ImageEncodingHelper
import com.example.core.RupiahFormatter
import com.example.core.WhatsAppHelper
import com.example.core.onGoogleSignInClicked
import com.example.model.AppSettings
import com.example.model.PremiumRequest
import com.example.model.UserProfile
import com.example.ui.components.BrutalBadge
import com.example.ui.components.BrutalButton
import com.example.ui.components.BrutalCard
import com.example.ui.components.BrutalOutlinedButton
import com.example.ui.components.BrutalTextField
import com.example.ui.components.ErrorBannerCard
import com.example.ui.components.Lucide
import com.example.ui.components.LucideIcon
import com.example.ui.components.StatusBadge
import com.example.ui.components.StoredImage
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.BrutalBlack
import com.example.ui.theme.BrutalWhite
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.PrimaryYellow
import com.example.ui.theme.WhatsAppGreen
import com.example.ui.theme.brutalAccentText
import com.example.ui.theme.brutalHighlightBorder

private enum class AuthTabMode(val label: String) {
    LOGIN("Login"),
    REGISTER("Register"),
    RECOVERY("Lupa Akses")
}

@Composable
fun LandingAuthScreen(
    appSettings: AppSettings,
    onAuthSuccess: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }
    var isSigningIn by remember { mutableStateOf(false) }
    var authError by remember { mutableStateOf<String?>(null) }
    var authTab by remember { mutableStateOf(AuthTabMode.LOGIN) }

    val triggerGoogleSignIn = {
        authError = null
        isSigningIn = true
        onGoogleSignInClicked(
            context = context,
            credentialManager = credentialManager,
            onAuthSuccess = {
                isSigningIn = false
                onAuthSuccess()
            },
            onAuthError = { msg ->
                isSigningIn = false
                authError = msg
            },
            scope = scope,
            onAuthCancelled = {
                isSigningIn = false
            }
        )
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .windowInsetsPadding(WindowInsets.safeDrawing),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 760.dp),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. HERO CARD — CLEAN MODERN BRUTALISM SAAS
            item {
                BrutalCard(
                    borderColor = MaterialTheme.colorScheme.outline,
                    borderWidth = 2.dp,
                    contentPadding = 20.dp
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Image(
                                    painter = painterResource(id = R.drawable.img_nexora_logo),
                                    contentDescription = "Logo NEXORA POS",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .size(44.dp)
                                        .clip(RoundedCornerShape(6.dp))
                                        .border(1.5.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(6.dp))
                                )
                                Column {
                                    Text(appSettings.appName, style = MaterialTheme.typography.titleLarge)
                                    Text(
                                        appSettings.tagline,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.brutalAccentText
                                    )
                                }
                            }
                            BrutalBadge(text = "SAAS POS", icon = Lucide.ShieldCheck)
                        }

                        Text(
                            text = "Kasir Pintar & Manajemen Bisnis Modern",
                            style = MaterialTheme.typography.displayLarge
                        )
                        Text(
                            text = appSettings.description,
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        // Auth Mode Switcher (Login / Register / Pemulihan Akses)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            AuthTabMode.entries.forEach { tab ->
                                val selected = authTab == tab
                                Surface(
                                    onClick = { authTab = tab },
                                    shape = MaterialTheme.shapes.small,
                                    color = if (selected) PrimaryYellow else MaterialTheme.colorScheme.surfaceVariant,
                                    border = BorderStroke(
                                        1.5.dp,
                                        if (selected) MaterialTheme.colorScheme.brutalHighlightBorder else MaterialTheme.colorScheme.outlineVariant
                                    ),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Box(
                                        modifier = Modifier.padding(vertical = 10.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = tab.label,
                                            style = MaterialTheme.typography.labelLarge,
                                            color = if (selected) BrutalBlack else MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                }
                            }
                        }

                        val tabSummary = when (authTab) {
                            AuthTabMode.LOGIN -> "Masuk cepat ke ruang kerja toko Anda dengan akun Google yang tersinkronisasi aman ke Cloud Firestore."
                            AuthTabMode.REGISTER -> "Daftar otomatis sebagai pengguna baru NEXORA POS menggunakan akun Google. Langsung aktif dengan paket Free Rp0."
                            AuthTabMode.RECOVERY -> "Akses akun terhubung langsung dengan Google Credential Manager sehingga pemulihan akses mengikuti keamanan akun Google Anda."
                        }
                        Text(
                            text = tabSummary,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            BrutalButton(
                                text = if (isSigningIn) "Memproses..." else when (authTab) {
                                    AuthTabMode.REGISTER -> "Daftar via Google"
                                    else -> "Masuk dengan Google"
                                },
                                icon = if (authTab == AuthTabMode.REGISTER) Lucide.UserPlus else Lucide.LogIn,
                                onClick = triggerGoogleSignIn,
                                enabled = !isSigningIn,
                                modifier = Modifier.weight(1f),
                                testTag = "google_signin_button"
                            )
                        }
                    }
                }
            }

            if (isSigningIn) {
                item {
                    BrutalCard(borderColor = PrimaryYellow, borderWidth = 2.dp) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(22.dp),
                                strokeWidth = 2.5.dp,
                                color = MaterialTheme.colorScheme.brutalAccentText
                            )
                            Text("Menghubungkan akun Google ke Firebase...", style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }

            if (authError != null) {
                item {
                    ErrorBannerCard(
                        message = authError!!,
                        onRetry = triggerGoogleSignIn
                    )
                }
            }

            // 2. FITUR UNGGULAN
            item {
                Text("Arsitektur Fitur Bisnis", style = MaterialTheme.typography.titleLarge)
            }
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    FeatureRowCard(
                        icon = Lucide.ScanLine,
                        title = "Scanner QR & Barcode Real-Time",
                        desc = "Scan kamera belakang dengan ML Kit atau input SKU manual, plus cetak & unduh QR produk."
                    )
                    FeatureRowCard(
                        icon = Lucide.ShoppingCart,
                        title = "Kasir POS & Pengurangan Stok Atomik",
                        desc = "Transaksi kasir aman dengan kalkulasi diskon, pajak, kembalian, dan validasi stok otomatis."
                    )
                    FeatureRowCard(
                        icon = Lucide.Printer,
                        title = "Cetak Struk 58mm / 80mm & Ekspor PDF",
                        desc = "Pratinjau struk thermal, simpan PDF, dan cetak langsung melalui sistem Android Print."
                    )
                    FeatureRowCard(
                        icon = Lucide.Bot,
                        title = "AI Customer Service & Tools Premium",
                        desc = "Asisten AI bisnis 24/7 berbasis Firebase AI Logic serta manajemen komplain terintegrasi."
                    )
                    FeatureRowCard(
                        icon = Lucide.ShieldCheck,
                        title = "Sinkronisasi Cloud & Keamanan Zero-Trust",
                        desc = "Seluruh data tersimpan permanen di Cloud Firestore dengan isolasi akun dan App Check."
                    )
                }
            }

            // 3. PERBANDINGAN FREE VS PREMIUM
            item {
                PremiumComparisonCards(
                    premiumPrice = appSettings.premiumPrice,
                    onUpgradeAction = triggerGoogleSignIn
                )
            }

            // 4. FAQ & BANTUAN CS
            item {
                BrutalCard {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Pertanyaan Umum (FAQ)", style = MaterialTheme.typography.titleLarge)
                        Text(
                            "Apakah paket Premium berlangganan bulanan?\nTidak. Paket Premium Lifetime cukup dibayar sekali (${RupiahFormatter.format(appSettings.premiumPrice)}) untuk aktif selamanya.",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                        Text(
                            "Bagaimana cara daftar, login, atau pemulihan akses?\nGunakan tombol Masuk / Daftar Google di atas. Akun Anda otomatis tersinkronisasi aman di Firebase.",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Butuh Bantuan Admin?", style = MaterialTheme.typography.titleMedium)
                                Text(
                                    "WhatsApp: ${appSettings.whatsappNumber}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            BrutalButton(
                                text = "Hubungi CS",
                                icon = Lucide.MessageCircle,
                                containerColor = WhatsAppGreen,
                                onClick = {
                                    WhatsAppHelper.openCs(
                                        context = context,
                                        whatsappNumber = appSettings.whatsappNumber,
                                        name = "Calon Pengguna",
                                        email = "-",
                                        accountStatus = "Belum Login"
                                    )
                                },
                                testTag = "landing_wa_cs_button"
                            )
                        }
                    }
                }
            }

            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        "${appSettings.appName} — ${appSettings.tagline}",
                        style = MaterialTheme.typography.labelLarge
                    )
                    Text(
                        "Manage Smart. Sell Faster. | ${appSettings.supportContact}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun FeatureRowCard(@DrawableRes icon: Int, title: String, desc: String) {
    BrutalCard {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(PrimaryYellow)
                    .border(1.5.dp, BrutalBlack, RoundedCornerShape(4.dp)),
                contentAlignment = Alignment.Center
            ) {
                LucideIcon(icon, contentDescription = null, tint = BrutalBlack, modifier = Modifier.size(20.dp))
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleMedium)
                Text(desc, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
fun PremiumComparisonCards(
    premiumPrice: Double,
    onUpgradeAction: () -> Unit,
    actionLabel: String = "Beli Premium Sekarang"
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Perbandingan Paket Free vs Premium", style = MaterialTheme.typography.titleLarge)

        BrutalCard {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("PAKET FREE", style = MaterialTheme.typography.titleLarge)
                    BrutalBadge("Rp0 / Gratis")
                }
                val freeItems = listOf(
                    "Dashboard ringkasan bisnis",
                    "Scan QR & Barcode produk",
                    "Tambah, edit, hapus, kategori & pencarian produk",
                    "Manajemen stok dasar & riwayat dasar",
                    "Profil toko, Dark Mode, Komplain & WhatsApp CS"
                )
                freeItems.forEach { item ->
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        LucideIcon(Lucide.CircleCheck, contentDescription = null, tint = EmeraldSuccess, modifier = Modifier.size(16.dp))
                        Text(item, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }

        BrutalCard(
            containerColor = BrutalBlack,
            borderColor = PrimaryYellow,
            borderWidth = 2.dp
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        LucideIcon(Lucide.Crown, contentDescription = null, tint = PrimaryYellow, modifier = Modifier.size(20.dp))
                        Text("PREMIUM LIFETIME", style = MaterialTheme.typography.titleLarge, color = BrutalWhite)
                    }
                    BrutalBadge(
                        text = "${RupiahFormatter.format(premiumPrice)} Sekali Bayar",
                        containerColor = PrimaryYellow,
                        contentColor = BrutalBlack
                    )
                }
                val premItems = listOf(
                    "Semua fitur Free tanpa batas",
                    "Transaksi Kasir POS & validasi stok atomik",
                    "Cetak Struk Thermal 58mm & 80mm + Download PDF",
                    "Laporan penjualan, laba rugi, statistik & ekspor CSV",
                    "Tools Premium & AI Customer Service 24/7",
                    "Pembayaran QRIS (saat gateway dikonfigurasi Admin)",
                    "Seluruh pembaruan fitur Premium mendatang"
                )
                premItems.forEach { item ->
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        LucideIcon(Lucide.CircleCheck, contentDescription = null, tint = PrimaryYellow, modifier = Modifier.size(16.dp))
                        Text(item, style = MaterialTheme.typography.bodyMedium, color = BrutalWhite.copy(alpha = 0.9f))
                    }
                }
                Spacer(Modifier.height(4.dp))
                BrutalButton(
                    text = actionLabel,
                    icon = Lucide.Crown,
                    containerColor = PrimaryYellow,
                    contentColor = BrutalBlack,
                    borderColor = PrimaryYellow,
                    onClick = onUpgradeAction,
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "buy_premium_button"
                )
            }
        }
    }
}

@Composable
fun PremiumScreen(
    user: UserProfile,
    appSettings: AppSettings,
    requests: List<PremiumRequest>,
    isSubmitting: Boolean,
    onSubmitRequest: (paymentMethod: String, proofUrl: String?, note: String?) -> Unit,
    onUpdateProof: (requestId: String, proofUrl: String, note: String?) -> Unit,
    onShowMessage: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var paymentMethod by remember { mutableStateOf("Transfer Bank") }
    var note by remember { mutableStateOf("") }
    var proofDataUri by remember { mutableStateOf<String?>(null) }

    val latestRequest = requests.firstOrNull()
    val pendingRequest = requests.firstOrNull { it.status == "PENDING" }

    val photoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            val encoded = ImageEncodingHelper.uriToCompressedDataUri(context, uri)
            if (encoded != null) {
                proofDataUri = encoded
                if (pendingRequest != null) {
                    onUpdateProof(pendingRequest.id, encoded, note.ifBlank { null })
                }
            } else {
                onShowMessage("Gagal mengompres gambar bukti pembayaran. Pilih gambar lain.")
            }
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .widthIn(max = 760.dp),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            BrutalCard(
                borderColor = if (user.isPremiumActive) EmeraldSuccess else MaterialTheme.colorScheme.brutalHighlightBorder,
                borderWidth = 2.dp
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Status Paket Akun", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(
                            if (user.isPremiumActive) "PREMIUM LIFETIME AKTIF"
                            else if (user.premiumStatus == "pending") "MENUNGGU PERSETUJUAN ADMIN"
                            else if (user.premiumStatus == "rejected") "PERMINTAAN DITOLAK"
                            else "PAKET FREE",
                            style = MaterialTheme.typography.headlineMedium,
                            color = if (user.isPremiumActive) EmeraldSuccess else MaterialTheme.colorScheme.brutalAccentText
                        )
                        if (user.premiumActivatedAt != null) {
                            Text(
                                "Aktif sejak: ${DateFormatter.format(user.premiumActivatedAt)}",
                                style = MaterialTheme.typography.labelSmall
                            )
                        }
                    }
                    StatusBadge(user.premiumStatus)
                }
            }
        }

        if (!user.isPremiumActive) {
            item {
                BrutalCard {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            LucideIcon(Lucide.Banknote, contentDescription = null, tint = MaterialTheme.colorScheme.brutalAccentText, modifier = Modifier.size(20.dp))
                            Text("Instruksi Pembayaran Admin", style = MaterialTheme.typography.titleLarge)
                        }
                        Text(appSettings.paymentInstructions, style = MaterialTheme.typography.bodyMedium)
                        Text(
                            "Nominal: ${RupiahFormatter.format(appSettings.premiumPrice)} (Sekali Bayar Selamanya)",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.brutalAccentText
                        )
                    }
                }
            }

            if (pendingRequest != null) {
                item {
                    BrutalCard(borderColor = AmberWarning, borderWidth = 2.dp) {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Permintaan Sedang Diproses", style = MaterialTheme.typography.titleLarge)
                                StatusBadge("PENDING")
                            }
                            Text(
                                "ID Permintaan: ${pendingRequest.id}\nMetode: ${pendingRequest.paymentMethod}\nNominal: ${RupiahFormatter.format(pendingRequest.amount)}",
                                style = MaterialTheme.typography.bodyMedium
                            )
                            val previewProof = proofDataUri ?: pendingRequest.proofUrl
                            if (previewProof.isNotBlank()) {
                                StoredImage(
                                    imageSource = previewProof,
                                    contentDescription = "Bukti Pembayaran",
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(180.dp)
                                        .clip(MaterialTheme.shapes.small)
                                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, MaterialTheme.shapes.small)
                                )
                            }
                            BrutalOutlinedButton(
                                text = "Unggah / Perbarui Bukti Pembayaran",
                                icon = Lucide.Upload,
                                onClick = {
                                    photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                                },
                                modifier = Modifier.fillMaxWidth(),
                                testTag = "upload_payment_proof_button"
                            )
                        }
                    }
                }
            } else {
                item {
                    BrutalCard {
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                LucideIcon(Lucide.Wallet, contentDescription = null, tint = MaterialTheme.colorScheme.brutalAccentText, modifier = Modifier.size(20.dp))
                                Text("Ajukan Upgrade Premium Lifetime", style = MaterialTheme.typography.titleLarge)
                            }
                            if (latestRequest?.status == "REJECTED" && latestRequest.rejectionReason.isNotBlank()) {
                                ErrorBannerCard(message = "Alasan penolakan sebelumnya: ${latestRequest.rejectionReason}")
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf("Transfer Bank", "E-Wallet", "QRIS Manual").forEach { method ->
                                    val selected = paymentMethod == method
                                    Surface(
                                        shape = MaterialTheme.shapes.small,
                                        color = if (selected) PrimaryYellow else MaterialTheme.colorScheme.surfaceVariant,
                                        border = BorderStroke(
                                            1.5.dp,
                                            if (selected) MaterialTheme.colorScheme.brutalHighlightBorder else MaterialTheme.colorScheme.outlineVariant
                                        ),
                                        modifier = Modifier.weight(1f),
                                        onClick = { paymentMethod = method }
                                    ) {
                                        Box(
                                            modifier = Modifier.padding(vertical = 10.dp, horizontal = 6.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                method,
                                                style = MaterialTheme.typography.labelLarge,
                                                color = if (selected) BrutalBlack else MaterialTheme.colorScheme.onSurface
                                            )
                                        }
                                    }
                                }
                            }
                            BrutalTextField(
                                value = note,
                                onValueChange = { note = it },
                                label = "Catatan / Nama Pengirim (Opsional)",
                                placeholder = "Contoh: Transfer BCA a.n. Budi",
                                leadingIcon = Lucide.Wallet,
                                testTag = "premium_note_input"
                            )
                            if (!proofDataUri.isNullOrBlank()) {
                                StoredImage(
                                    imageSource = proofDataUri,
                                    contentDescription = "Pratinjau Bukti Transfer",
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(160.dp)
                                        .clip(MaterialTheme.shapes.small)
                                )
                            }
                            BrutalOutlinedButton(
                                text = if (proofDataUri == null) "Pilih Bukti Pembayaran (Opsional)" else "Ganti Bukti Pembayaran",
                                icon = Lucide.Upload,
                                onClick = {
                                    photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                                },
                                modifier = Modifier.fillMaxWidth(),
                                testTag = "pick_payment_proof_button"
                            )
                            BrutalButton(
                                text = if (isSubmitting) "Mengirim Permintaan..." else "Beli Premium (${RupiahFormatter.format(appSettings.premiumPrice)})",
                                icon = Lucide.Crown,
                                enabled = !isSubmitting,
                                onClick = { onSubmitRequest(paymentMethod, proofDataUri, note) },
                                modifier = Modifier.fillMaxWidth(),
                                testTag = "submit_premium_request_button"
                            )
                        }
                    }
                }
            }
        }

        item {
            PremiumComparisonCards(
                premiumPrice = appSettings.premiumPrice,
                actionLabel = if (user.isPremiumActive) "Premium Lifetime Aktif" else "Hubungi Admin via WhatsApp",
                onUpgradeAction = {
                    WhatsAppHelper.openCs(
                        context = context,
                        whatsappNumber = appSettings.whatsappNumber,
                        name = user.name,
                        email = user.email,
                        accountStatus = if (user.isPremiumActive) "Premium Lifetime" else "Free",
                        issue = "Tanya aktivasi Premium Lifetime"
                    )
                }
            )
        }
    }
}
