package com.example.ui.navigation

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.VerticalDivider
import androidx.compose.material3.windowsizeclass.WindowWidthSizeClass
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.annotation.DrawableRes
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.toRoute
import com.example.R
import com.example.core.LocalNotificationHelper
import com.example.core.WhatsAppHelper
import com.example.data.AuthUserRepository
import com.example.data.InventoryRepository
import com.example.data.PosRepository
import com.example.data.SupportPremiumRepository
import com.example.model.UiState
import com.example.model.UserProfile
import com.example.ui.components.BrutalBadge
import com.example.ui.components.BrutalButton
import com.example.ui.components.BrutalCard
import com.example.ui.components.BrutalIconButton
import com.example.ui.components.BrutalOutlinedButton
import com.example.ui.components.ErrorBannerCard
import com.example.ui.components.FloatingWhatsAppMenu
import com.example.ui.components.Lucide
import com.example.ui.components.LucideIcon
import com.example.ui.components.SkeletonBox
import com.example.ui.screens.AdminDashboardScreen
import com.example.ui.screens.AiCustomerServiceScreen
import com.example.ui.screens.ComplaintsScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.NotificationsScreen
import com.example.ui.screens.PosCashierScreen
import com.example.ui.screens.PremiumScreen
import com.example.ui.screens.ProductDetailScreen
import com.example.ui.screens.ProductFormScreen
import com.example.ui.screens.ProductsListScreen
import com.example.ui.screens.ProfileSettingsScreen
import com.example.ui.screens.ReceiptPreviewScreen
import com.example.ui.screens.ReportsScreen
import com.example.ui.screens.ScannerScreen
import com.example.ui.screens.ToolsHubScreen
import com.example.ui.screens.TransactionsHistoryScreen
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.BrutalBlack
import com.example.ui.theme.CrimsonError
import com.example.ui.theme.PrimaryYellow
import com.example.ui.theme.WhatsAppGreen
import com.example.ui.theme.brutalAccentText
import com.example.ui.theme.brutalHighlightBorder
import com.example.viewmodel.AdminViewModel
import com.example.viewmodel.AiCsViewModel
import com.example.viewmodel.InventoryViewModel
import com.example.viewmodel.MainViewModel
import com.example.viewmodel.PosViewModel
import com.example.viewmodel.SupportToolsViewModel
import com.google.firebase.auth.FirebaseUser
import kotlinx.serialization.Serializable

@Serializable data object RouteDashboard
@Serializable data object RouteProducts
@Serializable data object RouteProductAdd
@Serializable data class RouteProductDetail(val productId: String)
@Serializable data class RouteProductEdit(val productId: String)
@Serializable data object RouteScanner
@Serializable data object RoutePos
@Serializable data object RouteTransactions
@Serializable data class RouteReceipt(val transactionId: String)
@Serializable data object RouteReports
@Serializable data object RouteTools
@Serializable data object RouteAiCs
@Serializable data object RoutePremium
@Serializable data object RouteComplaints
@Serializable data object RouteNotifications
@Serializable data object RouteProfile
@Serializable data object RouteAdmin

private data class NavTabItem(
    val label: String,
    @DrawableRes val icon: Int,
    val route: Any,
    val testTag: String
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NexoraAuthenticatedApp(
    firebaseUser: FirebaseUser,
    widthSizeClass: WindowWidthSizeClass,
    onDarkThemeResolved: (Boolean) -> Unit,
    onSignOut: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val uid = firebaseUser.uid

    val mainVm: MainViewModel = viewModel(
        key = "main_$uid",
        factory = viewModelFactory {
            initializer {
                val app = this[APPLICATION_KEY]!!
                MainViewModel(
                    authRepo = AuthUserRepository(app),
                    supportRepo = SupportPremiumRepository(app),
                    currentUserId = uid
                )
            }
        }
    )

    val inventoryVm: InventoryViewModel = viewModel(
        key = "inv_$uid",
        factory = viewModelFactory {
            initializer {
                val app = this[APPLICATION_KEY]!!
                InventoryViewModel(InventoryRepository(app), uid)
            }
        }
    )

    val posVm: PosViewModel = viewModel(
        key = "pos_$uid",
        factory = viewModelFactory {
            initializer {
                val app = this[APPLICATION_KEY]!!
                PosViewModel(PosRepository(app), uid)
            }
        }
    )

    val supportToolsVm: SupportToolsViewModel = viewModel(
        key = "sup_$uid",
        factory = viewModelFactory {
            initializer {
                val app = this[APPLICATION_KEY]!!
                SupportToolsViewModel(SupportPremiumRepository(app), uid)
            }
        }
    )

    val aiCsVm: AiCsViewModel = viewModel(
        key = "ai_$uid",
        factory = viewModelFactory {
            initializer {
                val app = this[APPLICATION_KEY]!!
                AiCsViewModel(SupportPremiumRepository(app), uid)
            }
        }
    )

    LaunchedEffect(uid) {
        mainVm.ensureProfile(firebaseUser)
    }

    val notifPermLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ -> }

    LaunchedEffect(uid) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) {
                notifPermLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    val userState by mainVm.userProfileState.collectAsStateWithLifecycle()
    val appSettings by mainVm.appSettings.collectAsStateWithLifecycle()
    val apiSettings by mainVm.apiSettings.collectAsStateWithLifecycle()
    val notifications by mainVm.notifications.collectAsStateWithLifecycle()
    val toastMessage by mainVm.toastMessage.collectAsStateWithLifecycle()
    val isSavingProfile by mainVm.isSaving.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }
    LaunchedEffect(toastMessage) {
        val msg = toastMessage
        if (!msg.isNullOrBlank()) {
            snackbarHostState.showSnackbar(msg)
            mainVm.clearToast()
        }
    }

    var lastNotifiedId by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(notifications) {
        val newestUnread = notifications.firstOrNull { !it.read }
        if (newestUnread != null && newestUnread.id != lastNotifiedId) {
            lastNotifiedId = newestUnread.id
            LocalNotificationHelper.showNotification(
                context = context,
                id = newestUnread.id.hashCode(),
                title = newestUnread.title,
                body = newestUnread.body
            )
        }
    }

    val userProfile: UserProfile? = (userState as? UiState.Success)?.data
    LaunchedEffect(userProfile?.darkMode) {
        if (userProfile != null) {
            onDarkThemeResolved(userProfile.darkMode)
        }
    }

    if (userState is UiState.Loading || userProfile == null) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                modifier = Modifier.widthIn(max = 480.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (userState is UiState.Error) {
                    ErrorBannerCard(
                        message = (userState as UiState.Error).message,
                        onRetry = { mainVm.ensureProfile(firebaseUser) }
                    )
                    BrutalOutlinedButton(
                        text = "Keluar",
                        icon = Lucide.LogOut,
                        onClick = onSignOut,
                        modifier = Modifier.fillMaxWidth()
                    )
                } else {
                    Text("Menyiapkan ruang kerja NEXORA POS...", style = MaterialTheme.typography.titleLarge)
                    SkeletonBox(height = 96.dp)
                    SkeletonBox(height = 140.dp)
                }
            }
        }
        return
    }

    if (userProfile.isDisabledAccount) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            BrutalCard(
                modifier = Modifier.widthIn(max = 480.dp),
                borderColor = CrimsonError,
                borderWidth = 2.dp
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        LucideIcon(Lucide.Ban, contentDescription = null, tint = CrimsonError, modifier = Modifier.size(22.dp))
                        Text("Akun Dinonaktifkan", style = MaterialTheme.typography.headlineMedium, color = CrimsonError)
                    }
                    Text(
                        "Akun Anda (${userProfile.email}) saat ini dinonaktifkan oleh Admin. Silakan hubungi Admin melalui WhatsApp untuk informasi lebih lanjut.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    BrutalButton(
                        text = "Hubungi Admin WhatsApp",
                        icon = Lucide.MessageCircle,
                        containerColor = WhatsAppGreen,
                        onClick = {
                            WhatsAppHelper.openComplaint(
                                context = context,
                                whatsappNumber = appSettings.whatsappNumber,
                                name = userProfile.name,
                                email = userProfile.email,
                                uid = userProfile.userId,
                                detail = "Akun saya dinonaktifkan"
                            )
                        },
                        modifier = Modifier.fillMaxWidth()
                    )
                    BrutalOutlinedButton(
                        text = "Keluar dari Akun",
                        icon = Lucide.LogOut,
                        onClick = onSignOut,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
        return
    }

    if (appSettings.maintenanceMode && !userProfile.isAdminRole) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            BrutalCard(
                modifier = Modifier.widthIn(max = 480.dp),
                borderColor = AmberWarning,
                borderWidth = 2.dp
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Pemeliharaan Sistem", style = MaterialTheme.typography.headlineMedium)
                    Text(
                        "NEXORA POS sedang dalam pemeliharaan terjadwal oleh Admin untuk meningkatkan layanan. Silakan coba beberapa saat lagi.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    BrutalButton(
                        text = "Hubungi CS WhatsApp",
                        icon = Lucide.MessageCircle,
                        containerColor = WhatsAppGreen,
                        onClick = {
                            WhatsAppHelper.openCs(
                                context = context,
                                whatsappNumber = appSettings.whatsappNumber,
                                name = userProfile.name,
                                email = userProfile.email,
                                accountStatus = if (userProfile.isPremiumActive) "Premium Lifetime" else "Free"
                            )
                        },
                        modifier = Modifier.fillMaxWidth()
                    )
                    BrutalOutlinedButton(
                        text = "Keluar",
                        icon = Lucide.LogOut,
                        onClick = onSignOut,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
        return
    }

    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = backStackEntry?.destination
    val unreadCount = notifications.count { !it.read }
    var showMobileMenuSheet by remember { mutableStateOf(false) }

    val productsState by inventoryVm.productsState.collectAsStateWithLifecycle()
    val filteredProducts by inventoryVm.filteredProducts.collectAsStateWithLifecycle()
    val categories by inventoryVm.categories.collectAsStateWithLifecycle()
    val movements by inventoryVm.movements.collectAsStateWithLifecycle()
    val searchQuery by inventoryVm.searchQuery.collectAsStateWithLifecycle()
    val selectedCategory by inventoryVm.selectedCategory.collectAsStateWithLifecycle()
    val stockFilter by inventoryVm.stockFilter.collectAsStateWithLifecycle()
    val sortOrder by inventoryVm.sortOrder.collectAsStateWithLifecycle()
    val isInvBusy by inventoryVm.isBusy.collectAsStateWithLifecycle()

    val transactionsState by posVm.transactionsState.collectAsStateWithLifecycle()
    val cart by posVm.cart.collectAsStateWithLifecycle()
    val selectedTxItems by posVm.selectedItems.collectAsStateWithLifecycle()
    val isCheckingOut by posVm.isCheckingOut.collectAsStateWithLifecycle()

    val premiumRequests by supportToolsVm.premiumRequests.collectAsStateWithLifecycle()
    val complaints by supportToolsVm.complaints.collectAsStateWithLifecycle()
    val complaintMessages by supportToolsVm.complaintMessages.collectAsStateWithLifecycle()
    val toolsHistory by supportToolsVm.toolsHistory.collectAsStateWithLifecycle()
    val toolState by supportToolsVm.toolState.collectAsStateWithLifecycle()
    val isSupportSubmitting by supportToolsVm.isSubmitting.collectAsStateWithLifecycle()

    val aiConversations by aiCsVm.conversations.collectAsStateWithLifecycle()
    val activeAiConvId by aiCsVm.activeConversationId.collectAsStateWithLifecycle()
    val aiMessages by aiCsVm.messages.collectAsStateWithLifecycle()
    val aiState by aiCsVm.aiState.collectAsStateWithLifecycle()
    val aiStreamingText by aiCsVm.streamingText.collectAsStateWithLifecycle()

    val productsList = (productsState as? UiState.Success)?.data ?: emptyList()
    val transactionsList = (transactionsState as? UiState.Success)?.data ?: emptyList()

    // Mobile Bottom Navigation: Dashboard, Produk, Scanner, Kasir, Profile (Section 7 spec)
    val bottomNavTabs = remember {
        listOf(
            NavTabItem("Dashboard", Lucide.LayoutDashboard, RouteDashboard, "nav_dashboard"),
            NavTabItem("Produk", Lucide.Package, RouteProducts, "nav_products"),
            NavTabItem("Scanner", Lucide.ScanLine, RouteScanner, "nav_scanner"),
            NavTabItem("Kasir", Lucide.ShoppingCart, RoutePos, "nav_pos"),
            NavTabItem("Profile", Lucide.UserRound, RouteProfile, "nav_profile")
        )
    }

    // Desktop/Tablet Sidebar Navigation (Section 7 spec)
    val sidebarNavTabs = remember(userProfile.isAdminRole) {
        buildList {
            add(NavTabItem("Dashboard", Lucide.LayoutDashboard, RouteDashboard, "rail_dashboard"))
            add(NavTabItem("Produk", Lucide.Package, RouteProducts, "rail_products"))
            add(NavTabItem("Scanner", Lucide.ScanLine, RouteScanner, "rail_scanner"))
            add(NavTabItem("Kasir", Lucide.ShoppingCart, RoutePos, "rail_pos"))
            add(NavTabItem("Transaksi", Lucide.Receipt, RouteTransactions, "rail_transactions"))
            add(NavTabItem("Laporan", Lucide.ChartNoAxesCombined, RouteReports, "rail_reports"))
            add(NavTabItem("Tools", Lucide.Wrench, RouteTools, "rail_tools"))
            add(NavTabItem("AI CS", Lucide.Bot, RouteAiCs, "rail_aics"))
            add(NavTabItem("Premium", Lucide.Crown, RoutePremium, "rail_premium"))
            add(NavTabItem("Komplain", Lucide.MessageSquareWarning, RouteComplaints, "rail_complaints"))
            add(NavTabItem("Notifikasi", Lucide.Bell, RouteNotifications, "rail_notifications"))
            add(NavTabItem("Pengaturan", Lucide.Settings, RouteProfile, "rail_profile"))
            if (userProfile.isAdminRole) {
                add(NavTabItem("Admin Panel", Lucide.ShieldCheck, RouteAdmin, "rail_admin"))
            }
        }
    }

    fun navigateTopLevel(route: Any) {
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }

    fun isRouteActive(route: Any): Boolean = when (route) {
        is RouteDashboard -> currentDestination?.hasRoute<RouteDashboard>() == true
        is RouteProducts -> currentDestination?.hasRoute<RouteProducts>() == true ||
            currentDestination?.hasRoute<RouteProductDetail>() == true ||
            currentDestination?.hasRoute<RouteProductAdd>() == true ||
            currentDestination?.hasRoute<RouteProductEdit>() == true
        is RouteScanner -> currentDestination?.hasRoute<RouteScanner>() == true
        is RoutePos -> currentDestination?.hasRoute<RoutePos>() == true
        is RouteTransactions -> currentDestination?.hasRoute<RouteTransactions>() == true ||
            currentDestination?.hasRoute<RouteReceipt>() == true
        is RouteReports -> currentDestination?.hasRoute<RouteReports>() == true
        is RouteTools -> currentDestination?.hasRoute<RouteTools>() == true
        is RouteAiCs -> currentDestination?.hasRoute<RouteAiCs>() == true
        is RoutePremium -> currentDestination?.hasRoute<RoutePremium>() == true
        is RouteComplaints -> currentDestination?.hasRoute<RouteComplaints>() == true
        is RouteNotifications -> currentDestination?.hasRoute<RouteNotifications>() == true
        is RouteProfile -> currentDestination?.hasRoute<RouteProfile>() == true
        is RouteAdmin -> currentDestination?.hasRoute<RouteAdmin>() == true
        else -> false
    }

    val isWideScreen = widthSizeClass != WindowWidthSizeClass.Compact
    val showWhatsAppFab = currentDestination?.let { dest ->
        dest.hasRoute<RouteDashboard>() ||
            dest.hasRoute<RoutePremium>() ||
            dest.hasRoute<RoutePos>() ||
            dest.hasRoute<RouteTransactions>() ||
            dest.hasRoute<RouteAiCs>() ||
            dest.hasRoute<RouteComplaints>() ||
            dest.hasRoute<RouteProfile>()
    } ?: false

    Scaffold(
        modifier = modifier.fillMaxSize(),
        contentWindowInsets = WindowInsets.safeDrawing,
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        topBar = {
            Column {
                TopAppBar(
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    ),
                    title = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.img_nexora_logo),
                                contentDescription = "Logo NEXORA POS",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .border(1.5.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(6.dp))
                            )
                            Column {
                                Text(appSettings.appName, style = MaterialTheme.typography.titleMedium, maxLines = 1)
                                Text(
                                    if (userProfile.isPremiumActive) "PREMIUM LIFETIME" else "PAKET FREE",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.brutalAccentText
                                )
                            }
                        }
                    },
                    actions = {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(end = 8.dp)
                        ) {
                            BrutalIconButton(
                                icon = Lucide.History,
                                contentDescription = "Transaksi & Riwayat",
                                onClick = { navController.navigate(RouteTransactions) { launchSingleTop = true } },
                                testTag = "topbar_history_button"
                            )
                            BrutalIconButton(
                                icon = Lucide.Bot,
                                contentDescription = "AI Customer Service",
                                onClick = { navController.navigate(RouteAiCs) { launchSingleTop = true } },
                                testTag = "topbar_aics_button"
                            )
                            BadgedBox(
                                badge = {
                                    if (unreadCount > 0) {
                                        Badge(containerColor = PrimaryYellow, contentColor = BrutalBlack) {
                                            Text("$unreadCount")
                                        }
                                    }
                                }
                            ) {
                                BrutalIconButton(
                                    icon = Lucide.Bell,
                                    contentDescription = "Notifikasi",
                                    onClick = { navController.navigate(RouteNotifications) { launchSingleTop = true } },
                                    testTag = "topbar_notifications_button"
                                )
                            }
                            if (!isWideScreen) {
                                BrutalIconButton(
                                    icon = Lucide.Menu,
                                    contentDescription = "Menu Lainnya",
                                    onClick = { showMobileMenuSheet = true },
                                    testTag = "topbar_menu_button"
                                )
                            }
                        }
                    }
                )
                HorizontalDivider(thickness = 1.5.dp, color = MaterialTheme.colorScheme.outlineVariant)
            }
        },
        bottomBar = {
            if (!isWideScreen) {
                Column(modifier = Modifier.background(MaterialTheme.colorScheme.surface)) {
                    HorizontalDivider(thickness = 1.5.dp, color = MaterialTheme.colorScheme.outlineVariant)
                    NavigationBar(
                        containerColor = MaterialTheme.colorScheme.surface,
                        windowInsets = WindowInsets.navigationBars
                    ) {
                        bottomNavTabs.forEach { tab ->
                            val selected = isRouteActive(tab.route)
                            NavigationBarItem(
                                selected = selected,
                                onClick = { navigateTopLevel(tab.route) },
                                icon = {
                                    LucideIcon(
                                        tab.icon,
                                        contentDescription = tab.label,
                                        modifier = Modifier.size(20.dp)
                                    )
                                },
                                label = { Text(tab.label, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = BrutalBlack,
                                    selectedTextColor = MaterialTheme.colorScheme.brutalAccentText,
                                    indicatorColor = PrimaryYellow,
                                    unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                    unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                                ),
                                modifier = Modifier.testTag(tab.testTag)
                            )
                        }
                    }
                }
            }
        },
        floatingActionButton = {
            if (showWhatsAppFab) {
                FloatingWhatsAppMenu(
                    userProfile = userProfile,
                    whatsappNumber = appSettings.whatsappNumber
                )
            }
        }
    ) { innerPadding ->
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Desktop / Tablet Brutalist Sidebar
            if (isWideScreen) {
                Row(modifier = Modifier.fillMaxHeight()) {
                    Column(
                        modifier = Modifier
                            .width(220.dp)
                            .fillMaxHeight()
                            .background(MaterialTheme.colorScheme.surface)
                            .verticalScroll(rememberScrollState())
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            "MENU UTAMA",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                        sidebarNavTabs.forEach { tab ->
                            val selected = isRouteActive(tab.route)
                            val isAdminItem = tab.route is RouteAdmin
                            if (isAdminItem) {
                                HorizontalDivider(
                                    modifier = Modifier.padding(vertical = 6.dp),
                                    color = MaterialTheme.colorScheme.outlineVariant
                                )
                                Text(
                                    "ADMINISTRATOR",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.brutalAccentText,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                )
                            }
                            Surface(
                                onClick = { navigateTopLevel(tab.route) },
                                shape = MaterialTheme.shapes.small,
                                color = if (selected) PrimaryYellow else MaterialTheme.colorScheme.surface,
                                border = if (selected) BorderStroke(1.5.dp, MaterialTheme.colorScheme.brutalHighlightBorder) else null,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag(tab.testTag)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    LucideIcon(
                                        icon = tab.icon,
                                        contentDescription = tab.label,
                                        tint = if (selected) BrutalBlack else MaterialTheme.colorScheme.onSurface,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Text(
                                        text = tab.label,
                                        style = MaterialTheme.typography.labelLarge,
                                        color = if (selected) BrutalBlack else MaterialTheme.colorScheme.onSurface,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                    VerticalDivider(thickness = 1.5.dp, color = MaterialTheme.colorScheme.outlineVariant)
                }
            }

            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight(),
                contentAlignment = Alignment.TopCenter
            ) {
                NavHost(
                    navController = navController,
                    startDestination = RouteDashboard
                ) {
                    composable<RouteDashboard> {
                        DashboardScreen(
                            user = userProfile,
                            appSettings = appSettings,
                            productsState = productsState,
                            transactionsState = transactionsState,
                            onOpenScanner = { navigateTopLevel(RouteScanner) },
                            onOpenAddProduct = { navController.navigate(RouteProductAdd) },
                            onOpenPos = { navigateTopLevel(RoutePos) },
                            onOpenPremium = { navController.navigate(RoutePremium) },
                            onOpenProductDetail = { id -> navController.navigate(RouteProductDetail(id)) },
                            onOpenTransactionDetail = { txId -> navController.navigate(RouteReceipt(txId)) }
                        )
                    }

                    composable<RouteProducts> {
                        ProductsListScreen(
                            productsState = productsState,
                            filteredProducts = filteredProducts,
                            categories = categories,
                            searchQuery = searchQuery,
                            selectedCategory = selectedCategory,
                            stockFilter = stockFilter,
                            sortOrder = sortOrder,
                            onSearchChange = inventoryVm::setSearchQuery,
                            onCategoryChange = inventoryVm::setSelectedCategory,
                            onStockFilterChange = inventoryVm::setStockFilter,
                            onSortOrderChange = inventoryVm::setSortOrder,
                            onAddProductClick = { navController.navigate(RouteProductAdd) },
                            onProductClick = { id -> navController.navigate(RouteProductDetail(id)) },
                            onAddCategory = { name ->
                                inventoryVm.addCategory(name) { res ->
                                    res.onSuccess { mainVm.showToast("Kategori ditambahkan.") }
                                        .onFailure { mainVm.showToast(it.localizedMessage ?: "Gagal menambah kategori.") }
                                }
                            },
                            onDeleteCategory = { catId ->
                                inventoryVm.deleteCategory(catId) { res ->
                                    res.onFailure { mainVm.showToast(it.localizedMessage ?: "Gagal menghapus kategori.") }
                                }
                            },
                            onExportCsv = { uri ->
                                val ok = writeCsvToUri(context, uri, inventoryVm.buildProductsCsv())
                                mainVm.showToast(if (ok) "Data produk CSV diekspor." else "Gagal mengekspor CSV.")
                            }
                        )
                    }

                    composable<RouteProductAdd> {
                        ProductFormScreen(
                            existingProduct = null,
                            categories = categories,
                            isBusy = isInvBusy,
                            onBack = { navController.popBackStack() },
                            onSave = { product ->
                                inventoryVm.saveProduct(product) { res ->
                                    res.onSuccess {
                                        mainVm.showToast("Produk berhasil disimpan.")
                                        navController.popBackStack()
                                    }.onFailure {
                                        mainVm.showToast(it.localizedMessage ?: "Gagal menyimpan produk.")
                                    }
                                }
                            },
                            onShowMessage = mainVm::showToast
                        )
                    }

                    composable<RouteProductEdit> { entry ->
                        val args = entry.toRoute<RouteProductEdit>()
                        val existing = productsList.find { it.id == args.productId }
                        ProductFormScreen(
                            existingProduct = existing,
                            categories = categories,
                            isBusy = isInvBusy,
                            onBack = { navController.popBackStack() },
                            onSave = { product ->
                                inventoryVm.saveProduct(product) { res ->
                                    res.onSuccess {
                                        mainVm.showToast("Perubahan produk disimpan.")
                                        navController.popBackStack()
                                    }.onFailure {
                                        mainVm.showToast(it.localizedMessage ?: "Gagal memperbarui produk.")
                                    }
                                }
                            },
                            onShowMessage = mainVm::showToast
                        )
                    }

                    composable<RouteProductDetail> { entry ->
                        val args = entry.toRoute<RouteProductDetail>()
                        val product = productsList.find { it.id == args.productId }
                        if (product == null) {
                            Box(
                                modifier = Modifier.fillMaxSize().padding(24.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Text("Produk tidak ditemukan atau sudah dihapus.")
                                    BrutalButton(text = "Kembali", onClick = { navController.popBackStack() })
                                }
                            }
                        } else {
                            ProductDetailScreen(
                                product = product,
                                movements = movements,
                                isPremium = userProfile.isPremiumActive,
                                onBack = { navController.popBackStack() },
                                onEdit = { navController.navigate(RouteProductEdit(product.id)) },
                                onDelete = {
                                    inventoryVm.deleteProduct(product.id) { res ->
                                        res.onSuccess {
                                            mainVm.showToast("Produk dihapus.")
                                            navController.popBackStack()
                                        }.onFailure {
                                            mainVm.showToast(it.localizedMessage ?: "Gagal menghapus produk.")
                                        }
                                    }
                                },
                                onAdjustStock = { delta, reason ->
                                    inventoryVm.adjustStock(product, delta, reason) { res ->
                                        res.onSuccess { mainVm.showToast("Stok diperbarui.") }
                                            .onFailure { mainVm.showToast(it.localizedMessage ?: "Gagal mengubah stok.") }
                                    }
                                },
                                onAddToPosCart = {
                                    if (posVm.addToCart(product)) {
                                        mainVm.showToast("${product.name} ditambahkan ke keranjang kasir.")
                                        navigateTopLevel(RoutePos)
                                    } else {
                                        mainVm.showToast("Stok tidak mencukupi.")
                                    }
                                },
                                onShowMessage = mainVm::showToast
                            )
                        }
                    }

                    composable<RouteScanner> {
                        ScannerScreen(
                            isPremium = userProfile.isPremiumActive,
                            onLookupCode = { code, cb -> inventoryVm.lookupProductByCode(code, cb) },
                            onOpenProductDetail = { prodId -> navController.navigate(RouteProductDetail(prodId)) },
                            onAddProductToPos = { prod ->
                                if (posVm.addToCart(prod)) {
                                    mainVm.showToast("${prod.name} masuk ke keranjang POS.")
                                    navigateTopLevel(RoutePos)
                                } else {
                                    mainVm.showToast("Stok ${prod.name} habis.")
                                }
                            },
                            onShowMessage = mainVm::showToast
                        )
                    }

                    composable<RoutePos> {
                        PosCashierScreen(
                            user = userProfile,
                            apiSettings = apiSettings,
                            products = productsList,
                            cart = cart,
                            isCheckingOut = isCheckingOut,
                            onAddToCart = { prod ->
                                if (!posVm.addToCart(prod)) {
                                    mainVm.showToast("Stok ${prod.name} tidak mencukupi.")
                                }
                            },
                            onUpdateQty = posVm::updateQuantity,
                            onRemoveFromCart = posVm::removeFromCart,
                            onClearCart = posVm::clearCart,
                            onOpenScanner = { navigateTopLevel(RouteScanner) },
                            onUpgradePremium = { navController.navigate(RoutePremium) },
                            onCheckout = { discount, taxPercent, method, paidAmount, note ->
                                posVm.checkout(
                                    cashierName = userProfile.name.ifBlank { userProfile.email },
                                    discount = discount,
                                    taxPercent = taxPercent,
                                    paymentMethod = method,
                                    paidAmount = paidAmount,
                                    note = note
                                ) { res ->
                                    res.onSuccess { txId ->
                                        mainVm.showToast("Transaksi berhasil disimpan!")
                                        navController.navigate(RouteReceipt(txId))
                                    }.onFailure { err ->
                                        mainVm.showToast(err.localizedMessage ?: "Transaksi gagal.")
                                    }
                                }
                            }
                        )
                    }

                    composable<RouteTransactions> {
                        TransactionsHistoryScreen(
                            user = userProfile,
                            transactionsState = transactionsState,
                            onOpenTransaction = { txId -> navController.navigate(RouteReceipt(txId)) },
                            onUpgradePremium = { navController.navigate(RoutePremium) },
                            onExportCsv = { uri ->
                                val ok = writeCsvToUri(context, uri, posVm.buildTransactionsCsv())
                                mainVm.showToast(if (ok) "Riwayat transaksi CSV diekspor." else "Gagal mengekspor CSV.")
                            }
                        )
                    }

                    composable<RouteReceipt> { entry ->
                        val args = entry.toRoute<RouteReceipt>()
                        val tx = transactionsList.find { it.id == args.transactionId }
                        if (tx == null) {
                            Box(
                                modifier = Modifier.fillMaxSize().padding(24.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Text("Memuat detail transaksi atau transaksi tidak ditemukan...")
                                    BrutalButton(text = "Kembali", onClick = { navController.popBackStack() })
                                }
                            }
                        } else {
                            ReceiptPreviewScreen(
                                user = userProfile,
                                transaction = tx,
                                items = selectedTxItems,
                                onLoadItems = { posVm.loadTransactionItems(tx.id) },
                                onBack = { navController.popBackStack() },
                                onShowMessage = mainVm::showToast
                            )
                        }
                    }

                    composable<RouteReports> {
                        ReportsScreen(
                            user = userProfile,
                            transactionsState = transactionsState,
                            products = productsList,
                            onUpgradePremium = { navController.navigate(RoutePremium) },
                            onExportCsv = { uri ->
                                val ok = writeCsvToUri(context, uri, posVm.buildTransactionsCsv())
                                mainVm.showToast(if (ok) "Laporan penjualan CSV diekspor." else "Gagal mengekspor laporan.")
                            }
                        )
                    }

                    composable<RouteTools> {
                        ToolsHubScreen(
                            user = userProfile,
                            apiSettings = apiSettings,
                            toolsHistory = toolsHistory,
                            toolState = toolState,
                            onRunGenerationAm = { email, key ->
                                supportToolsVm.runGenerationAmTool(apiSettings, email, key)
                            },
                            onRunVoteChannel = { email, link, key ->
                                supportToolsVm.runVoteChannelTool(apiSettings, email, link, key)
                            },
                            onRunFakeLobby = { game, nick, rank, players ->
                                supportToolsVm.runFakeLobbySimulation(game, nick, rank, players)
                            },
                            onClearToolState = supportToolsVm::clearToolState,
                            onUpgradePremium = { navController.navigate(RoutePremium) },
                            onShowMessage = mainVm::showToast
                        )
                    }

                    composable<RouteAiCs> {
                        AiCustomerServiceScreen(
                            user = userProfile,
                            appSettings = appSettings,
                            apiSettings = apiSettings,
                            conversations = aiConversations,
                            activeConversationId = activeAiConvId,
                            messages = aiMessages,
                            aiState = aiState,
                            streamingText = aiStreamingText,
                            onSelectConversation = aiCsVm::selectConversation,
                            onSendQuestion = { q -> aiCsVm.sendQuestion(q, apiSettings) },
                            onClearError = aiCsVm::clearError,
                            onUpgradePremium = { navController.navigate(RoutePremium) }
                        )
                    }

                    composable<RoutePremium> {
                        PremiumScreen(
                            user = userProfile,
                            appSettings = appSettings,
                            requests = premiumRequests,
                            isSubmitting = isSupportSubmitting,
                            onSubmitRequest = { method, proof, note ->
                                supportToolsVm.submitPremiumRequest(
                                    userName = userProfile.name,
                                    userEmail = userProfile.email,
                                    amount = appSettings.premiumPrice,
                                    paymentMethod = method,
                                    proofUrl = proof,
                                    note = note
                                ) { res ->
                                    res.onSuccess {
                                        mainVm.showToast("Permintaan Premium dikirim! Menunggu verifikasi Admin.")
                                    }.onFailure {
                                        mainVm.showToast(it.localizedMessage ?: "Gagal mengirim permintaan Premium.")
                                    }
                                }
                            },
                            onUpdateProof = { reqId, proof, note ->
                                supportToolsVm.updatePendingProof(reqId, proof, note) { res ->
                                    res.onSuccess { mainVm.showToast("Bukti pembayaran diperbarui.") }
                                        .onFailure { mainVm.showToast(it.localizedMessage ?: "Gagal memperbarui bukti.") }
                                }
                            },
                            onShowMessage = mainVm::showToast
                        )
                    }

                    composable<RouteComplaints> {
                        ComplaintsScreen(
                            user = userProfile,
                            complaints = complaints,
                            messages = complaintMessages,
                            isSubmitting = isSupportSubmitting,
                            onCreateComplaint = { cat, title, detail, att ->
                                supportToolsVm.createComplaint(
                                    userName = userProfile.name,
                                    userEmail = userProfile.email,
                                    category = cat,
                                    title = title,
                                    detail = detail,
                                    attachmentUrl = att
                                ) { res ->
                                    res.onSuccess { mainVm.showToast("Komplain berhasil dikirim ke Admin.") }
                                        .onFailure { mainVm.showToast(it.localizedMessage ?: "Gagal mengirim komplain.") }
                                }
                            },
                            onOpenComplaint = { comp ->
                                supportToolsVm.observeComplaintThread(comp, isAdmin = userProfile.isAdminRole)
                            },
                            onSendReply = { comp, msg ->
                                supportToolsVm.sendComplaintReply(
                                    complaint = comp,
                                    senderName = userProfile.name,
                                    senderRole = if (userProfile.isAdminRole) "ADMIN" else "USER",
                                    message = msg
                                ) { res ->
                                    res.onFailure { mainVm.showToast(it.localizedMessage ?: "Gagal mengirim balasan.") }
                                }
                            },
                            onShowMessage = mainVm::showToast
                        )
                    }

                    composable<RouteNotifications> {
                        NotificationsScreen(
                            notifications = notifications,
                            onMarkRead = mainVm::markNotificationRead,
                            onMarkAllRead = mainVm::markAllNotificationsRead
                        )
                    }

                    composable<RouteProfile> {
                        Column(modifier = Modifier.fillMaxSize()) {
                            Box(modifier = Modifier.weight(1f)) {
                                ProfileSettingsScreen(
                                    user = userProfile,
                                    darkMode = userProfile.darkMode,
                                    isSaving = isSavingProfile,
                                    onToggleDarkMode = mainVm::toggleDarkMode,
                                    onSaveProfile = { name, storeName, storeAddr, storePhone, photo, logo ->
                                        mainVm.updateProfile(name, storeName, storeAddr, storePhone, photo, logo)
                                    },
                                    onOpenAdminPanel = { navController.navigate(RouteAdmin) },
                                    onSignOut = onSignOut,
                                    onShowMessage = mainVm::showToast
                                )
                            }
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp, vertical = 6.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                BrutalOutlinedButton(
                                    text = "Komplain",
                                    icon = Lucide.MessageSquareWarning,
                                    onClick = { navController.navigate(RouteComplaints) },
                                    modifier = Modifier.weight(1f),
                                    testTag = "profile_complaints_shortcut"
                                )
                                BrutalOutlinedButton(
                                    text = "Paket Premium",
                                    icon = Lucide.Crown,
                                    onClick = { navController.navigate(RoutePremium) },
                                    modifier = Modifier.weight(1f),
                                    testTag = "profile_premium_shortcut"
                                )
                            }
                        }
                    }

                    composable<RouteAdmin> {
                        if (!userProfile.isAdminRole) {
                            Box(
                                modifier = Modifier.fillMaxSize().padding(24.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                ErrorBannerCard(
                                    message = "Akses ditolak. Halaman ini khusus Owner / Admin terverifikasi.",
                                    onRetry = { navController.popBackStack() }
                                )
                            }
                        } else {
                            AdminSectionHost(
                                adminUser = userProfile,
                                appSettings = appSettings,
                                apiSettings = apiSettings,
                                supportToolsVm = supportToolsVm,
                                onBackToUserMode = { navController.popBackStack() },
                                onShowMessage = mainVm::showToast
                            )
                        }
                    }
                }
            }
        }
    }

    if (showMobileMenuSheet) {
        ModalBottomSheet(
            onDismissRequest = { showMobileMenuSheet = false },
            containerColor = MaterialTheme.colorScheme.surface,
            shape = MaterialTheme.shapes.large
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .windowInsetsPadding(WindowInsets.navigationBars),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("Menu Fitur NEXORA POS", style = MaterialTheme.typography.titleLarge)
                val sheetItems = buildList {
                    add(NavTabItem("Transaksi & Riwayat", Lucide.Receipt, RouteTransactions, "sheet_tx"))
                    add(NavTabItem("Laporan Bisnis", Lucide.ChartNoAxesCombined, RouteReports, "sheet_reports"))
                    add(NavTabItem("Tools Premium", Lucide.Wrench, RouteTools, "sheet_tools"))
                    add(NavTabItem("AI Customer Service", Lucide.Bot, RouteAiCs, "sheet_aics"))
                    add(NavTabItem("Paket Premium", Lucide.Crown, RoutePremium, "sheet_premium"))
                    add(NavTabItem("Komplain & Bantuan", Lucide.MessageSquareWarning, RouteComplaints, "sheet_complaints"))
                    if (userProfile.isAdminRole) {
                        add(NavTabItem("Admin Panel", Lucide.ShieldCheck, RouteAdmin, "sheet_admin"))
                    }
                }
                sheetItems.forEach { item ->
                    BrutalCard(
                        onClick = {
                            showMobileMenuSheet = false
                            navController.navigate(item.route) { launchSingleTop = true }
                        },
                        contentPadding = 12.dp,
                        modifier = Modifier.testTag(item.testTag)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            LucideIcon(item.icon, contentDescription = item.label, tint = MaterialTheme.colorScheme.brutalAccentText, modifier = Modifier.size(20.dp))
                            Text(item.label, style = MaterialTheme.typography.titleMedium)
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
            }
        }
    }
}

@Composable
private fun AdminSectionHost(
    adminUser: UserProfile,
    appSettings: com.example.model.AppSettings,
    apiSettings: com.example.model.ApiSettings,
    supportToolsVm: SupportToolsViewModel,
    onBackToUserMode: () -> Unit,
    onShowMessage: (String) -> Unit
) {
    val adminVm: AdminViewModel = viewModel(
        key = "admin_${adminUser.userId}",
        factory = viewModelFactory {
            initializer {
                val app = this[APPLICATION_KEY]!!
                AdminViewModel(
                    authRepo = AuthUserRepository(app),
                    inventoryRepo = InventoryRepository(app),
                    posRepo = PosRepository(app),
                    supportRepo = SupportPremiumRepository(app)
                )
            }
        }
    )

    val allUsers by adminVm.allUsers.collectAsStateWithLifecycle()
    val allRequests by adminVm.allRequests.collectAsStateWithLifecycle()
    val premiumHistory by adminVm.premiumHistory.collectAsStateWithLifecycle()
    val allProducts by adminVm.allProducts.collectAsStateWithLifecycle()
    val allTransactions by adminVm.allTransactions.collectAsStateWithLifecycle()
    val allComplaints by adminVm.allComplaints.collectAsStateWithLifecycle()
    val auditLogs by adminVm.auditLogs.collectAsStateWithLifecycle()
    val isBusy by adminVm.isBusy.collectAsStateWithLifecycle()

    AdminDashboardScreen(
        adminUser = adminUser,
        allUsers = allUsers,
        allRequests = allRequests,
        premiumHistory = premiumHistory,
        allProducts = allProducts,
        allTransactions = allTransactions,
        allComplaints = allComplaints,
        auditLogs = auditLogs,
        appSettings = appSettings,
        apiSettings = apiSettings,
        isBusy = isBusy,
        onBackToUserMode = onBackToUserMode,
        onApprovePremium = { req -> adminVm.approvePremium(req, onShowMessage) },
        onRejectPremium = { req, reason -> adminVm.rejectPremium(req, reason, onShowMessage) },
        onUpdateUserStatus = { uid, role, acc, prem, pType ->
            adminVm.updateUserStatus(uid, role, acc, prem, pType, onShowMessage)
        },
        onReplyComplaint = { comp, reply, newStatus, rejReason ->
            supportToolsVm.sendComplaintReply(
                complaint = comp,
                senderName = adminUser.name.ifBlank { "Admin NEXORA" },
                senderRole = "ADMIN",
                message = reply,
                newStatus = newStatus,
                rejectionReason = rejReason
            ) { res ->
                res.onSuccess { onShowMessage("Tanggapan komplain dikirim.") }
                    .onFailure { onShowMessage(it.localizedMessage ?: "Gagal menanggapi komplain.") }
            }
        },
        onSaveAppSettings = { settings -> adminVm.saveAppSettings(settings, onShowMessage) },
        onSaveApiSettings = { settings -> adminVm.saveApiSettings(settings, onShowMessage) },
        onBroadcastAnnouncement = { title, body -> adminVm.broadcastAnnouncement(title, body, onShowMessage) }
    )
}

private fun writeCsvToUri(context: Context, uri: Uri, content: String): Boolean {
    return try {
        context.contentResolver.openOutputStream(uri)?.use { stream ->
            stream.write(content.toByteArray(Charsets.UTF_8))
        }
        true
    } catch (_: Exception) {
        false
    }
}
