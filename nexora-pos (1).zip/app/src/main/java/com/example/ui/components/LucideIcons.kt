package com.example.ui.components

import androidx.annotation.DrawableRes
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalContentColor
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import com.composables.icons.lucide.R as LucideR

/**
 * Central Lucide icon registry backed by com.composables:icons-lucide-android.
 * Every icon renders with consistent 2dp stroke width from the Lucide vector set.
 */
object Lucide {
    @DrawableRes val ArrowLeft: Int = LucideR.drawable.lucide_ic_arrow_left
    @DrawableRes val Ban: Int = LucideR.drawable.lucide_ic_ban
    @DrawableRes val Banknote: Int = LucideR.drawable.lucide_ic_banknote
    @DrawableRes val Barcode: Int = LucideR.drawable.lucide_ic_barcode
    @DrawableRes val Bell: Int = LucideR.drawable.lucide_ic_bell
    @DrawableRes val Bot: Int = LucideR.drawable.lucide_ic_bot
    @DrawableRes val Boxes: Int = LucideR.drawable.lucide_ic_boxes
    @DrawableRes val CalendarDays: Int = LucideR.drawable.lucide_ic_calendar_days
    @DrawableRes val Camera: Int = LucideR.drawable.lucide_ic_camera
    @DrawableRes val ChartNoAxesCombined: Int = LucideR.drawable.lucide_ic_chart_no_axes_combined
    @DrawableRes val CheckCheck: Int = LucideR.drawable.lucide_ic_check_check
    @DrawableRes val CircleCheck: Int = LucideR.drawable.lucide_ic_circle_check
    @DrawableRes val CircleX: Int = LucideR.drawable.lucide_ic_circle_x
    @DrawableRes val Clock: Int = LucideR.drawable.lucide_ic_clock
    @DrawableRes val Copy: Int = LucideR.drawable.lucide_ic_copy
    @DrawableRes val Crown: Int = LucideR.drawable.lucide_ic_crown
    @DrawableRes val Download: Int = LucideR.drawable.lucide_ic_download
    @DrawableRes val FileText: Int = LucideR.drawable.lucide_ic_file_text
    @DrawableRes val Gamepad2: Int = LucideR.drawable.lucide_ic_gamepad_2
    @DrawableRes val Heart: Int = LucideR.drawable.lucide_ic_heart
    @DrawableRes val History: Int = LucideR.drawable.lucide_ic_history
    @DrawableRes val Inbox: Int = LucideR.drawable.lucide_ic_inbox
    @DrawableRes val LayoutDashboard: Int = LucideR.drawable.lucide_ic_layout_dashboard
    @DrawableRes val ListFilter: Int = LucideR.drawable.lucide_ic_list_filter
    @DrawableRes val Lock: Int = LucideR.drawable.lucide_ic_lock
    @DrawableRes val LogIn: Int = LucideR.drawable.lucide_ic_log_in
    @DrawableRes val LogOut: Int = LucideR.drawable.lucide_ic_log_out
    @DrawableRes val Menu: Int = LucideR.drawable.lucide_ic_menu
    @DrawableRes val MessageCircle: Int = LucideR.drawable.lucide_ic_message_circle
    @DrawableRes val MessageSquareWarning: Int = LucideR.drawable.lucide_ic_message_square_warning
    @DrawableRes val Minus: Int = LucideR.drawable.lucide_ic_minus
    @DrawableRes val Moon: Int = LucideR.drawable.lucide_ic_moon
    @DrawableRes val Package: Int = LucideR.drawable.lucide_ic_package
    @DrawableRes val PackagePlus: Int = LucideR.drawable.lucide_ic_package_plus
    @DrawableRes val Pencil: Int = LucideR.drawable.lucide_ic_pencil
    @DrawableRes val Plus: Int = LucideR.drawable.lucide_ic_plus
    @DrawableRes val Printer: Int = LucideR.drawable.lucide_ic_printer
    @DrawableRes val QrCode: Int = LucideR.drawable.lucide_ic_qr_code
    @DrawableRes val Receipt: Int = LucideR.drawable.lucide_ic_receipt
    @DrawableRes val ScanLine: Int = LucideR.drawable.lucide_ic_scan_line
    @DrawableRes val Search: Int = LucideR.drawable.lucide_ic_search
    @DrawableRes val Send: Int = LucideR.drawable.lucide_ic_send
    @DrawableRes val Settings: Int = LucideR.drawable.lucide_ic_settings
    @DrawableRes val ShieldCheck: Int = LucideR.drawable.lucide_ic_shield_check
    @DrawableRes val ShoppingCart: Int = LucideR.drawable.lucide_ic_shopping_cart
    @DrawableRes val Sparkles: Int = LucideR.drawable.lucide_ic_sparkles
    @DrawableRes val Store: Int = LucideR.drawable.lucide_ic_store
    @DrawableRes val Sun: Int = LucideR.drawable.lucide_ic_sun
    @DrawableRes val Trash2: Int = LucideR.drawable.lucide_ic_trash_2
    @DrawableRes val TrendingUp: Int = LucideR.drawable.lucide_ic_trending_up
    @DrawableRes val Upload: Int = LucideR.drawable.lucide_ic_upload
    @DrawableRes val UserPlus: Int = LucideR.drawable.lucide_ic_user_plus
    @DrawableRes val UserRound: Int = LucideR.drawable.lucide_ic_user_round
    @DrawableRes val Vote: Int = LucideR.drawable.lucide_ic_vote
    @DrawableRes val Wallet: Int = LucideR.drawable.lucide_ic_wallet
    @DrawableRes val Wrench: Int = LucideR.drawable.lucide_ic_wrench
    @DrawableRes val X: Int = LucideR.drawable.lucide_ic_x
}

@Composable
fun LucideIcon(
    @DrawableRes icon: Int,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    tint: Color = LocalContentColor.current,
) {
    Icon(
        painter = painterResource(id = icon),
        contentDescription = contentDescription,
        modifier = modifier,
        tint = tint,
    )
}
