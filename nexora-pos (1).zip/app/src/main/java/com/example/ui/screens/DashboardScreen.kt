package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.annotation.DrawableRes
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.core.DateFormatter
import com.example.core.RupiahFormatter
import com.example.model.AppSettings
import com.example.model.PosTransaction
import com.example.model.Product
import com.example.model.UiState
import com.example.model.UserProfile
import com.example.ui.components.BrutalBadge
import com.example.ui.components.BrutalCard
import com.example.ui.components.BrutalStatCard
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.ErrorBannerCard
import com.example.ui.components.Lucide
import com.example.ui.components.LucideIcon
import com.example.ui.components.SkeletonBox
import com.example.ui.components.StatusBadge
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.BrutalBlack
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.PrimaryYellow
import com.example.ui.theme.SecondaryYellow
import com.example.ui.theme.brutalAccentText
import com.example.ui.theme.brutalHighlightBorder
import com.example.ui.theme.isDarkBrutal

@Composable
fun DashboardScreen(
    user: UserProfile,
    appSettings: AppSettings,
    productsState: UiState<List<Product>>,
    transactionsState: UiState<List<PosTransaction>>,
    onOpenScanner: () -> Unit,
    onOpenAddProduct: () -> Unit,
    onOpenPos: () -> Unit,
    onOpenPremium: () -> Unit,
    onOpenProductDetail: (String) -> Unit,
    onOpenTransactionDetail: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val products = (productsState as? UiState.Success)?.data ?: emptyList()
    val transactions = (transactionsState as? UiState.Success)?.data ?: emptyList()

    val paidTxs = remember(transactions) { transactions.filter { it.paymentStatus != "CANCELLED" } }
    val totalSales = remember(paidTxs) { paidTxs.sumOf { it.total } }
    val totalProfit = remember(paidTxs) { paidTxs.sumOf { it.totalProfit } }
    val lowStockProducts = remember(products) { products.filter { it.stock <= it.lowStockThreshold }.sortedBy { it.stock } }
    val recentProducts = remember(products) { products.take(4) }
    val recentTxs = remember(paidTxs) { paidTxs.take(5) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .widthIn(max = 960.dp),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        if (appSettings.announcement.isNotBlank()) {
            item {
                BrutalCard(
                    borderColor = MaterialTheme.colorScheme.brutalHighlightBorder,
                    borderWidth = 1.5.dp
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        LucideIcon(Lucide.Bell, contentDescription = null, tint = MaterialTheme.colorScheme.brutalAccentText, modifier = Modifier.size(18.dp))
                        Column {
                            Text("Pengumuman Admin", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.brutalAccentText)
                            Text(appSettings.announcement, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }
        }

        // 1. Header & Greeting + Status Paket
        item {
            BrutalCard(borderColor = MaterialTheme.colorScheme.outline, borderWidth = 1.5.dp) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            LucideIcon(Lucide.LayoutDashboard, contentDescription = null, tint = MaterialTheme.colorScheme.brutalAccentText, modifier = Modifier.size(16.dp))
                            Text(
                                "Ringkasan Bisnis",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Spacer(Modifier.height(2.dp))
                        Text(
                            user.name.ifBlank { "Pemilik Bisnis" },
                            style = MaterialTheme.typography.headlineMedium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        if (user.storeName.isNotBlank()) {
                            Text(
                                user.storeName,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.brutalAccentText
                            )
                        }
                    }
                    BrutalBadge(
                        text = if (user.isPremiumActive) "PREMIUM LIFETIME" else "PAKET FREE",
                        icon = if (user.isPremiumActive) Lucide.Crown else Lucide.Package,
                        containerColor = if (user.isPremiumActive) EmeraldSuccess.copy(alpha = 0.14f) else PrimaryYellow,
                        contentColor = if (user.isPremiumActive) EmeraldSuccess else BrutalBlack
                    )
                }
            }
        }

        // 2. Quick Actions
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    QuickActionTile(
                        title = "Scan QR",
                        icon = Lucide.ScanLine,
                        accent = PrimaryYellow,
                        onClick = onOpenScanner,
                        testTag = "dash_scan_button",
                        modifier = Modifier.weight(1f)
                    )
                    QuickActionTile(
                        title = "Tambah Produk",
                        icon = Lucide.PackagePlus,
                        accent = SecondaryYellow,
                        onClick = onOpenAddProduct,
                        testTag = "dash_add_product_button",
                        modifier = Modifier.weight(1f)
                    )
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    QuickActionTile(
                        title = "Kasir POS",
                        icon = Lucide.ShoppingCart,
                        accent = EmeraldSuccess,
                        onClick = onOpenPos,
                        testTag = "dash_pos_button",
                        modifier = Modifier.weight(1f)
                    )
                    QuickActionTile(
                        title = if (user.isPremiumActive) "Status Premium" else "Upgrade Premium",
                        icon = Lucide.Crown,
                        accent = PrimaryYellow,
                        onClick = onOpenPremium,
                        testTag = "dash_premium_button",
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // 3. KPI Metrics (Produk, Transaksi, Penjualan, Keuntungan)
        item {
            if (productsState is UiState.Loading || transactionsState is UiState.Loading) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        SkeletonBox(modifier = Modifier.weight(1f), height = 96.dp)
                        SkeletonBox(modifier = Modifier.weight(1f), height = 96.dp)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        SkeletonBox(modifier = Modifier.weight(1f), height = 96.dp)
                        SkeletonBox(modifier = Modifier.weight(1f), height = 96.dp)
                    }
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (productsState is UiState.Error) {
                        ErrorBannerCard(message = productsState.message)
                    }
                    if (transactionsState is UiState.Error) {
                        ErrorBannerCard(message = transactionsState.message)
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        BrutalStatCard(
                            title = "Total Produk",
                            value = "${products.size}",
                            icon = Lucide.Package,
                            accentColor = PrimaryYellow,
                            subtitle = "${lowStockProducts.size} stok menipis",
                            modifier = Modifier.weight(1f)
                        )
                        BrutalStatCard(
                            title = "Total Transaksi",
                            value = "${paidTxs.size}",
                            icon = Lucide.Receipt,
                            accentColor = SecondaryYellow,
                            subtitle = "Transaksi lunas",
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        BrutalStatCard(
                            title = "Total Penjualan",
                            value = RupiahFormatter.format(totalSales),
                            icon = Lucide.Banknote,
                            accentColor = EmeraldSuccess,
                            modifier = Modifier.weight(1f)
                        )
                        BrutalStatCard(
                            title = "Total Keuntungan",
                            value = RupiahFormatter.format(totalProfit),
                            icon = Lucide.TrendingUp,
                            accentColor = AmberWarning,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        // 4. Sales Chart
        item {
            BrutalCard {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        LucideIcon(Lucide.ChartNoAxesCombined, contentDescription = null, tint = MaterialTheme.colorScheme.brutalAccentText, modifier = Modifier.size(20.dp))
                        Text("Grafik Penjualan Terbaru", style = MaterialTheme.typography.titleLarge)
                    }
                    val chartData = remember(paidTxs) {
                        paidTxs.take(7).reversed()
                    }
                    if (chartData.isEmpty()) {
                        Text(
                            "Belum ada data transaksi penjualan untuk ditampilkan di grafik.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        val maxVal = (chartData.maxOfOrNull { it.total } ?: 1.0).coerceAtLeast(1.0)
                        val isDark = MaterialTheme.colorScheme.isDarkBrutal
                        Canvas(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(150.dp)
                                .padding(top = 8.dp)
                        ) {
                            val barCount = chartData.size
                            val slotWidth = size.width / barCount.coerceAtLeast(1)
                            val barWidth = (slotWidth * 0.54f).coerceAtMost(44f)
                            chartData.forEachIndexed { idx, tx ->
                                val ratio = (tx.total / maxVal).toFloat().coerceIn(0.06f, 1f)
                                val barHeight = size.height * ratio
                                val x = idx * slotWidth + (slotWidth - barWidth) / 2f
                                val y = size.height - barHeight
                                drawRoundRect(
                                    color = if (idx == barCount - 1) PrimaryYellow else if (isDark) SecondaryYellow.copy(alpha = 0.55f) else BrutalBlack,
                                    topLeft = Offset(x, y),
                                    size = Size(barWidth, barHeight),
                                    cornerRadius = CornerRadius(4f, 4f)
                                )
                            }
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            chartData.forEach { tx ->
                                Text(
                                    DateFormatter.formatShort(tx.createdAt),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }

        // 5. Low Stock Alert
        item {
            BrutalCard(borderColor = if (lowStockProducts.isNotEmpty()) AmberWarning else MaterialTheme.colorScheme.outlineVariant) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        LucideIcon(Lucide.Boxes, contentDescription = null, tint = AmberWarning, modifier = Modifier.size(20.dp))
                        Text("Produk Stok Menipis (${lowStockProducts.size})", style = MaterialTheme.typography.titleLarge)
                    }
                    if (lowStockProducts.isEmpty()) {
                        Text(
                            "Semua stok produk berada dalam batas aman.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        lowStockProducts.take(5).forEach { prod ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onOpenProductDetail(prod.id) }
                                    .padding(vertical = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(prod.name, style = MaterialTheme.typography.titleMedium)
                                    Text("SKU: ${prod.sku}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                StatusBadge(if (prod.outOfStock) "HABIS" else "SISA ${prod.stock}")
                            }
                        }
                    }
                }
            }
        }

        // 6. Latest Products
        item {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                LucideIcon(Lucide.Package, contentDescription = null, tint = MaterialTheme.colorScheme.brutalAccentText, modifier = Modifier.size(18.dp))
                Text("Produk Terbaru", style = MaterialTheme.typography.titleLarge)
            }
        }
        item {
            if (recentProducts.isEmpty()) {
                EmptyStateCard(
                    title = "Belum Ada Produk",
                    subtitle = "Tambahkan produk pertama Anda untuk mulai mengelola stok dan kasir.",
                    icon = Lucide.Package,
                    actionText = "Tambah Produk",
                    onAction = onOpenAddProduct
                )
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    recentProducts.forEach { prod ->
                        BrutalCard(onClick = { onOpenProductDetail(prod.id) }) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(prod.name, style = MaterialTheme.typography.titleMedium)
                                    Text("${prod.category} | Stok: ${prod.stock} ${prod.unit}", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Text(
                                    RupiahFormatter.format(prod.sellPrice),
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.brutalAccentText
                                )
                            }
                        }
                    }
                }
            }
        }

        // 7. Latest Transactions
        item {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                LucideIcon(Lucide.History, contentDescription = null, tint = MaterialTheme.colorScheme.brutalAccentText, modifier = Modifier.size(18.dp))
                Text("Transaksi Terbaru", style = MaterialTheme.typography.titleLarge)
            }
        }
        item {
            if (recentTxs.isEmpty()) {
                EmptyStateCard(
                    title = "Belum Ada Transaksi",
                    subtitle = if (user.isPremiumActive) "Catat transaksi pertama Anda melalui Kasir POS." else "Transaksi Kasir POS tersedia di paket Premium Lifetime.",
                    icon = Lucide.Receipt,
                    actionText = if (user.isPremiumActive) "Buka Kasir POS" else "Lihat Premium",
                    onAction = if (user.isPremiumActive) onOpenPos else onOpenPremium
                )
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    recentTxs.forEach { tx ->
                        BrutalCard(onClick = { onOpenTransactionDetail(tx.id) }) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("#${tx.id.take(8)} - ${tx.paymentMethod}", style = MaterialTheme.typography.titleMedium)
                                    Text(tx.itemsSummary, style = MaterialTheme.typography.bodyMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(DateFormatter.format(tx.createdAt), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(RupiahFormatter.format(tx.total), style = MaterialTheme.typography.titleMedium, color = EmeraldSuccess)
                                    Spacer(Modifier.height(4.dp))
                                    StatusBadge(tx.paymentStatus)
                                }
                            }
                        }
                    }
                }
            }
        }

        item { Spacer(Modifier.height(72.dp)) }
    }
}

@Composable
private fun QuickActionTile(
    title: String,
    @DrawableRes icon: Int,
    accent: Color,
    onClick: () -> Unit,
    testTag: String,
    modifier: Modifier = Modifier
) {
    val isYellow = accent == PrimaryYellow || accent == SecondaryYellow
    BrutalCard(
        modifier = modifier.testTag(testTag),
        borderColor = MaterialTheme.colorScheme.outlineVariant,
        onClick = onClick,
        contentPadding = 12.dp
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(if (isYellow) accent else accent.copy(alpha = 0.14f))
                    .border(1.5.dp, if (isYellow) BrutalBlack else accent, RoundedCornerShape(4.dp)),
                contentAlignment = Alignment.Center
            ) {
                LucideIcon(
                    icon,
                    contentDescription = title,
                    tint = if (isYellow) BrutalBlack else accent,
                    modifier = Modifier.size(18.dp)
                )
            }
            Text(title, style = MaterialTheme.typography.labelLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}
