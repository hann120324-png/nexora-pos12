package com.example.ui.components

import android.graphics.Bitmap
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.annotation.DrawableRes
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.PlainTooltip
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TooltipBox
import androidx.compose.material3.TooltipDefaults
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.material3.rememberTooltipState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.core.ImageEncodingHelper
import com.example.core.WhatsAppHelper
import com.example.model.UserProfile
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.BrutalBlack
import com.example.ui.theme.BrutalWhite
import com.example.ui.theme.CrimsonError
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.PrimaryYellow
import com.example.ui.theme.SecondaryYellow
import com.example.ui.theme.WhatsAppGreen
import com.example.ui.theme.brutalHighlightBorder
import com.example.ui.theme.isDarkBrutal

@Composable
fun BrutalCard(
    modifier: Modifier = Modifier,
    containerColor: Color = MaterialTheme.colorScheme.surface,
    borderColor: Color = MaterialTheme.colorScheme.outlineVariant,
    borderWidth: Dp = 1.5.dp,
    onClick: (() -> Unit)? = null,
    contentPadding: Dp = 16.dp,
    content: @Composable ColumnScope.() -> Unit
) {
    Surface(
        modifier = modifier.then(
            if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier
        ),
        shape = MaterialTheme.shapes.medium,
        color = containerColor,
        border = BorderStroke(borderWidth, borderColor),
        shadowElevation = 0.dp,
    ) {
        Column(
            modifier = Modifier.padding(contentPadding),
            content = content
        )
    }
}

@Composable
fun BrutalStatCard(
    title: String,
    value: String,
    @DrawableRes icon: Int,
    modifier: Modifier = Modifier,
    accentColor: Color = PrimaryYellow,
    subtitle: String? = null,
    onClick: (() -> Unit)? = null
) {
    val isYellowAccent = accentColor == PrimaryYellow || accentColor == SecondaryYellow
    BrutalCard(
        modifier = modifier,
        onClick = onClick,
        contentPadding = 14.dp
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(if (isYellowAccent) accentColor else accentColor.copy(alpha = 0.14f))
                    .border(
                        1.5.dp,
                        if (isYellowAccent) BrutalBlack else accentColor.copy(alpha = 0.65f),
                        RoundedCornerShape(4.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                LucideIcon(
                    icon = icon,
                    contentDescription = title,
                    tint = if (isYellowAccent) BrutalBlack else accentColor,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
        Spacer(Modifier.height(10.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.onSurface,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        if (!subtitle.isNullOrBlank()) {
            Spacer(Modifier.height(2.dp))
            Text(
                text = subtitle,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun BrutalButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    @DrawableRes icon: Int? = null,
    enabled: Boolean = true,
    containerColor: Color = PrimaryYellow,
    contentColor: Color = BrutalBlack,
    borderColor: Color = MaterialTheme.colorScheme.brutalHighlightBorder,
    testTag: String? = null,
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier
            .minimumInteractiveComponentSize()
            .height(48.dp)
            .then(if (testTag != null) Modifier.testTag(testTag) else Modifier),
        shape = MaterialTheme.shapes.small,
        border = BorderStroke(1.5.dp, if (enabled) borderColor else MaterialTheme.colorScheme.outlineVariant),
        colors = ButtonDefaults.buttonColors(
            containerColor = containerColor,
            contentColor = contentColor,
            disabledContainerColor = MaterialTheme.colorScheme.surfaceVariant,
            disabledContentColor = MaterialTheme.colorScheme.onSurfaceVariant
        ),
        elevation = ButtonDefaults.buttonElevation(defaultElevation = 0.dp, pressedElevation = 0.dp),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp)
    ) {
        if (icon != null) {
            LucideIcon(icon, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
        }
        Text(
            text = text,
            style = MaterialTheme.typography.labelLarge,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun BrutalOutlinedButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    @DrawableRes icon: Int? = null,
    enabled: Boolean = true,
    borderColor: Color = MaterialTheme.colorScheme.outline,
    contentColor: Color = MaterialTheme.colorScheme.onSurface,
    containerColor: Color = MaterialTheme.colorScheme.surface,
    testTag: String? = null,
) {
    OutlinedButton(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier
            .minimumInteractiveComponentSize()
            .height(48.dp)
            .then(if (testTag != null) Modifier.testTag(testTag) else Modifier),
        shape = MaterialTheme.shapes.small,
        border = BorderStroke(1.5.dp, if (enabled) borderColor else MaterialTheme.colorScheme.outlineVariant),
        colors = ButtonDefaults.outlinedButtonColors(
            containerColor = containerColor,
            contentColor = contentColor
        ),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp)
    ) {
        if (icon != null) {
            LucideIcon(icon, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
        }
        Text(
            text = text,
            style = MaterialTheme.typography.labelLarge,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun BrutalDangerButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    @DrawableRes icon: Int? = null,
    enabled: Boolean = true,
    testTag: String? = null,
) {
    BrutalButton(
        text = text,
        onClick = onClick,
        modifier = modifier,
        icon = icon,
        enabled = enabled,
        containerColor = CrimsonError,
        contentColor = BrutalWhite,
        borderColor = BrutalBlack,
        testTag = testTag
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BrutalIconButton(
    @DrawableRes icon: Int,
    contentDescription: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    tint: Color = MaterialTheme.colorScheme.onSurface,
    borderColor: Color = MaterialTheme.colorScheme.outlineVariant,
    containerColor: Color = MaterialTheme.colorScheme.surface,
    enabled: Boolean = true,
    testTag: String? = null
) {
    TooltipBox(
        positionProvider = TooltipDefaults.rememberPlainTooltipPositionProvider(),
        tooltip = { PlainTooltip { Text(contentDescription) } },
        state = rememberTooltipState()
    ) {
        Surface(
            onClick = onClick,
            enabled = enabled,
            shape = MaterialTheme.shapes.small,
            color = containerColor,
            border = BorderStroke(1.5.dp, borderColor),
            modifier = modifier
                .minimumInteractiveComponentSize()
                .size(40.dp)
                .then(if (testTag != null) Modifier.testTag(testTag) else Modifier)
        ) {
            Box(contentAlignment = Alignment.Center) {
                LucideIcon(
                    icon = icon,
                    contentDescription = contentDescription,
                    tint = if (enabled) tint else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

@Composable
fun BrutalSectionHeader(
    title: String,
    @DrawableRes icon: Int? = null,
    subtitle: String? = null,
    modifier: Modifier = Modifier,
    trailing: (@Composable () -> Unit)? = null
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            modifier = Modifier.weight(1f),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (icon != null) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(PrimaryYellow)
                        .border(1.5.dp, BrutalBlack, RoundedCornerShape(4.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    LucideIcon(icon, contentDescription = null, tint = BrutalBlack, modifier = Modifier.size(20.dp))
                }
            }
            Column {
                Text(title, style = MaterialTheme.typography.headlineMedium)
                if (!subtitle.isNullOrBlank()) {
                    Text(
                        subtitle,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
        if (trailing != null) {
            Spacer(Modifier.width(8.dp))
            trailing()
        }
    }
}

@Composable
fun BrutalBadge(
    text: String,
    containerColor: Color = PrimaryYellow,
    contentColor: Color = BrutalBlack,
    @DrawableRes icon: Int? = null,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(4.dp))
            .background(containerColor)
            .border(1.dp, contentColor, RoundedCornerShape(4.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        if (icon != null) {
            LucideIcon(icon, contentDescription = null, tint = contentColor, modifier = Modifier.size(13.dp))
        }
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
            color = contentColor,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun StatusBadge(status: String) {
    val upper = status.uppercase()
    val (bg, fg, icon) = when (upper) {
        "ACTIVE", "APPROVED", "PAID", "RESOLVED", "SUCCESS" ->
            Triple(EmeraldSuccess.copy(alpha = 0.12f), EmeraldSuccess, Lucide.CircleCheck)
        "PENDING", "IN_PROGRESS", "SIMULATION" ->
            Triple(PrimaryYellow, BrutalBlack, Lucide.Clock)
        "REJECTED", "FAILED", "DISABLED", "CANCELLED", "EXPIRED", "ERROR", "HABIS" ->
            Triple(CrimsonError.copy(alpha = 0.12f), CrimsonError, Lucide.CircleX)
        else ->
            Triple(PrimaryYellow, BrutalBlack, null)
    }
    BrutalBadge(text = upper, containerColor = bg, contentColor = fg, icon = icon)
}

@Composable
fun BrutalTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    placeholder: String = "",
    @DrawableRes leadingIcon: Int? = null,
    singleLine: Boolean = true,
    maxLines: Int = if (singleLine) 1 else 5,
    keyboardOptions: KeyboardOptions = KeyboardOptions.Default,
    visualTransformation: VisualTransformation = VisualTransformation.None,
    enabled: Boolean = true,
    isError: Boolean = false,
    helperText: String? = null,
    testTag: String? = null
) {
    Column(modifier = modifier.fillMaxWidth()) {
        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            label = { Text(label) },
            placeholder = if (placeholder.isNotBlank()) ({ Text(placeholder) }) else null,
            leadingIcon = leadingIcon?.let {
                { LucideIcon(it, contentDescription = null, modifier = Modifier.size(18.dp)) }
            },
            singleLine = singleLine,
            maxLines = maxLines,
            enabled = enabled,
            isError = isError,
            supportingText = if (!helperText.isNullOrBlank()) ({ Text(helperText) }) else null,
            keyboardOptions = keyboardOptions,
            visualTransformation = visualTransformation,
            shape = MaterialTheme.shapes.small,
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = if (MaterialTheme.colorScheme.isDarkBrutal) PrimaryYellow else BrutalBlack,
                focusedLabelColor = MaterialTheme.colorScheme.onSurface,
                cursorColor = MaterialTheme.colorScheme.onSurface,
                unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant,
                errorBorderColor = CrimsonError,
                focusedContainerColor = MaterialTheme.colorScheme.surface,
                unfocusedContainerColor = MaterialTheme.colorScheme.surface
            ),
            modifier = Modifier
                .fillMaxWidth()
                .then(if (testTag != null) Modifier.testTag(testTag) else Modifier)
        )
    }
}

@Composable
fun SkeletonBox(
    modifier: Modifier = Modifier,
    height: Dp = 80.dp
) {
    val transition = rememberInfiniteTransition(label = "skeleton")
    val alpha by transition.animateFloat(
        initialValue = 0.35f,
        targetValue = 0.70f,
        animationSpec = infiniteRepeatable(tween(800), RepeatMode.Reverse),
        label = "skeletonAlpha"
    )
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(height)
            .clip(MaterialTheme.shapes.medium)
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, MaterialTheme.shapes.medium)
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = alpha))
    )
}

@Composable
fun EmptyStateCard(
    title: String,
    subtitle: String,
    @DrawableRes icon: Int = Lucide.Inbox,
    actionText: String? = null,
    onAction: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    BrutalCard(modifier = modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(52.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(PrimaryYellow)
                    .border(1.5.dp, BrutalBlack, RoundedCornerShape(6.dp)),
                contentAlignment = Alignment.Center
            ) {
                LucideIcon(icon, contentDescription = null, tint = BrutalBlack, modifier = Modifier.size(24.dp))
            }
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(
                subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (actionText != null && onAction != null) {
                Spacer(Modifier.height(4.dp))
                BrutalButton(text = actionText, onClick = onAction, testTag = "empty_action_button")
            }
        }
    }
}

@Composable
fun ErrorBannerCard(
    message: String,
    onRetry: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    BrutalCard(
        modifier = modifier.fillMaxWidth(),
        containerColor = CrimsonError.copy(alpha = 0.08f),
        borderColor = CrimsonError
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            LucideIcon(Lucide.CircleX, contentDescription = "Error", tint = CrimsonError, modifier = Modifier.size(20.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text("Terjadi Kendala", style = MaterialTheme.typography.titleMedium, color = CrimsonError)
                Text(message, style = MaterialTheme.typography.bodyMedium)
            }
            if (onRetry != null) {
                TextButton(onClick = onRetry) { Text("Coba Lagi") }
            }
        }
    }
}

@Composable
fun PremiumGateCard(
    featureName: String,
    onUpgradeClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    BrutalCard(
        modifier = modifier.fillMaxWidth(),
        containerColor = MaterialTheme.colorScheme.surface,
        borderColor = MaterialTheme.colorScheme.brutalHighlightBorder,
        borderWidth = 2.dp
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(PrimaryYellow)
                        .border(1.5.dp, BrutalBlack, RoundedCornerShape(4.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    LucideIcon(Lucide.Lock, contentDescription = "Terkunci", tint = BrutalBlack, modifier = Modifier.size(18.dp))
                }
                Column {
                    BrutalBadge(text = "AKSES PREMIUM", icon = Lucide.Crown)
                    Spacer(Modifier.height(4.dp))
                    Text(featureName, style = MaterialTheme.typography.titleLarge)
                }
            }
            Text(
                "Fitur ini khusus pengguna Premium Lifetime. Upgrade sekali bayar untuk membuka Kasir POS, Cetak Struk 58mm/80mm, Laporan Laba, Tools Premium, dan AI Customer Service.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            BrutalButton(
                text = "Upgrade Premium Lifetime",
                icon = Lucide.Crown,
                onClick = onUpgradeClick,
                modifier = Modifier.fillMaxWidth(),
                testTag = "premium_gate_upgrade_button"
            )
        }
    }
}

@Composable
fun ConfirmDialog(
    title: String,
    message: String,
    confirmText: String = "Ya, Lanjutkan",
    dismissText: String = "Batal",
    isDanger: Boolean = false,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        shape = MaterialTheme.shapes.medium,
        onDismissRequest = onDismiss,
        title = { Text(title, style = MaterialTheme.typography.titleLarge) },
        text = { Text(message, style = MaterialTheme.typography.bodyMedium) },
        confirmButton = {
            if (isDanger) {
                BrutalDangerButton(text = confirmText, onClick = onConfirm, testTag = "confirm_dialog_yes")
            } else {
                BrutalButton(text = confirmText, onClick = onConfirm, testTag = "confirm_dialog_yes")
            }
        },
        dismissButton = {
            BrutalOutlinedButton(text = dismissText, onClick = onDismiss)
        }
    )
}

@Composable
fun StoredImage(
    imageSource: String?,
    contentDescription: String,
    modifier: Modifier = Modifier,
    @DrawableRes fallbackIcon: Int? = null
) {
    val bitmap: Bitmap? = remember(imageSource) {
        ImageEncodingHelper.decodeBase64DataUri(imageSource)
    }
    if (bitmap != null) {
        Image(
            bitmap = bitmap.asImageBitmap(),
            contentDescription = contentDescription,
            contentScale = ContentScale.Crop,
            modifier = modifier
        )
    } else if (!imageSource.isNullOrBlank() && imageSource.startsWith("http")) {
        AsyncImage(
            model = imageSource,
            contentDescription = contentDescription,
            contentScale = ContentScale.Crop,
            modifier = modifier
        )
    } else if (fallbackIcon != null) {
        Box(
            modifier = modifier
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(6.dp)),
            contentAlignment = Alignment.Center
        ) {
            LucideIcon(
                fallbackIcon,
                contentDescription = contentDescription,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(22.dp)
            )
        }
    }
}

@Composable
fun FloatingWhatsAppMenu(
    userProfile: UserProfile?,
    whatsappNumber: String,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var expanded by remember { mutableStateOf(false) }

    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.End,
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        AnimatedVisibility(visible = expanded) {
            Column(
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    shape = MaterialTheme.shapes.small,
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.outline),
                    shadowElevation = 2.dp,
                    modifier = Modifier
                        .clickable {
                            expanded = false
                            WhatsAppHelper.openComplaint(
                                context = context,
                                whatsappNumber = whatsappNumber,
                                name = userProfile?.name ?: "-",
                                email = userProfile?.email ?: "-",
                                uid = userProfile?.userId ?: "-"
                            )
                        }
                        .testTag("wa_complaint_button")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        LucideIcon(Lucide.MessageSquareWarning, contentDescription = null, tint = AmberWarning, modifier = Modifier.size(18.dp))
                        Text("Komplain Admin", style = MaterialTheme.typography.labelLarge)
                    }
                }
                Surface(
                    shape = MaterialTheme.shapes.small,
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.outline),
                    shadowElevation = 2.dp,
                    modifier = Modifier
                        .clickable {
                            expanded = false
                            WhatsAppHelper.openCs(
                                context = context,
                                whatsappNumber = whatsappNumber,
                                name = userProfile?.name ?: "-",
                                email = userProfile?.email ?: "-",
                                accountStatus = if (userProfile?.isPremiumActive == true) "Premium Lifetime" else "Free"
                            )
                        }
                        .testTag("wa_cs_button")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        LucideIcon(Lucide.Bot, contentDescription = null, tint = WhatsAppGreen, modifier = Modifier.size(18.dp))
                        Text("Hubungi CS", style = MaterialTheme.typography.labelLarge)
                    }
                }
            }
        }
        Surface(
            onClick = { expanded = !expanded },
            shape = MaterialTheme.shapes.small,
            color = WhatsAppGreen,
            contentColor = BrutalWhite,
            border = BorderStroke(1.5.dp, BrutalBlack),
            shadowElevation = 2.dp,
            modifier = Modifier
                .minimumInteractiveComponentSize()
                .size(48.dp)
                .testTag("wa_floating_toggle")
        ) {
            Box(contentAlignment = Alignment.Center) {
                LucideIcon(
                    icon = if (expanded) Lucide.X else Lucide.MessageCircle,
                    contentDescription = "Bantuan WhatsApp",
                    modifier = Modifier.size(22.dp)
                )
            }
        }
    }
}
