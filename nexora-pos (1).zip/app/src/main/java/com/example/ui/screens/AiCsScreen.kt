package com.example.ui.screens

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.core.WhatsAppHelper
import com.example.model.AiConversation
import com.example.model.AiMessage
import com.example.model.ApiSettings
import com.example.model.AppSettings
import com.example.model.UiState
import com.example.model.UserProfile
import com.example.ui.components.BrutalButton
import com.example.ui.components.BrutalCard
import com.example.ui.components.BrutalOutlinedButton
import com.example.ui.components.BrutalSectionHeader
import com.example.ui.components.BrutalTextField
import com.example.ui.components.ErrorBannerCard
import com.example.ui.components.Lucide
import com.example.ui.components.PremiumGateCard
import com.example.ui.theme.BrutalBlack
import com.example.ui.theme.BrutalWhite
import com.example.ui.theme.PrimaryYellow
import com.example.ui.theme.WhatsAppGreen
import com.example.ui.theme.brutalAccentText
import com.example.ui.theme.brutalHighlightBorder

@Composable
fun AiCustomerServiceScreen(
    user: UserProfile,
    appSettings: AppSettings,
    apiSettings: ApiSettings,
    conversations: List<AiConversation>,
    activeConversationId: String?,
    messages: List<AiMessage>,
    aiState: UiState<String>?,
    streamingText: String,
    onSelectConversation: (String?) -> Unit,
    onSendQuestion: (String) -> Unit,
    onClearError: () -> Unit,
    onUpgradePremium: () -> Unit,
    modifier: Modifier = Modifier
) {
    if (!user.isPremiumActive) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .padding(16.dp),
            contentAlignment = Alignment.Center
        ) {
            PremiumGateCard(
                featureName = "AI Customer Service 24/7",
                onUpgradeClick = onUpgradePremium,
                modifier = Modifier.widthIn(max = 540.dp)
            )
        }
        return
    }

    val context = LocalContext.current
    var inputPrompt by remember { mutableStateOf("") }
    val quickQuestions = listOf(
        "Cara cetak struk 58mm?",
        "Cara scan barcode produk?",
        "Tips atasi stok menipis",
        "Cara hitung diskon di kasir POS"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .widthIn(max = 960.dp)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        BrutalSectionHeader(
            title = "AI Customer Service",
            icon = Lucide.Bot,
            subtitle = "Asisten bisnis 24/7",
            trailing = {
                BrutalOutlinedButton(
                    text = "Sesi Baru",
                    icon = Lucide.Plus,
                    onClick = { onSelectConversation(null) },
                    testTag = "ai_new_chat_button"
                )
            }
        )

        if (conversations.isNotEmpty()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                conversations.take(8).forEach { conv ->
                    FilterChip(
                        selected = conv.id == activeConversationId,
                        onClick = { onSelectConversation(conv.id) },
                        shape = MaterialTheme.shapes.small,
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = PrimaryYellow,
                            selectedLabelColor = BrutalBlack
                        ),
                        label = { Text(conv.title.take(22)) }
                    )
                }
            }
        }

        // Quick Questions
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            quickQuestions.forEach { q ->
                SuggestionChip(
                    onClick = { onSendQuestion(q) },
                    shape = MaterialTheme.shapes.small,
                    label = { Text(q) }
                )
            }
        }

        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentPadding = PaddingValues(vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (messages.isEmpty() && streamingText.isBlank()) {
                item {
                    BrutalCard(borderColor = MaterialTheme.colorScheme.brutalHighlightBorder) {
                        Text(
                            "Halo ${user.name}! Saya Al, AI Customer Service NEXORA POS. Tanyakan apa saja tentang kasir, kelola produk, scan barcode/QR, cetak struk 58mm, transaksi, laporan penjualan, atau fitur Free & Premium.",
                            style = MaterialTheme.typography.bodyLarge
                        )
                    }
                }
            }

            items(messages, key = { it.id }) { msg ->
                val isUser = msg.role == "user"
                BrutalCard(
                    containerColor = if (isUser) PrimaryYellow else MaterialTheme.colorScheme.surface,
                    borderColor = if (isUser) MaterialTheme.colorScheme.brutalHighlightBorder else MaterialTheme.colorScheme.outlineVariant
                ) {
                    Text(
                        text = if (isUser) "Anda" else "Al • AI CS NEXORA",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (isUser) BrutalBlack.copy(alpha = 0.85f) else MaterialTheme.colorScheme.brutalAccentText
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = msg.text,
                        style = MaterialTheme.typography.bodyLarge,
                        color = if (isUser) BrutalBlack else MaterialTheme.colorScheme.onSurface
                    )
                }
            }

            if (streamingText.isNotBlank()) {
                item {
                    BrutalCard(containerColor = BrutalBlack, borderColor = PrimaryYellow, borderWidth = 1.5.dp) {
                        Text("AI CS NEXORA (mengetik...)", style = MaterialTheme.typography.labelSmall, color = PrimaryYellow)
                        Spacer(Modifier.height(4.dp))
                        Text(streamingText, style = MaterialTheme.typography.bodyLarge, color = BrutalWhite)
                    }
                }
            } else if (aiState is UiState.Loading) {
                item {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.5.dp, color = MaterialTheme.colorScheme.brutalAccentText)
                        Text("Al sedang menyiapkan jawaban...")
                    }
                }
            }

            if (aiState is UiState.Error) {
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        ErrorBannerCard(message = aiState.message, onRetry = onClearError)
                        BrutalButton(
                            text = "Hubungi Admin via WhatsApp",
                            icon = Lucide.MessageCircle,
                            containerColor = WhatsAppGreen,
                            onClick = {
                                WhatsAppHelper.openCs(
                                    context = context,
                                    whatsappNumber = appSettings.whatsappNumber,
                                    name = user.name,
                                    email = user.email,
                                    accountStatus = "Premium Lifetime",
                                    issue = "Kendala AI CS"
                                )
                            },
                            modifier = Modifier.fillMaxWidth(),
                            testTag = "ai_cs_whatsapp_fallback"
                        )
                    }
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            BrutalTextField(
                value = inputPrompt,
                onValueChange = { inputPrompt = it },
                label = "Tulis pertanyaan Anda...",
                leadingIcon = Lucide.Bot,
                modifier = Modifier.weight(1f),
                testTag = "ai_cs_input"
            )
            BrutalButton(
                text = "Kirim",
                icon = Lucide.Send,
                enabled = inputPrompt.isNotBlank() && aiState !is UiState.Loading,
                onClick = {
                    val prompt = inputPrompt
                    inputPrompt = ""
                    onSendQuestion(prompt)
                },
                testTag = "ai_cs_send_button"
            )
        }
    }
}
