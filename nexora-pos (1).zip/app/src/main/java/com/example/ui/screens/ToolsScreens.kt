package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.annotation.DrawableRes
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.core.DateFormatter
import com.example.model.ApiSettings
import com.example.model.ToolHistory
import com.example.model.UiState
import com.example.model.UserProfile
import com.example.ui.components.BrutalBadge
import com.example.ui.components.BrutalButton
import com.example.ui.components.BrutalCard
import com.example.ui.components.BrutalIconButton
import com.example.ui.components.BrutalOutlinedButton
import com.example.ui.components.BrutalSectionHeader
import com.example.ui.components.BrutalTextField
import com.example.ui.components.ErrorBannerCard
import com.example.ui.components.Lucide
import com.example.ui.components.LucideIcon
import com.example.ui.components.PremiumGateCard
import com.example.ui.components.StatusBadge
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.BrutalBlack
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.PrimaryYellow
import com.example.ui.theme.brutalAccentText
import com.example.ui.theme.brutalHighlightBorder

enum class ActiveToolType { NONE, GENERATION_AM, REACTION_CHANNEL, VOTE_CHANNEL, FAKE_LOBBY }

@Composable
fun ToolsHubScreen(
    user: UserProfile,
    apiSettings: ApiSettings,
    toolsHistory: List<ToolHistory>,
    toolState: UiState<String>?,
    onRunGenerationAm: (email: String, key: String) -> Unit,
    onRunVoteChannel: (email: String, link: String, key: String) -> Unit,
    onRunFakeLobby: (game: String, nickname: String, rank: String, players: Int) -> Unit,
    onClearToolState: () -> Unit,
    onUpgradePremium: () -> Unit,
    onShowMessage: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    if (!user.isPremiumActive) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .padding(16.dp),
            contentAlignment = Alignment.Center
        ) {
            PremiumGateCard(
                featureName = "Tools Premium NEXORA",
                onUpgradeClick = onUpgradePremium,
                modifier = Modifier.widthIn(max = 540.dp)
            )
        }
        return
    }

    var activeTool by remember { mutableStateOf(ActiveToolType.NONE) }

    if (activeTool != ActiveToolType.NONE) {
        BackHandler {
            onClearToolState()
            activeTool = ActiveToolType.NONE
        }
        ToolDetailScreen(
            toolType = activeTool,
            apiSettings = apiSettings,
            toolState = toolState,
            history = toolsHistory,
            onBack = {
                onClearToolState()
                activeTool = ActiveToolType.NONE
            },
            onRunGenerationAm = onRunGenerationAm,
            onRunVoteChannel = onRunVoteChannel,
            onRunFakeLobby = onRunFakeLobby,
            onShowMessage = onShowMessage,
            modifier = modifier
        )
        return
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .widthIn(max = 960.dp),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            BrutalSectionHeader(
                title = "Tools Premium",
                icon = Lucide.Wrench,
                subtitle = "Utilitas bisnis & integrasi endpoint"
            )
        }

        item {
            ToolMenuCard(
                title = "Generation AM Premium",
                desc = "Integrasi API Nexa (${apiSettings.nexaSendEndpoint.ifBlank { "Belum diatur" }}).",
                configured = apiSettings.nexaSendConfigured,
                icon = Lucide.Sparkles,
                onClick = { activeTool = ActiveToolType.GENERATION_AM },
                testTag = "tool_generation_am_card"
            )
        }
        item {
            ToolMenuCard(
                title = "Reaction Channel",
                desc = "Otomasi reaksi channel sesuai endpoint dokumentasi yang dikonfigurasi Admin.",
                configured = apiSettings.reactionConfigured,
                icon = Lucide.Heart,
                onClick = { activeTool = ActiveToolType.REACTION_CHANNEL },
                testTag = "tool_reaction_channel_card"
            )
        }
        item {
            ToolMenuCard(
                title = "Vote Channel",
                desc = "Integrasi verifikasi Nexa (${apiSettings.voteEndpoint.ifBlank { "Belum diatur" }}).",
                configured = apiSettings.voteConfigured,
                icon = Lucide.Vote,
                onClick = { activeTool = ActiveToolType.VOTE_CHANNEL },
                testTag = "tool_vote_channel_card"
            )
        }
        item {
            ToolMenuCard(
                title = "Fake Lobby (Simulasi Generator)",
                desc = "Generator simulasi tampilan lobi Free Fire, Mobile Legends, PUBG Mobile, & Roblox.",
                configured = true,
                icon = Lucide.Gamepad2,
                badgeLabel = "SIMULASI",
                onClick = { activeTool = ActiveToolType.FAKE_LOBBY },
                testTag = "tool_fake_lobby_card"
            )
        }

        item {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                LucideIcon(Lucide.History, contentDescription = null, tint = MaterialTheme.colorScheme.brutalAccentText, modifier = Modifier.size(18.dp))
                Text("Riwayat Penggunaan Tools", style = MaterialTheme.typography.titleLarge)
            }
        }
        if (toolsHistory.isEmpty()) {
            item {
                Text("Belum ada riwayat penggunaan tools.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            items(toolsHistory.take(15), key = { it.id }) { hist ->
                BrutalCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(hist.toolName, style = MaterialTheme.typography.titleMedium)
                            Text(hist.inputSummary, style = MaterialTheme.typography.bodyMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(DateFormatter.format(hist.createdAt), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        StatusBadge(hist.status)
                    }
                }
            }
        }
        item { Spacer(Modifier.height(64.dp)) }
    }
}

@Composable
private fun ToolMenuCard(
    title: String,
    desc: String,
    configured: Boolean,
    @DrawableRes icon: Int,
    badgeLabel: String? = null,
    onClick: () -> Unit,
    testTag: String
) {
    BrutalCard(onClick = onClick, modifier = Modifier.testTag(testTag)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(PrimaryYellow)
                    .border(1.5.dp, BrutalBlack, RoundedCornerShape(4.dp)),
                contentAlignment = Alignment.Center
            ) {
                LucideIcon(icon, contentDescription = null, tint = BrutalBlack, modifier = Modifier.size(20.dp))
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleLarge)
                Text(desc, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            BrutalBadge(
                text = badgeLabel ?: if (configured) "SIAP" else "BELUM DIKONFIGURASI",
                containerColor = if (badgeLabel != null) PrimaryYellow else if (configured) EmeraldSuccess.copy(alpha = 0.14f) else PrimaryYellow,
                contentColor = if (badgeLabel != null) BrutalBlack else if (configured) EmeraldSuccess else BrutalBlack
            )
        }
    }
}

@Composable
private fun ToolDetailScreen(
    toolType: ActiveToolType,
    apiSettings: ApiSettings,
    toolState: UiState<String>?,
    history: List<ToolHistory>,
    onBack: () -> Unit,
    onRunGenerationAm: (email: String, key: String) -> Unit,
    onRunVoteChannel: (email: String, link: String, key: String) -> Unit,
    onRunFakeLobby: (game: String, nickname: String, rank: String, players: Int) -> Unit,
    onShowMessage: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val clipboard = LocalClipboardManager.current
    var email by remember { mutableStateOf("") }
    var link by remember { mutableStateOf("") }
    var optionalKey by remember { mutableStateOf("") }
    var selectedGame by remember { mutableStateOf("Mobile Legends") }
    var nickname by remember { mutableStateOf("") }
    var rank by remember { mutableStateOf("Mythic") }

    val title = when (toolType) {
        ActiveToolType.GENERATION_AM -> "Generation AM Premium"
        ActiveToolType.REACTION_CHANNEL -> "Reaction Channel"
        ActiveToolType.VOTE_CHANNEL -> "Vote Channel"
        ActiveToolType.FAKE_LOBBY -> "Fake Lobby (Simulasi)"
        ActiveToolType.NONE -> ""
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .widthIn(max = 760.dp),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                BrutalIconButton(
                    icon = Lucide.ArrowLeft,
                    contentDescription = "Kembali",
                    onClick = onBack
                )
                Text(title, style = MaterialTheme.typography.headlineMedium)
            }
        }

        item {
            BrutalCard {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    when (toolType) {
                        ActiveToolType.GENERATION_AM -> {
                            if (!apiSettings.nexaSendConfigured) {
                                BrutalBadge(
                                    "Status: Belum Dikonfigurasi oleh Admin",
                                    containerColor = PrimaryYellow,
                                    contentColor = BrutalBlack
                                )
                            }
                            BrutalTextField(value = email, onValueChange = { email = it }, label = "Email Tujuan *", leadingIcon = Lucide.Sparkles)
                            BrutalTextField(
                                value = optionalKey,
                                onValueChange = { optionalKey = it },
                                label = "Kunci Proxy / Opsional",
                                placeholder = "Kosongkan jika backend proxy otomatis menyuntikkan API Key"
                            )
                            BrutalButton(
                                text = "Generate AM",
                                icon = Lucide.Sparkles,
                                enabled = email.isNotBlank() && toolState !is UiState.Loading,
                                onClick = { onRunGenerationAm(email, optionalKey) },
                                modifier = Modifier.fillMaxWidth(),
                                testTag = "run_generation_am_button"
                            )
                        }
                        ActiveToolType.REACTION_CHANNEL -> {
                            BrutalBadge(
                                text = if (apiSettings.reactionConfigured) "Endpoint: ${apiSettings.reactionEndpoint}" else "Belum Dikonfigurasi",
                                containerColor = PrimaryYellow,
                                contentColor = BrutalBlack
                            )
                            Text(
                                if (apiSettings.reactionConfigured) {
                                    "Endpoint Reaction Channel telah diatur Admin: ${apiSettings.reactionEndpoint}."
                                } else {
                                    "Status: Belum Dikonfigurasi. Admin dapat menambahkan endpoint API Reaction Channel yang terverifikasi di menu Pengaturan API."
                                },
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                        ActiveToolType.VOTE_CHANNEL -> {
                            if (!apiSettings.voteConfigured) {
                                BrutalBadge(
                                    "Status: Belum Dikonfigurasi oleh Admin",
                                    containerColor = PrimaryYellow,
                                    contentColor = BrutalBlack
                                )
                            }
                            BrutalTextField(value = email, onValueChange = { email = it }, label = "Email Verifikasi *", leadingIcon = Lucide.Vote)
                            BrutalTextField(value = link, onValueChange = { link = it }, label = "Link Channel *")
                            BrutalButton(
                                text = "Verifikasi & Proses Vote",
                                icon = Lucide.Vote,
                                enabled = email.isNotBlank() && link.isNotBlank() && toolState !is UiState.Loading,
                                onClick = { onRunVoteChannel(email, link, optionalKey) },
                                modifier = Modifier.fillMaxWidth(),
                                testTag = "run_vote_channel_button"
                            )
                        }
                        ActiveToolType.FAKE_LOBBY -> {
                            BrutalBadge(
                                text = "SIMULASI / GENERATOR VISUAL",
                                containerColor = PrimaryYellow,
                                contentColor = BrutalBlack
                            )
                            Text(
                                "Catatan: Fitur ini hanya generator simulasi lokal dan tidak menghasilkan data resmi dari server game.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                listOf("Free Fire", "Mobile Legends", "PUBG Mobile", "Roblox").forEach { game ->
                                    FilterChip(
                                        selected = selectedGame == game,
                                        onClick = { selectedGame = game },
                                        shape = MaterialTheme.shapes.small,
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = PrimaryYellow,
                                            selectedLabelColor = BrutalBlack
                                        ),
                                        label = { Text(game) }
                                    )
                                }
                            }
                            BrutalTextField(value = nickname, onValueChange = { nickname = it }, label = "Nickname Host", leadingIcon = Lucide.Gamepad2)
                            BrutalTextField(value = rank, onValueChange = { rank = it }, label = "Rank / Tier Simulasi")
                            BrutalButton(
                                text = "Buat Simulasi Lobby",
                                icon = Lucide.Gamepad2,
                                onClick = { onRunFakeLobby(selectedGame, nickname, rank, 5) },
                                modifier = Modifier.fillMaxWidth(),
                                testTag = "run_fake_lobby_button"
                            )
                        }
                        ActiveToolType.NONE -> {}
                    }
                }
            }
        }

        if (toolState is UiState.Loading) {
            item {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.5.dp, color = MaterialTheme.colorScheme.brutalAccentText)
                    Text("Memproses permintaan...")
                }
            }
        } else if (toolState is UiState.Error) {
            item { ErrorBannerCard(message = toolState.message) }
        } else if (toolState is UiState.Success) {
            item {
                BrutalCard(borderColor = MaterialTheme.colorScheme.brutalHighlightBorder, borderWidth = 1.5.dp) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Hasil Proses", style = MaterialTheme.typography.titleLarge)
                        Text(toolState.data, style = MaterialTheme.typography.bodyMedium)
                        BrutalOutlinedButton(
                            text = "Salin Hasil",
                            icon = Lucide.Copy,
                            onClick = {
                                clipboard.setText(AnnotatedString(toolState.data))
                                onShowMessage("Hasil disalin ke clipboard.")
                            },
                            modifier = Modifier.fillMaxWidth(),
                            testTag = "copy_tool_result_button"
                        )
                    }
                }
            }
        }

        item {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                LucideIcon(Lucide.History, contentDescription = null, tint = MaterialTheme.colorScheme.brutalAccentText, modifier = Modifier.size(18.dp))
                Text("Riwayat Tool Ini", style = MaterialTheme.typography.titleLarge)
            }
        }
        items(history.filter { it.toolName.contains(title.take(8), ignoreCase = true) }.take(10), key = { it.id }) { h ->
            BrutalCard {
                Text(h.inputSummary, style = MaterialTheme.typography.titleMedium)
                Text(h.outputSummary, style = MaterialTheme.typography.bodyMedium, maxLines = 3)
                Text(DateFormatter.format(h.createdAt), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
