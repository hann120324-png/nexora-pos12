package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import com.example.core.DateFormatter
import com.example.core.ImageEncodingHelper
import com.example.model.AppNotification
import com.example.model.Complaint
import com.example.model.ComplaintMessage
import com.example.model.UserProfile
import com.example.ui.components.BrutalBadge
import com.example.ui.components.BrutalButton
import com.example.ui.components.BrutalCard
import com.example.ui.components.BrutalDangerButton
import com.example.ui.components.BrutalIconButton
import com.example.ui.components.BrutalOutlinedButton
import com.example.ui.components.BrutalSectionHeader
import com.example.ui.components.BrutalTextField
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.ErrorBannerCard
import com.example.ui.components.Lucide
import com.example.ui.components.LucideIcon
import com.example.ui.components.StatusBadge
import com.example.ui.components.StoredImage
import com.example.ui.theme.BrutalBlack
import com.example.ui.theme.PrimaryYellow
import com.example.ui.theme.brutalAccentText
import com.example.ui.theme.brutalHighlightBorder

@Composable
fun ComplaintsScreen(
    user: UserProfile,
    complaints: List<Complaint>,
    messages: List<ComplaintMessage>,
    isSubmitting: Boolean,
    onCreateComplaint: (category: String, title: String, detail: String, attachmentUrl: String?) -> Unit,
    onOpenComplaint: (Complaint) -> Unit,
    onSendReply: (Complaint, String) -> Unit,
    onShowMessage: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var selectedComplaint by remember { mutableStateOf<Complaint?>(null) }
    var category by remember { mutableStateOf("Teknis") }
    var title by remember { mutableStateOf("") }
    var detail by remember { mutableStateOf("") }
    var attachmentUrl by remember { mutableStateOf<String?>(null) }
    var replyText by remember { mutableStateOf("") }

    val photoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            val encoded = ImageEncodingHelper.uriToCompressedDataUri(context, uri)
            if (encoded != null) attachmentUrl = encoded
            else onShowMessage("Gagal memproses gambar lampiran.")
        }
    }

    if (selectedComplaint != null) {
        val current = complaints.find { it.id == selectedComplaint!!.id } ?: selectedComplaint!!
        BackHandler { selectedComplaint = null }
        LaunchedEffect(current.id) { onOpenComplaint(current) }

        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .widthIn(max = 760.dp),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    BrutalIconButton(
                        icon = Lucide.ArrowLeft,
                        contentDescription = "Kembali",
                        onClick = { selectedComplaint = null }
                    )
                    Text("Detail Komplain", style = MaterialTheme.typography.headlineMedium)
                }
            }
            item {
                BrutalCard {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(current.title, style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                            StatusBadge(current.status)
                        }
                        Text("Kategori: ${current.category}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(current.detail, style = MaterialTheme.typography.bodyMedium)
                        if (current.rejectionReason.isNotBlank()) {
                            ErrorBannerCard(message = "Alasan Penolakan: ${current.rejectionReason}")
                        }
                        if (current.attachmentUrl.isNotBlank()) {
                            StoredImage(
                                imageSource = current.attachmentUrl,
                                contentDescription = "Lampiran Komplain",
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(170.dp)
                                    .clip(MaterialTheme.shapes.small)
                            )
                        }
                    }
                }
            }
            item { Text("Percakapan Komplain", style = MaterialTheme.typography.titleLarge) }
            items(messages, key = { it.id }) { msg ->
                val isAdminMsg = msg.senderRole == "ADMIN"
                BrutalCard(
                    borderColor = if (isAdminMsg) MaterialTheme.colorScheme.brutalHighlightBorder else MaterialTheme.colorScheme.outlineVariant
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("${msg.senderName} (${msg.senderRole})", style = MaterialTheme.typography.labelLarge)
                        Text(DateFormatter.format(msg.createdAt), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(msg.message, style = MaterialTheme.typography.bodyMedium)
                }
            }
            item {
                BrutalCard {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        BrutalTextField(
                            value = replyText,
                            onValueChange = { replyText = it },
                            label = "Balas pesan...",
                            testTag = "complaint_reply_input"
                        )
                        BrutalButton(
                            text = "Kirim Balasan",
                            icon = Lucide.Send,
                            enabled = replyText.isNotBlank() && !isSubmitting,
                            onClick = {
                                val text = replyText
                                replyText = ""
                                onSendReply(current, text)
                            },
                            modifier = Modifier.fillMaxWidth(),
                            testTag = "complaint_reply_send"
                        )
                    }
                }
            }
        }
        return
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .widthIn(max = 760.dp),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            BrutalSectionHeader(
                title = "Komplain",
                icon = Lucide.MessageSquareWarning,
                subtitle = "Laporkan kendala teknis atau pembayaran"
            )
        }

        item {
            BrutalCard {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Buat Komplain Baru", style = MaterialTheme.typography.titleLarge)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("Teknis", "Pembayaran", "Premium", "Lainnya").forEach { cat ->
                            FilterChip(
                                selected = category == cat,
                                onClick = { category = cat },
                                shape = MaterialTheme.shapes.small,
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = PrimaryYellow,
                                    selectedLabelColor = BrutalBlack
                                ),
                                label = { Text(cat) }
                            )
                        }
                    }
                    BrutalTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = "Judul Komplain *",
                        leadingIcon = Lucide.MessageSquareWarning,
                        testTag = "complaint_title_input"
                    )
                    BrutalTextField(
                        value = detail,
                        onValueChange = { detail = it },
                        label = "Detail Masalah *",
                        singleLine = false,
                        testTag = "complaint_detail_input"
                    )
                    if (!attachmentUrl.isNullOrBlank()) {
                        StoredImage(
                            imageSource = attachmentUrl,
                            contentDescription = "Lampiran",
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(150.dp)
                                .clip(MaterialTheme.shapes.small)
                        )
                    }
                    BrutalOutlinedButton(
                        text = if (attachmentUrl == null) "Lampirkan Gambar (Opsional)" else "Ganti Gambar Lampiran",
                        icon = Lucide.Upload,
                        onClick = { photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                        modifier = Modifier.fillMaxWidth(),
                        testTag = "complaint_pick_image_button"
                    )
                    BrutalButton(
                        text = if (isSubmitting) "Mengirim..." else "Kirim Komplain",
                        icon = Lucide.Send,
                        enabled = !isSubmitting && title.isNotBlank() && detail.isNotBlank(),
                        onClick = {
                            onCreateComplaint(category, title, detail, attachmentUrl)
                            title = ""
                            detail = ""
                            attachmentUrl = null
                        },
                        modifier = Modifier.fillMaxWidth(),
                        testTag = "submit_complaint_button"
                    )
                }
            }
        }

        item { Text("Daftar Komplain Anda", style = MaterialTheme.typography.titleLarge) }
        if (complaints.isEmpty()) {
            item {
                EmptyStateCard(
                    title = "Belum Ada Komplain",
                    subtitle = "Jika ada kendala transaksi atau akun, kirim komplain di atas.",
                    icon = Lucide.MessageSquareWarning
                )
            }
        } else {
            items(complaints, key = { it.id }) { comp ->
                BrutalCard(onClick = { selectedComplaint = comp }) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(comp.title, style = MaterialTheme.typography.titleMedium)
                            Text("${comp.category} | ${DateFormatter.format(comp.updatedAt ?: comp.createdAt)}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            if (comp.lastReply.isNotBlank()) {
                                Text("Balasan terakhir: ${comp.lastReply}", style = MaterialTheme.typography.bodyMedium, maxLines = 1)
                            }
                        }
                        StatusBadge(comp.status)
                    }
                }
            }
        }
        item { Spacer(Modifier.height(64.dp)) }
    }
}

@Composable
fun NotificationsScreen(
    notifications: List<AppNotification>,
    onMarkRead: (String) -> Unit,
    onMarkAllRead: () -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .widthIn(max = 760.dp),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            BrutalSectionHeader(
                title = "Notifikasi",
                icon = Lucide.Bell,
                subtitle = "Pemberitahuan akun & sistem",
                trailing = {
                    if (notifications.any { !it.read }) {
                        BrutalOutlinedButton(
                            text = "Tandai Dibaca",
                            icon = Lucide.CheckCheck,
                            onClick = onMarkAllRead,
                            testTag = "mark_all_notifications_read"
                        )
                    }
                }
            )
        }

        if (notifications.isEmpty()) {
            item {
                EmptyStateCard(
                    title = "Belum Ada Notifikasi",
                    subtitle = "Notifikasi stok menipis, transaksi, dan persetujuan Premium akan muncul di sini.",
                    icon = Lucide.Bell
                )
            }
        } else {
            items(notifications, key = { it.id }) { notif ->
                BrutalCard(
                    onClick = { if (!notif.read) onMarkRead(notif.id) },
                    borderColor = if (!notif.read) PrimaryYellow else MaterialTheme.colorScheme.outlineVariant
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(notif.title, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                        if (!notif.read) BrutalBadge("BARU", icon = Lucide.Bell)
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(notif.body, style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(4.dp))
                    Text(DateFormatter.format(notif.createdAt), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable
fun ProfileSettingsScreen(
    user: UserProfile,
    darkMode: Boolean,
    isSaving: Boolean,
    onToggleDarkMode: (Boolean) -> Unit,
    onSaveProfile: (name: String, storeName: String, storeAddress: String, storePhone: String, photoUrl: String?, storeLogoUrl: String?) -> Unit,
    onOpenAdminPanel: () -> Unit,
    onSignOut: () -> Unit,
    onShowMessage: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current

    var name by remember(user) { mutableStateOf(user.name) }
    var storeName by remember(user) { mutableStateOf(user.storeName) }
    var storeAddress by remember(user) { mutableStateOf(user.storeAddress) }
    var storePhone by remember(user) { mutableStateOf(user.storePhone) }
    var photoUrl by remember(user) { mutableStateOf(user.photoUrl) }
    var storeLogoUrl by remember(user) { mutableStateOf(user.storeLogoUrl) }

    val avatarPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            val encoded = ImageEncodingHelper.uriToCompressedDataUri(context, uri, maxDim = 320)
            if (encoded != null) photoUrl = encoded else onShowMessage("Gagal memproses foto profil.")
        }
    }
    val logoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            val encoded = ImageEncodingHelper.uriToCompressedDataUri(context, uri, maxDim = 320)
            if (encoded != null) storeLogoUrl = encoded else onShowMessage("Gagal memproses logo toko.")
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .widthIn(max = 760.dp),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            BrutalSectionHeader(
                title = "Profil & Pengaturan",
                icon = Lucide.Settings,
                subtitle = "Akun, identitas toko, & tampilan"
            )
        }

        item {
            BrutalCard(borderColor = MaterialTheme.colorScheme.outline, borderWidth = 1.5.dp) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    StoredImage(
                        imageSource = photoUrl,
                        contentDescription = "Foto Profil",
                        fallbackIcon = Lucide.UserRound,
                        modifier = Modifier
                            .size(64.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .border(1.5.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(8.dp))
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text(user.name, style = MaterialTheme.typography.titleLarge)
                        Text(user.email, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(Modifier.height(6.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            BrutalBadge(
                                text = if (user.isPremiumActive) "PREMIUM LIFETIME" else "FREE",
                                icon = if (user.isPremiumActive) Lucide.Crown else null
                            )
                            BrutalBadge("ROLE: ${user.role}")
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("UID: ${user.userId}", style = MaterialTheme.typography.labelSmall, modifier = Modifier.weight(1f))
                    BrutalIconButton(
                        icon = Lucide.Copy,
                        contentDescription = "Salin UID",
                        onClick = {
                            clipboard.setText(AnnotatedString(user.userId))
                            onShowMessage("UID disalin.")
                        }
                    )
                }
                Spacer(Modifier.height(8.dp))
                BrutalOutlinedButton(
                    text = "Ubah Foto Profil",
                    icon = Lucide.Upload,
                    onClick = { avatarPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "change_avatar_button"
                )
            }
        }

        if (user.isAdminRole) {
            item {
                BrutalCard(borderColor = MaterialTheme.colorScheme.brutalHighlightBorder, borderWidth = 2.dp) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Panel Owner / Admin", style = MaterialTheme.typography.titleLarge)
                            Text("Kelola user, approval Premium, komplain, API & pengaturan aplikasi.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        BrutalButton(
                            text = "Admin",
                            icon = Lucide.ShieldCheck,
                            onClick = onOpenAdminPanel,
                            testTag = "open_admin_dashboard_button"
                        )
                    }
                }
            }
        }

        item {
            BrutalCard {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        LucideIcon(Lucide.Store, contentDescription = null, tint = MaterialTheme.colorScheme.brutalAccentText, modifier = Modifier.size(18.dp))
                        Text("Informasi Bisnis & Struk", style = MaterialTheme.typography.titleLarge)
                    }
                    BrutalTextField(value = name, onValueChange = { name = it }, label = "Nama Lengkap", leadingIcon = Lucide.UserRound, testTag = "profile_name_input")
                    BrutalTextField(value = storeName, onValueChange = { storeName = it }, label = "Nama Toko (tampil di struk)", leadingIcon = Lucide.Store, testTag = "profile_store_name_input")
                    BrutalTextField(value = storeAddress, onValueChange = { storeAddress = it }, label = "Alamat Toko", testTag = "profile_store_address_input")
                    BrutalTextField(value = storePhone, onValueChange = { storePhone = it }, label = "Nomor Telepon Toko", testTag = "profile_store_phone_input")
                    BrutalOutlinedButton(
                        text = if (storeLogoUrl.isBlank()) "Unggah Logo Toko" else "Ganti Logo Toko",
                        icon = Lucide.Upload,
                        onClick = { logoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                        modifier = Modifier.fillMaxWidth()
                    )
                    BrutalButton(
                        text = if (isSaving) "Menyimpan..." else "Simpan Perubahan Profil",
                        enabled = !isSaving,
                        onClick = {
                            onSaveProfile(name, storeName, storeAddress, storePhone, photoUrl, storeLogoUrl)
                        },
                        modifier = Modifier.fillMaxWidth(),
                        testTag = "save_profile_button"
                    )
                }
            }
        }

        item {
            BrutalCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        LucideIcon(
                            if (darkMode) Lucide.Moon else Lucide.Sun,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.brutalAccentText,
                            modifier = Modifier.size(20.dp)
                        )
                        Column {
                            Text("Mode Gelap (Dark Mode)", style = MaterialTheme.typography.titleMedium)
                            Text("Tema gelap kontras tinggi", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    Switch(
                        checked = darkMode,
                        onCheckedChange = onToggleDarkMode,
                        modifier = Modifier.testTag("dark_mode_switch")
                    )
                }
                HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp), color = MaterialTheme.colorScheme.outlineVariant)
                BrutalDangerButton(
                    text = "Keluar dari Akun",
                    icon = Lucide.LogOut,
                    onClick = onSignOut,
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "sign_out_button"
                )
            }
        }

        item { Spacer(Modifier.height(64.dp)) }
    }
}
