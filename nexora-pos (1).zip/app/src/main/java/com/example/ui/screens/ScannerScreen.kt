package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.util.Size
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.OptIn
import androidx.camera.core.CameraSelector
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.core.RupiahFormatter
import com.example.model.Product
import com.example.ui.components.BrutalBadge
import com.example.ui.components.BrutalButton
import com.example.ui.components.BrutalCard
import com.example.ui.components.BrutalOutlinedButton
import com.example.ui.components.BrutalSectionHeader
import com.example.ui.components.BrutalTextField
import com.example.ui.components.ErrorBannerCard
import com.example.ui.components.Lucide
import com.example.ui.components.LucideIcon
import com.example.ui.theme.PrimaryYellow
import com.example.ui.theme.brutalAccentText
import com.example.ui.theme.brutalHighlightBorder
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import java.util.concurrent.Executors

@OptIn(ExperimentalGetImage::class)
@Composable
fun ScannerScreen(
    isPremium: Boolean,
    onLookupCode: (String, (Product?) -> Unit) -> Unit,
    onOpenProductDetail: (String) -> Unit,
    onAddProductToPos: (Product) -> Unit,
    onShowMessage: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
                PackageManager.PERMISSION_GRANTED
        )
    }
    var cameraAvailable by remember { mutableStateOf(true) }
    var manualCode by remember { mutableStateOf("") }
    var lastScannedCode by remember { mutableStateOf<String?>(null) }
    var foundProduct by remember { mutableStateOf<Product?>(null) }
    var notFoundMessage by remember { mutableStateOf<String?>(null) }

    val handleCodeDetected: (String) -> Unit = remember(onLookupCode) {
        { rawCode ->
            val clean = rawCode.trim()
            if (clean.isNotEmpty() && clean != lastScannedCode) {
                lastScannedCode = clean
                manualCode = clean
                notFoundMessage = null
                onLookupCode(clean) { matched ->
                    foundProduct = matched
                    if (matched == null) {
                        notFoundMessage = "Kode '$clean' belum terdaftar di produk Anda."
                    }
                }
            }
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasCameraPermission = granted
        if (!granted) {
            onShowMessage("Izin kamera ditolak. Anda masih dapat memindai dari gambar atau input kode manual.")
        }
    }

    val imagePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                val inputImage = InputImage.fromFilePath(context, uri)
                val scanner = BarcodeScanning.getClient()
                scanner.process(inputImage)
                    .addOnSuccessListener { barcodes ->
                        val code = barcodes.firstOrNull()?.rawValue
                        if (!code.isNullOrBlank()) {
                            lastScannedCode = null
                            handleCodeDetected(code)
                        } else {
                            onShowMessage("Tidak ditemukan QR atau Barcode pada gambar yang dipilih.")
                        }
                    }
                    .addOnFailureListener {
                        onShowMessage("Gagal memindai gambar: ${it.localizedMessage}")
                    }
            } catch (_: Exception) {
                onShowMessage("Gagal membaca file gambar.")
            }
        }
    }

    val analyzerExecutor = remember { Executors.newSingleThreadExecutor() }
    DisposableEffect(Unit) {
        onDispose { analyzerExecutor.shutdown() }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .widthIn(max = 760.dp),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            BrutalSectionHeader(
                title = "Scanner",
                icon = Lucide.ScanLine,
                subtitle = "Scan QR Code & Barcode produk"
            )
        }

        // CameraX Preview Card
        item {
            BrutalCard(borderColor = MaterialTheme.colorScheme.outline, borderWidth = 1.5.dp) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (!hasCameraPermission) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 18.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            LucideIcon(Lucide.Camera, contentDescription = null, tint = MaterialTheme.colorScheme.brutalAccentText, modifier = Modifier.size(28.dp))
                            Text("Izin Kamera Diperlukan untuk Scan Langsung", style = MaterialTheme.typography.titleMedium)
                            Text(
                                "Aktifkan kamera belakang untuk memindai QR Code dan Barcode produk secara real-time.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            BrutalButton(
                                text = "Izinkan Kamera",
                                icon = Lucide.Camera,
                                onClick = { permissionLauncher.launch(Manifest.permission.CAMERA) },
                                testTag = "grant_camera_button"
                            )
                        }
                    } else if (!cameraAvailable) {
                        ErrorBannerCard(message = "Kamera belakang tidak tersedia pada perangkat ini. Gunakan upload gambar atau input manual di bawah.")
                    } else {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(240.dp)
                                .clip(MaterialTheme.shapes.small)
                                .border(2.dp, MaterialTheme.colorScheme.brutalHighlightBorder, MaterialTheme.shapes.small)
                        ) {
                            AndroidView(
                                factory = { ctx ->
                                    val previewView = PreviewView(ctx)
                                    val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
                                    cameraProviderFuture.addListener({
                                        try {
                                            val cameraProvider = cameraProviderFuture.get()
                                            val preview = Preview.Builder().build().apply {
                                                surfaceProvider = previewView.surfaceProvider
                                            }
                                            val scanner = BarcodeScanning.getClient()
                                            val analysis = ImageAnalysis.Builder()
                                                .setTargetResolution(Size(1280, 720))
                                                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                                                .build()
                                            analysis.setAnalyzer(analyzerExecutor) { imageProxy ->
                                                val mediaImage = imageProxy.image
                                                if (mediaImage != null) {
                                                    val inputImage = InputImage.fromMediaImage(
                                                        mediaImage,
                                                        imageProxy.imageInfo.rotationDegrees
                                                    )
                                                    scanner.process(inputImage)
                                                        .addOnSuccessListener { barcodes ->
                                                            val raw = barcodes.firstOrNull()?.rawValue
                                                            if (!raw.isNullOrBlank()) {
                                                                handleCodeDetected(raw)
                                                            }
                                                        }
                                                        .addOnCompleteListener {
                                                            imageProxy.close()
                                                        }
                                                } else {
                                                    imageProxy.close()
                                                }
                                            }
                                            cameraProvider.unbindAll()
                                            cameraProvider.bindToLifecycle(
                                                lifecycleOwner,
                                                CameraSelector.DEFAULT_BACK_CAMERA,
                                                preview,
                                                analysis
                                            )
                                        } catch (_: Exception) {
                                            cameraAvailable = false
                                        }
                                    }, ContextCompat.getMainExecutor(ctx))
                                    previewView
                                },
                                modifier = Modifier.fillMaxSize()
                            )
                            BrutalBadge(
                                text = "KAMERA AKTIF",
                                icon = Lucide.ScanLine,
                                modifier = Modifier
                                    .align(Alignment.TopStart)
                                    .padding(10.dp)
                            )
                        }
                    }

                    BrutalOutlinedButton(
                        text = "Scan dari Gambar Galeri",
                        icon = Lucide.Upload,
                        onClick = {
                            imagePicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                        },
                        modifier = Modifier.fillMaxWidth(),
                        testTag = "scan_from_image_button"
                    )
                }
            }
        }

        // Manual lookup
        item {
            BrutalCard {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        LucideIcon(Lucide.Barcode, contentDescription = null, tint = MaterialTheme.colorScheme.brutalAccentText, modifier = Modifier.size(20.dp))
                        Text("Input Kode Manual", style = MaterialTheme.typography.titleLarge)
                    }
                    BrutalTextField(
                        value = manualCode,
                        onValueChange = { manualCode = it },
                        label = "Masukkan Barcode / SKU / ID QR",
                        leadingIcon = Lucide.Barcode,
                        testTag = "manual_code_input"
                    )
                    BrutalButton(
                        text = "Cari Produk",
                        icon = Lucide.Search,
                        onClick = {
                            lastScannedCode = null
                            handleCodeDetected(manualCode)
                        },
                        modifier = Modifier.fillMaxWidth(),
                        testTag = "manual_code_search_button"
                    )
                }
            }
        }

        if (notFoundMessage != null) {
            item {
                ErrorBannerCard(message = notFoundMessage!!)
            }
        }

        if (foundProduct != null) {
            val prod = foundProduct!!
            item {
                BrutalCard(borderColor = MaterialTheme.colorScheme.brutalHighlightBorder, borderWidth = 2.dp) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        BrutalBadge("PRODUK DITEMUKAN", icon = Lucide.CircleCheck)
                        Text(prod.name, style = MaterialTheme.typography.headlineMedium)
                        Text("SKU: ${prod.sku} | Kategori: ${prod.category}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(
                            "Harga Jual: ${RupiahFormatter.format(prod.sellPrice)} | Stok: ${prod.stock} ${prod.unit}",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.brutalAccentText
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            BrutalOutlinedButton(
                                text = "Detail Produk",
                                icon = Lucide.Package,
                                onClick = { onOpenProductDetail(prod.id) },
                                modifier = Modifier.weight(1f),
                                testTag = "scanned_detail_button"
                            )
                            if (isPremium) {
                                BrutalButton(
                                    text = "Ke Kasir POS",
                                    icon = Lucide.ShoppingCart,
                                    enabled = prod.stock > 0,
                                    onClick = { onAddProductToPos(prod) },
                                    modifier = Modifier.weight(1f),
                                    testTag = "scanned_add_pos_button"
                                )
                            }
                        }
                    }
                }
            }
        }

        item { Spacer(Modifier.height(64.dp)) }
    }
}
