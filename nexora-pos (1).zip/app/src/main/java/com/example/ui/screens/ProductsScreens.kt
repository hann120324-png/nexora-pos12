package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.core.DateFormatter
import com.example.core.ImageEncodingHelper
import com.example.core.QrCodeHelper
import com.example.core.RupiahFormatter
import com.example.model.Category
import com.example.model.Product
import com.example.model.StockMovement
import com.example.model.UiState
import com.example.ui.components.BrutalBadge
import com.example.ui.components.BrutalButton
import com.example.ui.components.BrutalCard
import com.example.ui.components.BrutalDangerButton
import com.example.ui.components.BrutalIconButton
import com.example.ui.components.BrutalOutlinedButton
import com.example.ui.components.BrutalSectionHeader
import com.example.ui.components.BrutalTextField
import com.example.ui.components.ConfirmDialog
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.ErrorBannerCard
import com.example.ui.components.Lucide
import com.example.ui.components.LucideIcon
import com.example.ui.components.SkeletonBox
import com.example.ui.components.StatusBadge
import com.example.ui.components.StoredImage
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.BrutalBlack
import com.example.ui.theme.CrimsonError
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.PrimaryYellow
import com.example.ui.theme.brutalAccentText
import com.example.viewmodel.ProductSort
import com.example.viewmodel.StockFilter

@Composable
fun ProductsListScreen(
    productsState: UiState<List<Product>>,
    filteredProducts: List<Product>,
    categories: List<Category>,
    searchQuery: String,
    selectedCategory: String,
    stockFilter: StockFilter,
    sortOrder: ProductSort,
    onSearchChange: (String) -> Unit,
    onCategoryChange: (String) -> Unit,
    onStockFilterChange: (StockFilter) -> Unit,
    onSortOrderChange: (ProductSort) -> Unit,
    onAddProductClick: () -> Unit,
    onProductClick: (String) -> Unit,
    onAddCategory: (String) -> Unit,
    onDeleteCategory: (String) -> Unit,
    onExportCsv: (Uri) -> Unit,
    modifier: Modifier = Modifier
) {
    var showCategoryDialog by remember { mutableStateOf(false) }
    var newCategoryName by remember { mutableStateOf("") }

    val exportCsvLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("text/csv")
    ) { uri ->
        if (uri != null) onExportCsv(uri)
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .widthIn(max = 960.dp),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            BrutalSectionHeader(
                title = "Produk",
                icon = Lucide.Package,
                subtitle = "Inventaris & kategori barang",
                trailing = {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        BrutalIconButton(
                            icon = Lucide.ListFilter,
                            contentDescription = "Kelola Kategori",
                            onClick = { showCategoryDialog = true },
                            testTag = "manage_categories_button"
                        )
                        BrutalButton(
                            text = "Tambah",
                            icon = Lucide.PackagePlus,
                            onClick = onAddProductClick,
                            testTag = "add_product_button"
                        )
                    }
                }
            )
        }

        item {
            BrutalTextField(
                value = searchQuery,
                onValueChange = onSearchChange,
                label = "Cari nama produk, SKU, barcode...",
                leadingIcon = Lucide.Search,
                testTag = "product_search_input"
            )
        }

        item {
            val allCats = remember(categories) {
                listOf("Semua") + (categories.map { it.name } + listOf("Umum", "Makanan", "Minuman", "Elektronik", "Jasa")).distinct()
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                allCats.forEach { cat ->
                    FilterChip(
                        selected = selectedCategory == cat,
                        onClick = { onCategoryChange(cat) },
                        shape = MaterialTheme.shapes.small,
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = PrimaryYellow,
                            selectedLabelColor = BrutalBlack
                        ),
                        label = { Text(cat) }
                    )
                }
            }
        }

        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                StockFilter.entries.forEach { filter ->
                    FilterChip(
                        selected = stockFilter == filter,
                        onClick = { onStockFilterChange(filter) },
                        shape = MaterialTheme.shapes.small,
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = PrimaryYellow,
                            selectedLabelColor = BrutalBlack
                        ),
                        label = { Text("Stok: ${filter.label}") }
                    )
                }
                ProductSort.entries.forEach { sort ->
                    FilterChip(
                        selected = sortOrder == sort,
                        onClick = { onSortOrderChange(sort) },
                        shape = MaterialTheme.shapes.small,
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = PrimaryYellow,
                            selectedLabelColor = BrutalBlack
                        ),
                        label = { Text("Urut: ${sort.label}") }
                    )
                }
                FilterChip(
                    selected = false,
                    onClick = { exportCsvLauncher.launch("nexora_produk.csv") },
                    shape = MaterialTheme.shapes.small,
                    leadingIcon = { LucideIcon(Lucide.Download, contentDescription = null, modifier = Modifier.size(16.dp)) },
                    label = { Text("Ekspor CSV") }
                )
            }
        }

        when (productsState) {
            is UiState.Loading -> {
                items(3) { SkeletonBox(height = 96.dp) }
            }
            is UiState.Error -> {
                item { ErrorBannerCard(message = productsState.message) }
            }
            is UiState.Success -> {
                if (filteredProducts.isEmpty()) {
                    item {
                        EmptyStateCard(
                            title = "Produk Tidak Ditemukan",
                            subtitle = "Tambahkan produk baru atau ubah kata kunci & filter pencarian.",
                            icon = Lucide.Package,
                            actionText = "Tambah Produk",
                            onAction = onAddProductClick
                        )
                    }
                } else {
                    items(filteredProducts, key = { it.id }) { product ->
                        BrutalCard(
                            onClick = { onProductClick(product.id) },
                            modifier = Modifier.testTag("product_card_${product.id}")
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                StoredImage(
                                    imageSource = product.photoUrl,
                                    contentDescription = product.name,
                                    fallbackIcon = Lucide.Package,
                                    modifier = Modifier
                                        .size(60.dp)
                                        .clip(RoundedCornerShape(6.dp))
                                )
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        product.name,
                                        style = MaterialTheme.typography.titleMedium,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        "${product.category} | SKU: ${product.sku}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Spacer(Modifier.height(4.dp))
                                    Row(
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            RupiahFormatter.format(product.sellPrice),
                                            style = MaterialTheme.typography.titleMedium,
                                            color = MaterialTheme.colorScheme.brutalAccentText
                                        )
                                        BrutalBadge(
                                            text = "${product.stock} ${product.unit}",
                                            icon = Lucide.Boxes,
                                            containerColor = when {
                                                product.outOfStock -> CrimsonError.copy(alpha = 0.12f)
                                                product.lowStock -> AmberWarning.copy(alpha = 0.14f)
                                                else -> EmeraldSuccess.copy(alpha = 0.12f)
                                            },
                                            contentColor = when {
                                                product.outOfStock -> CrimsonError
                                                product.lowStock -> AmberWarning
                                                else -> EmeraldSuccess
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        item { Spacer(Modifier.height(64.dp)) }
    }

    if (showCategoryDialog) {
        AlertDialog(
            shape = MaterialTheme.shapes.medium,
            onDismissRequest = { showCategoryDialog = false },
            title = { Text("Kelola Kategori Produk", style = MaterialTheme.typography.titleLarge) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    BrutalTextField(
                        value = newCategoryName,
                        onValueChange = { newCategoryName = it },
                        label = "Nama Kategori Baru",
                        leadingIcon = Lucide.ListFilter,
                        testTag = "new_category_input"
                    )
                    BrutalButton(
                        text = "Simpan Kategori",
                        icon = Lucide.Plus,
                        onClick = {
                            if (newCategoryName.isNotBlank()) {
                                onAddCategory(newCategoryName)
                                newCategoryName = ""
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        testTag = "save_category_button"
                    )
                    categories.forEach { cat ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(cat.name, style = MaterialTheme.typography.bodyLarge)
                            BrutalIconButton(
                                icon = Lucide.Trash2,
                                contentDescription = "Hapus Kategori",
                                tint = CrimsonError,
                                onClick = { onDeleteCategory(cat.id) }
                            )
                        }
                    }
                }
            },
            confirmButton = {
                BrutalOutlinedButton(text = "Tutup", onClick = { showCategoryDialog = false })
            }
        )
    }
}

@Composable
fun ProductFormScreen(
    existingProduct: Product?,
    categories: List<Category>,
    isBusy: Boolean,
    onBack: () -> Unit,
    onSave: (Product) -> Unit,
    onShowMessage: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onBack() }
    val context = LocalContext.current

    var name by remember(existingProduct) { mutableStateOf(existingProduct?.name ?: "") }
    var sku by remember(existingProduct) { mutableStateOf(existingProduct?.sku ?: "SKU-${(1000..9999).random()}") }
    var barcode by remember(existingProduct) { mutableStateOf(existingProduct?.barcode ?: "") }
    var category by remember(existingProduct) { mutableStateOf(existingProduct?.category ?: "Umum") }
    var description by remember(existingProduct) { mutableStateOf(existingProduct?.description ?: "") }
    var costPrice by remember(existingProduct) { mutableStateOf(existingProduct?.costPrice?.toLong()?.toString() ?: "0") }
    var sellPrice by remember(existingProduct) { mutableStateOf(existingProduct?.sellPrice?.toLong()?.toString() ?: "") }
    var stock by remember(existingProduct) { mutableStateOf(existingProduct?.stock?.toString() ?: "10") }
    var lowThreshold by remember(existingProduct) { mutableStateOf(existingProduct?.lowStockThreshold?.toString() ?: "5") }
    var unit by remember(existingProduct) { mutableStateOf(existingProduct?.unit ?: "pcs") }
    var photoUrl by remember(existingProduct) { mutableStateOf(existingProduct?.photoUrl ?: "") }

    val photoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            val encoded = ImageEncodingHelper.uriToCompressedDataUri(context, uri)
            if (encoded != null) {
                photoUrl = encoded
            } else {
                onShowMessage("Gagal memproses foto produk. Pilih gambar lain.")
            }
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .widthIn(max = 760.dp),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                BrutalIconButton(
                    icon = Lucide.ArrowLeft,
                    contentDescription = "Kembali",
                    onClick = onBack
                )
                LucideIcon(
                    if (existingProduct == null) Lucide.PackagePlus else Lucide.Pencil,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.brutalAccentText,
                    modifier = Modifier.size(20.dp)
                )
                Text(
                    if (existingProduct == null) "Tambah Produk Baru" else "Edit Produk",
                    style = MaterialTheme.typography.headlineMedium
                )
            }
        }

        item {
            BrutalCard {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    if (photoUrl.isNotBlank()) {
                        StoredImage(
                            imageSource = photoUrl,
                            contentDescription = "Foto Produk",
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp)
                                .clip(MaterialTheme.shapes.small)
                                .border(1.dp, MaterialTheme.colorScheme.outlineVariant, MaterialTheme.shapes.small)
                        )
                    }
                    BrutalOutlinedButton(
                        text = if (photoUrl.isBlank()) "Pilih Foto Produk" else "Ganti Foto Produk",
                        icon = Lucide.Upload,
                        onClick = { photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                        modifier = Modifier.fillMaxWidth(),
                        testTag = "pick_product_photo_button"
                    )
                    BrutalTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = "Nama Produk *",
                        leadingIcon = Lucide.Package,
                        isError = name.isBlank(),
                        helperText = if (name.isBlank()) "Wajib diisi" else null,
                        testTag = "product_name_input"
                    )
                    BrutalTextField(
                        value = sku,
                        onValueChange = { sku = it },
                        label = "SKU *",
                        leadingIcon = Lucide.QrCode,
                        testTag = "product_sku_input"
                    )
                    BrutalTextField(
                        value = barcode,
                        onValueChange = { barcode = it },
                        label = "Barcode / Kode EAN (Opsional)",
                        leadingIcon = Lucide.Barcode,
                        testTag = "product_barcode_input"
                    )

                    val catSuggestions = remember(categories) {
                        (categories.map { it.name } + listOf("Umum", "Makanan", "Minuman", "Elektronik", "Jasa")).distinct()
                    }
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        catSuggestions.forEach { cat ->
                            FilterChip(
                                selected = category == cat,
                                onClick = { category = cat },
                                shape = MaterialTheme.shapes.small,
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = PrimaryYellow,
                                    selectedLabelColor = BrutalBlack
                                ),
                                label = { Text(cat) }
                            )
                        }
                    }
                    BrutalTextField(
                        value = category,
                        onValueChange = { category = it },
                        label = "Kategori *",
                        leadingIcon = Lucide.ListFilter,
                        testTag = "product_category_input"
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        BrutalTextField(
                            value = costPrice,
                            onValueChange = { costPrice = it.filter { c -> c.isDigit() } },
                            label = "Harga Modal (Rp)",
                            leadingIcon = Lucide.Banknote,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            testTag = "product_cost_input"
                        )
                        BrutalTextField(
                            value = sellPrice,
                            onValueChange = { sellPrice = it.filter { c -> c.isDigit() } },
                            label = "Harga Jual (Rp) *",
                            leadingIcon = Lucide.Banknote,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            testTag = "product_sell_input"
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        BrutalTextField(
                            value = stock,
                            onValueChange = { stock = it.filter { c -> c.isDigit() } },
                            label = "Stok *",
                            leadingIcon = Lucide.Boxes,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            testTag = "product_stock_input"
                        )
                        BrutalTextField(
                            value = lowThreshold,
                            onValueChange = { lowThreshold = it.filter { c -> c.isDigit() } },
                            label = "Batas Min",
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            testTag = "product_threshold_input"
                        )
                        BrutalTextField(
                            value = unit,
                            onValueChange = { unit = it },
                            label = "Satuan",
                            modifier = Modifier.weight(1f),
                            testTag = "product_unit_input"
                        )
                    }
                    BrutalTextField(
                        value = description,
                        onValueChange = { description = it },
                        label = "Deskripsi Produk (Opsional)",
                        singleLine = false,
                        testTag = "product_desc_input"
                    )
                    BrutalButton(
                        text = if (isBusy) "Menyimpan..." else "Simpan Produk",
                        icon = if (existingProduct == null) Lucide.PackagePlus else Lucide.Pencil,
                        enabled = !isBusy,
                        onClick = {
                            val sell = sellPrice.toDoubleOrNull()
                            if (name.isBlank() || sku.isBlank() || sell == null) {
                                onShowMessage("Nama, SKU, dan Harga Jual wajib diisi.")
                                return@BrutalButton
                            }
                            onSave(
                                (existingProduct ?: Product()).copy(
                                    name = name,
                                    sku = sku,
                                    barcode = barcode,
                                    category = category,
                                    description = description,
                                    costPrice = costPrice.toDoubleOrNull() ?: 0.0,
                                    sellPrice = sell,
                                    stock = stock.toLongOrNull() ?: 0L,
                                    lowStockThreshold = lowThreshold.toLongOrNull() ?: 5L,
                                    unit = unit.ifBlank { "pcs" },
                                    photoUrl = photoUrl
                                )
                            )
                        },
                        modifier = Modifier.fillMaxWidth(),
                        testTag = "save_product_button"
                    )
                }
            }
        }
    }
}

@Composable
fun ProductDetailScreen(
    product: Product,
    movements: List<StockMovement>,
    isPremium: Boolean,
    onBack: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onAdjustStock: (delta: Long, reason: String) -> Unit,
    onAddToPosCart: () -> Unit,
    onShowMessage: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onBack() }
    val context = LocalContext.current
    var showDeleteConfirm by remember { mutableStateOf(false) }
    var adjustInput by remember { mutableStateOf("5") }
    var adjustReason by remember { mutableStateOf("Restock barang") }

    val qrContent = remember(product) {
        product.qrCode.ifBlank { "NEXORA:${product.id}:${product.sku}" }
    }
    val qrBitmap = remember(qrContent) { QrCodeHelper.generateQrBitmap(qrContent, 420) }

    val downloadQrLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("image/png")
    ) { uri ->
        if (uri != null && qrBitmap != null) {
            val ok = QrCodeHelper.saveBitmapPngToUri(context, uri, qrBitmap)
            onShowMessage(if (ok) "QR Code produk berhasil diunduh." else "Gagal menyimpan gambar QR Code.")
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .widthIn(max = 760.dp),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    BrutalIconButton(
                        icon = Lucide.ArrowLeft,
                        contentDescription = "Kembali",
                        onClick = onBack
                    )
                    Text("Detail Produk", style = MaterialTheme.typography.headlineMedium)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    BrutalIconButton(
                        icon = Lucide.Pencil,
                        contentDescription = "Edit Produk",
                        onClick = onEdit,
                        testTag = "edit_product_button"
                    )
                    BrutalIconButton(
                        icon = Lucide.Trash2,
                        contentDescription = "Hapus Produk",
                        tint = CrimsonError,
                        borderColor = CrimsonError,
                        onClick = { showDeleteConfirm = true },
                        testTag = "delete_product_button"
                    )
                }
            }
        }

        item {
            BrutalCard {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (product.photoUrl.isNotBlank()) {
                        StoredImage(
                            imageSource = product.photoUrl,
                            contentDescription = product.name,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(180.dp)
                                .clip(MaterialTheme.shapes.small)
                        )
                    }
                    Text(product.name, style = MaterialTheme.typography.headlineMedium)
                    Text("ID: ${product.id} | SKU: ${product.sku}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    if (product.barcode.isNotBlank()) {
                        Text("Barcode: ${product.barcode}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Harga Modal", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(RupiahFormatter.format(product.costPrice), style = MaterialTheme.typography.titleMedium)
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Harga Jual", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(RupiahFormatter.format(product.sellPrice), style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.brutalAccentText)
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Stok", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("${product.stock} ${product.unit}", style = MaterialTheme.typography.titleLarge)
                        }
                    }
                    if (product.description.isNotBlank()) {
                        Text(product.description, style = MaterialTheme.typography.bodyMedium)
                    }
                    if (isPremium) {
                        BrutalButton(
                            text = "Masukkan ke Keranjang Kasir POS",
                            icon = Lucide.ShoppingCart,
                            onClick = onAddToPosCart,
                            enabled = product.stock > 0,
                            modifier = Modifier.fillMaxWidth(),
                            testTag = "product_add_to_pos_button"
                        )
                    }
                }
            }
        }

        // QR Code Generator Card
        item {
            BrutalCard {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        LucideIcon(Lucide.QrCode, contentDescription = null, tint = MaterialTheme.colorScheme.brutalAccentText, modifier = Modifier.size(20.dp))
                        Text("QR Code Produk", style = MaterialTheme.typography.titleLarge)
                    }
                    if (qrBitmap != null) {
                        Image(
                            bitmap = qrBitmap.asImageBitmap(),
                            contentDescription = "QR Code ${product.name}",
                            modifier = Modifier
                                .size(190.dp)
                                .border(2.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(8.dp))
                                .padding(8.dp)
                        )
                    }
                    Text(qrContent, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        BrutalOutlinedButton(
                            text = "Unduh PNG",
                            icon = Lucide.Download,
                            onClick = { downloadQrLauncher.launch("QR_${product.sku}.png") },
                            modifier = Modifier.weight(1f),
                            testTag = "download_qr_button"
                        )
                        BrutalButton(
                            text = "Cetak QR",
                            icon = Lucide.Printer,
                            onClick = {
                                if (qrBitmap != null) {
                                    QrCodeHelper.printQrBitmap(context, product.name, product.sku, qrBitmap)
                                }
                            },
                            modifier = Modifier.weight(1f),
                            testTag = "print_qr_button"
                        )
                    }
                }
            }
        }

        // Stock Adjustment Card
        item {
            BrutalCard {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        LucideIcon(Lucide.Boxes, contentDescription = null, tint = MaterialTheme.colorScheme.brutalAccentText, modifier = Modifier.size(20.dp))
                        Text("Penyesuaian Stok", style = MaterialTheme.typography.titleLarge)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        BrutalTextField(
                            value = adjustInput,
                            onValueChange = { adjustInput = it.filter { c -> c.isDigit() } },
                            label = "Jumlah",
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f)
                        )
                        BrutalTextField(
                            value = adjustReason,
                            onValueChange = { adjustReason = it },
                            label = "Alasan",
                            modifier = Modifier.weight(2f)
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        BrutalButton(
                            text = "Tambah Stok",
                            icon = Lucide.Plus,
                            containerColor = EmeraldSuccess,
                            onClick = {
                                val qty = adjustInput.toLongOrNull() ?: 0L
                                if (qty > 0) onAdjustStock(qty, adjustReason)
                            },
                            modifier = Modifier.weight(1f),
                            testTag = "stock_increase_button"
                        )
                        BrutalDangerButton(
                            text = "Kurangi Stok",
                            icon = Lucide.Minus,
                            onClick = {
                                val qty = adjustInput.toLongOrNull() ?: 0L
                                if (qty > 0) onAdjustStock(-qty, adjustReason)
                            },
                            modifier = Modifier.weight(1f),
                            testTag = "stock_decrease_button"
                        )
                    }
                }
            }
        }

        item {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                LucideIcon(Lucide.History, contentDescription = null, tint = MaterialTheme.colorScheme.brutalAccentText, modifier = Modifier.size(18.dp))
                Text("Riwayat Mutasi Stok", style = MaterialTheme.typography.titleLarge)
            }
        }
        val prodMovements = movements.filter { it.productId == product.id }
        if (prodMovements.isEmpty()) {
            item {
                Text("Belum ada riwayat mutasi stok untuk produk ini.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            items(prodMovements.take(15), key = { it.id }) { mov ->
                BrutalCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(mov.reason, style = MaterialTheme.typography.titleMedium)
                            Text(DateFormatter.format(mov.createdAt), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            StatusBadge(if (mov.delta >= 0) "+${mov.delta}" else "${mov.delta}")
                            Spacer(Modifier.height(2.dp))
                            Text("Sisa: ${mov.stockAfter}", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
        }
    }

    if (showDeleteConfirm) {
        ConfirmDialog(
            title = "Hapus Produk?",
            message = "Produk '${product.name}' akan dihapus permanen dari inventaris Firestore.",
            confirmText = "Hapus",
            isDanger = true,
            onConfirm = {
                showDeleteConfirm = false
                onDelete()
            },
            onDismiss = { showDeleteConfirm = false }
        )
    }
}
