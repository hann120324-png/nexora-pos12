package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.core.DateFormatter
import com.example.core.ReceiptPrintHelper
import com.example.core.RupiahFormatter
import com.example.model.ApiSettings
import com.example.model.CartItem
import com.example.model.PosTransaction
import com.example.model.Product
import com.example.model.TransactionItem
import com.example.model.UiState
import com.example.model.UserProfile
import com.example.ui.components.BrutalButton
import com.example.ui.components.BrutalCard
import com.example.ui.components.BrutalIconButton
import com.example.ui.components.BrutalOutlinedButton
import com.example.ui.components.BrutalSectionHeader
import com.example.ui.components.BrutalStatCard
import com.example.ui.components.BrutalTextField
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.Lucide
import com.example.ui.components.LucideIcon
import com.example.ui.components.ErrorBannerCard
import com.example.ui.components.PremiumGateCard
import com.example.ui.components.SkeletonBox
import com.example.ui.components.StatusBadge
import com.example.ui.theme.BrutalBlack
import com.example.ui.theme.BrutalWhite
import com.example.ui.theme.CrimsonError
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.PrimaryYellow
import com.example.ui.theme.brutalAccentText
import com.example.ui.theme.brutalHighlightBorder

@Composable
fun PosCashierScreen(
    user: UserProfile,
    apiSettings: ApiSettings,
    products: List<Product>,
    cart: List<CartItem>,
    isCheckingOut: Boolean,
    onAddToCart: (Product) -> Unit,
    onUpdateQty: (String, Long) -> Unit,
    onRemoveFromCart: (String) -> Unit,
    onClearCart: () -> Unit,
    onOpenScanner: () -> Unit,
    onUpgradePremium: () -> Unit,
    onCheckout: (discount: Double, taxPercent: Double, method: String, paidAmount: Double, note: String) -> Unit,
    modifier: Modifier = Modifier
) {
    if (!user.isPremiumActive) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .padding(16.dp),
            contentAlignment = Alignment.Center
        ) {
            PremiumGateCard(
                featureName = "Kasir POS & Transaksi",
                onUpgradeClick = onUpgradePremium,
                modifier = Modifier.widthIn(max = 540.dp)
            )
        }
        return
    }

    var searchQuery by remember { mutableStateOf("") }
    var discountInput by remember { mutableStateOf("0") }
    var taxInput by remember { mutableStateOf("0") }
    var paymentMethod by remember { mutableStateOf("CASH") }
    var paidInput by remember { mutableStateOf("") }
    var noteInput by remember { mutableStateOf("") }

    val subtotal = remember(cart) { cart.sumOf { it.lineTotal } }
    val discount = (discountInput.toDoubleOrNull() ?: 0.0).coerceIn(0.0, subtotal)
    val taxPercent = (taxInput.toDoubleOrNull() ?: 0.0).coerceIn(0.0, 100.0)
    val taxable = (subtotal - discount).coerceAtLeast(0.0)
    val taxAmount = taxable * (taxPercent / 100.0)
    val total = (taxable + taxAmount).coerceAtLeast(0.0)
    val paidAmount = if (paymentMethod == "CASH") (paidInput.toDoubleOrNull() ?: 0.0) else total
    val changeAmount = (paidAmount - total).coerceAtLeast(0.0)

    val filteredProducts = remember(products, searchQuery) {
        val q = searchQuery.trim().lowercase()
        products.filter {
            q.isEmpty() || it.name.lowercase().contains(q) || it.sku.lowercase().contains(q)
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .widthIn(max = 960.dp),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            BrutalSectionHeader(
                title = "Kasir POS",
                icon = Lucide.ShoppingCart,
                subtitle = "Pilih barang, diskon, & pembayaran",
                trailing = {
                    BrutalOutlinedButton(
                        text = "Scan QR",
                        icon = Lucide.ScanLine,
                        onClick = onOpenScanner,
                        testTag = "pos_scan_button"
                    )
                }
            )
        }

        // Product Picker
        item {
            BrutalTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                label = "Pilih produk untuk ditambahkan ke keranjang...",
                leadingIcon = Lucide.Search,
                testTag = "pos_product_search"
            )
        }

        item {
            if (filteredProducts.isEmpty()) {
                Text("Tidak ada produk tersedia.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    filteredProducts.take(20).forEach { prod ->
                        BrutalCard(
                            modifier = Modifier
                                .widthIn(min = 160.dp, max = 190.dp)
                                .testTag("pos_pick_${prod.id}"),
                            onClick = { if (prod.stock > 0) onAddToCart(prod) },
                            contentPadding = 12.dp
                        ) {
                            Text(prod.name, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Spacer(Modifier.height(2.dp))
                            Text(RupiahFormatter.format(prod.sellPrice), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.brutalAccentText)
                            Text("Stok: ${prod.stock} ${prod.unit}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }

        // Cart Section
        item {
            BrutalCard(borderColor = MaterialTheme.colorScheme.outline, borderWidth = 1.5.dp) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            LucideIcon(Lucide.Receipt, contentDescription = null, tint = MaterialTheme.colorScheme.brutalAccentText, modifier = Modifier.size(18.dp))
                            Text("Keranjang (${cart.sumOf { it.quantity }} item)", style = MaterialTheme.typography.titleLarge)
                        }
                        if (cart.isNotEmpty()) {
                            BrutalOutlinedButton(
                                text = "Kosongkan",
                                icon = Lucide.Trash2,
                                onClick = onClearCart,
                                borderColor = CrimsonError,
                                contentColor = CrimsonError,
                                testTag = "pos_clear_cart_button"
                            )
                        }
                    }

                    if (cart.isEmpty()) {
                        Text(
                            "Keranjang masih kosong. Pilih produk di atas atau scan QR Code.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        cart.forEach { item ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(item.product.name, style = MaterialTheme.typography.titleMedium)
                                    Text(
                                        "${RupiahFormatter.format(item.product.sellPrice)} x ${item.quantity} = ${RupiahFormatter.format(item.lineTotal)}",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.brutalAccentText
                                    )
                                }
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    BrutalIconButton(
                                        icon = Lucide.Minus,
                                        contentDescription = "Kurangi",
                                        onClick = { onUpdateQty(item.product.id, item.quantity - 1) }
                                    )
                                    Text("${item.quantity}", style = MaterialTheme.typography.titleMedium)
                                    BrutalIconButton(
                                        icon = Lucide.Plus,
                                        contentDescription = "Tambah",
                                        onClick = { onUpdateQty(item.product.id, item.quantity + 1) }
                                    )
                                    BrutalIconButton(
                                        icon = Lucide.Trash2,
                                        contentDescription = "Hapus",
                                        tint = CrimsonError,
                                        borderColor = CrimsonError,
                                        onClick = { onRemoveFromCart(item.product.id) }
                                    )
                                }
                            }
                            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            BrutalTextField(
                                value = discountInput,
                                onValueChange = { discountInput = it.filter { c -> c.isDigit() } },
                                label = "Diskon (Rp)",
                                leadingIcon = Lucide.Banknote,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(1f),
                                testTag = "pos_discount_input"
                            )
                            BrutalTextField(
                                value = taxInput,
                                onValueChange = { taxInput = it.filter { c -> c.isDigit() } },
                                label = "Pajak (%)",
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(1f),
                                testTag = "pos_tax_input"
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            LucideIcon(Lucide.Wallet, contentDescription = null, tint = MaterialTheme.colorScheme.brutalAccentText, modifier = Modifier.size(18.dp))
                            Text("Metode Pembayaran", style = MaterialTheme.typography.titleMedium)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("CASH" to "Tunai", "TRANSFER" to "Transfer", "QRIS" to "QRIS").forEach { (key, label) ->
                                val selected = paymentMethod == key
                                Surface(
                                    shape = MaterialTheme.shapes.small,
                                    color = if (selected) PrimaryYellow else MaterialTheme.colorScheme.surfaceVariant,
                                    border = BorderStroke(
                                        1.5.dp,
                                        if (selected) MaterialTheme.colorScheme.brutalHighlightBorder else MaterialTheme.colorScheme.outlineVariant
                                    ),
                                    modifier = Modifier.weight(1f),
                                    onClick = { paymentMethod = key }
                                ) {
                                    Row(
                                        modifier = Modifier.padding(vertical = 10.dp, horizontal = 6.dp),
                                        horizontalArrangement = Arrangement.Center,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        LucideIcon(
                                            icon = when (key) {
                                                "QRIS" -> Lucide.QrCode
                                                "TRANSFER" -> Lucide.Wallet
                                                else -> Lucide.Banknote
                                            },
                                            contentDescription = null,
                                            tint = if (selected) BrutalBlack else MaterialTheme.colorScheme.onSurface,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(Modifier.size(6.dp))
                                        Text(
                                            label,
                                            style = MaterialTheme.typography.labelLarge,
                                            color = if (selected) BrutalBlack else MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                }
                            }
                        }

                        if (paymentMethod == "QRIS" && !apiSettings.qrisConfigured) {
                            ErrorBannerCard(
                                message = "Fitur pembayaran online QRIS belum tersedia (payment gateway belum dikonfigurasi oleh Admin). Gunakan Tunai atau Transfer."
                            )
                        }

                        if (paymentMethod == "CASH") {
                            BrutalTextField(
                                value = paidInput,
                                onValueChange = { paidInput = it.filter { c -> c.isDigit() } },
                                label = "Uang Diterima (Rp)",
                                leadingIcon = Lucide.Banknote,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                testTag = "pos_paid_input"
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Kembalian", style = MaterialTheme.typography.bodyLarge)
                                Text(
                                    RupiahFormatter.format(changeAmount),
                                    style = MaterialTheme.typography.titleMedium,
                                    color = EmeraldSuccess
                                )
                            }
                        }

                        BrutalTextField(
                            value = noteInput,
                            onValueChange = { noteInput = it },
                            label = "Catatan Transaksi (Opsional)",
                            testTag = "pos_note_input"
                        )

                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("TOTAL BAYAR", style = MaterialTheme.typography.titleLarge)
                            Text(
                                RupiahFormatter.format(total),
                                style = MaterialTheme.typography.headlineMedium,
                                color = MaterialTheme.colorScheme.brutalAccentText
                            )
                        }

                        BrutalButton(
                            text = if (isCheckingOut) "Memproses Transaksi..." else "Simpan & Selesaikan Transaksi",
                            icon = Lucide.CircleCheck,
                            enabled = !isCheckingOut && !(paymentMethod == "QRIS" && !apiSettings.qrisConfigured) && (paymentMethod != "CASH" || paidAmount >= total),
                            onClick = {
                                onCheckout(discount, taxPercent, paymentMethod, paidAmount, noteInput)
                            },
                            modifier = Modifier.fillMaxWidth(),
                            testTag = "pos_checkout_button"
                        )
                    }
                }
            }
        }

        item { Spacer(Modifier.height(64.dp)) }
    }
}

@Composable
fun TransactionsHistoryScreen(
    user: UserProfile,
    transactionsState: UiState<List<PosTransaction>>,
    onOpenTransaction: (String) -> Unit,
    onUpgradePremium: () -> Unit,
    onExportCsv: (Uri) -> Unit,
    modifier: Modifier = Modifier
) {
    var searchQuery by remember { mutableStateOf("") }
    var methodFilter by remember { mutableStateOf("ALL") }

    val exportCsvLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("text/csv")
    ) { uri ->
        if (uri != null) onExportCsv(uri)
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .widthIn(max = 960.dp),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            BrutalSectionHeader(
                title = "Transaksi & Riwayat",
                icon = Lucide.History,
                subtitle = "Daftar transaksi dan ekspor data",
                trailing = {
                    if (user.isPremiumActive) {
                        BrutalOutlinedButton(
                            text = "CSV",
                            icon = Lucide.Download,
                            onClick = { exportCsvLauncher.launch("nexora_transaksi.csv") },
                            testTag = "export_transactions_csv_button"
                        )
                    }
                }
            )
        }

        if (!user.isPremiumActive) {
            item {
                PremiumGateCard(
                    featureName = "Riwayat Transaksi Lengkap & Ekspor",
                    onUpgradeClick = onUpgradePremium
                )
            }
        } else {
            item {
                BrutalTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    label = "Cari ID transaksi atau produk...",
                    leadingIcon = Lucide.Search
                )
            }
            item {
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("ALL", "CASH", "TRANSFER", "QRIS").forEach { m ->
                        FilterChip(
                            selected = methodFilter == m,
                            onClick = { methodFilter = m },
                            shape = MaterialTheme.shapes.small,
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = PrimaryYellow,
                                selectedLabelColor = BrutalBlack
                            ),
                            label = { Text(if (m == "ALL") "Semua Metode" else m) }
                        )
                    }
                }
            }

            when (transactionsState) {
                is UiState.Loading -> items(3) { SkeletonBox(height = 88.dp) }
                is UiState.Error -> item { ErrorBannerCard(message = transactionsState.message) }
                is UiState.Success -> {
                    val filtered = transactionsState.data.filter { tx ->
                        val q = searchQuery.trim().lowercase()
                        val matchQ = q.isEmpty() || tx.id.lowercase().contains(q) || tx.itemsSummary.lowercase().contains(q)
                        val matchM = methodFilter == "ALL" || tx.paymentMethod == methodFilter
                        matchQ && matchM
                    }
                    if (filtered.isEmpty()) {
                        item {
                            EmptyStateCard(
                                title = "Belum Ada Transaksi",
                                subtitle = "Transaksi yang diselesaikan di Kasir POS akan muncul di sini.",
                                icon = Lucide.Receipt
                            )
                        }
                    } else {
                        items(filtered, key = { it.id }) { tx ->
                            BrutalCard(
                                onClick = { onOpenTransaction(tx.id) },
                                modifier = Modifier.testTag("tx_card_${tx.id}")
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("#${tx.id.take(10)} - ${tx.paymentMethod}", style = MaterialTheme.typography.titleMedium)
                                        Text(tx.itemsSummary, style = MaterialTheme.typography.bodyMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                        Text(DateFormatter.format(tx.createdAt), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text(RupiahFormatter.format(tx.total), style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.brutalAccentText)
                                        Spacer(Modifier.height(4.dp))
                                        StatusBadge(tx.paymentStatus)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        item { Spacer(Modifier.height(64.dp)) }
    }
}

@Composable
fun ReceiptPreviewScreen(
    user: UserProfile,
    transaction: PosTransaction,
    items: List<TransactionItem>,
    onLoadItems: () -> Unit,
    onBack: () -> Unit,
    onShowMessage: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onBack() }
    val context = LocalContext.current
    LaunchedEffect(transaction.id) { onLoadItems() }

    var paperWidth by remember { mutableStateOf(ReceiptPrintHelper.PaperWidth.MM_58) }
    val lines = remember(user, transaction, items) {
        ReceiptPrintHelper.buildReceiptLines(user, transaction, items)
    }

    val pdfLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri ->
        if (uri != null) {
            val ok = ReceiptPrintHelper.exportReceiptPdfToUri(context, uri, lines, paperWidth)
            onShowMessage(if (ok) "Struk PDF (${paperWidth.label}) berhasil disimpan." else "Gagal menyimpan struk PDF.")
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .widthIn(max = 760.dp),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                BrutalIconButton(
                    icon = Lucide.ArrowLeft,
                    contentDescription = "Kembali",
                    onClick = onBack
                )
                LucideIcon(Lucide.Receipt, contentDescription = null, tint = MaterialTheme.colorScheme.brutalAccentText, modifier = Modifier.size(20.dp))
                Text("Preview & Cetak Struk", style = MaterialTheme.typography.headlineMedium)
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ReceiptPrintHelper.PaperWidth.entries.forEach { widthOption ->
                    FilterChip(
                        selected = paperWidth == widthOption,
                        onClick = { paperWidth = widthOption },
                        shape = MaterialTheme.shapes.small,
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = PrimaryYellow,
                            selectedLabelColor = BrutalBlack
                        ),
                        label = { Text("Ukuran ${widthOption.label}") }
                    )
                }
            }
        }

        // Thermal paper preview
        item {
            Box(
                modifier = Modifier.fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = BrutalWhite,
                    modifier = Modifier
                        .widthIn(max = if (paperWidth == ReceiptPrintHelper.PaperWidth.MM_58) 290.dp else 380.dp)
                        .fillMaxWidth()
                        .border(2.dp, BrutalBlack, RoundedCornerShape(6.dp))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        lines.forEach { line ->
                            Text(
                                text = line,
                                color = BrutalBlack,
                                fontFamily = FontFamily.Monospace,
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                    }
                }
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                BrutalOutlinedButton(
                    text = "Unduh PDF",
                    icon = Lucide.FileText,
                    onClick = { pdfLauncher.launch("Struk_NEXORA_${transaction.id.take(8)}.pdf") },
                    modifier = Modifier.weight(1f),
                    testTag = "download_receipt_pdf_button"
                )
                BrutalButton(
                    text = "Cetak Struk",
                    icon = Lucide.Printer,
                    onClick = {
                        ReceiptPrintHelper.printReceipt(context, transaction.id, lines, paperWidth)
                    },
                    modifier = Modifier.weight(1f),
                    testTag = "print_receipt_button"
                )
            }
        }

        item {
            BrutalCard {
                Text(
                    "Catatan Kompatibilitas Printer: Fitur cetak menggunakan Android Print Service (mendukung printer Wi-Fi, driver cetak sistem, dan simpan PDF). Kompatibilitas printer thermal Bluetooth bergantung pada aplikasi layanan cetak masing-masing vendor printer.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
fun ReportsScreen(
    user: UserProfile,
    transactionsState: UiState<List<PosTransaction>>,
    products: List<Product>,
    onUpgradePremium: () -> Unit,
    onExportCsv: (Uri) -> Unit,
    modifier: Modifier = Modifier
) {
    if (!user.isPremiumActive) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .padding(16.dp),
            contentAlignment = Alignment.Center
        ) {
            PremiumGateCard(
                featureName = "Laporan Penjualan & Keuntungan",
                onUpgradeClick = onUpgradePremium,
                modifier = Modifier.widthIn(max = 540.dp)
            )
        }
        return
    }

    val exportCsvLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("text/csv")
    ) { uri ->
        if (uri != null) onExportCsv(uri)
    }

    val txs = (transactionsState as? UiState.Success)?.data?.filter { it.paymentStatus != "CANCELLED" } ?: emptyList()
    val totalRevenue = txs.sumOf { it.total }
    val totalProfit = txs.sumOf { it.totalProfit }
    val totalDiscount = txs.sumOf { it.discount }
    val totalItemsSold = txs.sumOf { it.itemsCount }
    val marginPct = if (totalRevenue > 0) (totalProfit / totalRevenue) * 100.0 else 0.0
    val inventoryValuation = products.sumOf { it.costPrice * it.stock }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .widthIn(max = 960.dp),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            BrutalSectionHeader(
                title = "Laporan & Statistik",
                icon = Lucide.ChartNoAxesCombined,
                subtitle = "Omzet, profitabilitas & valuasi stok",
                trailing = {
                    BrutalButton(
                        text = "Ekspor CSV",
                        icon = Lucide.Download,
                        onClick = { exportCsvLauncher.launch("laporan_nexora.csv") },
                        testTag = "reports_export_csv_button"
                    )
                }
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                BrutalStatCard(
                    title = "Omzet Penjualan",
                    value = RupiahFormatter.format(totalRevenue),
                    icon = Lucide.Banknote,
                    accentColor = PrimaryYellow,
                    modifier = Modifier.weight(1f)
                )
                BrutalStatCard(
                    title = "Keuntungan Bersih",
                    value = RupiahFormatter.format(totalProfit),
                    icon = Lucide.TrendingUp,
                    accentColor = EmeraldSuccess,
                    subtitle = String.format("Margin %.1f%%", marginPct),
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            BrutalCard(borderColor = MaterialTheme.colorScheme.outline) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Rincian Bisnis", style = MaterialTheme.typography.titleLarge)
                    ReportRow("Total Diskon Diberikan", RupiahFormatter.format(totalDiscount))
                    ReportRow("Jumlah Transaksi", "${txs.size}")
                    ReportRow("Total Unit Terjual", "$totalItemsSold unit")
                    ReportRow("Nilai Modal Inventaris Saat Ini", RupiahFormatter.format(inventoryValuation))
                }
            }
        }

        item {
            BrutalCard {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        LucideIcon(Lucide.Wallet, contentDescription = null, tint = MaterialTheme.colorScheme.brutalAccentText, modifier = Modifier.size(18.dp))
                        Text("Distribusi Metode Pembayaran", style = MaterialTheme.typography.titleLarge)
                    }
                    val grouped = txs.groupBy { it.paymentMethod }
                    if (grouped.isEmpty()) {
                        Text("Belum ada data transaksi.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    } else {
                        grouped.forEach { (method, list) ->
                            ReportRow("$method (${list.size}x)", RupiahFormatter.format(list.sumOf { it.total }))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ReportRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.titleMedium)
    }
}
