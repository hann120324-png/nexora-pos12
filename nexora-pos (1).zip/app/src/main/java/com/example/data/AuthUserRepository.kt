package com.example.data

import android.content.Context
import com.example.core.OperationType
import com.example.core.getNexoraFirestore
import com.example.core.handleFirestoreError
import com.example.model.ApiSettings
import com.example.model.AppSettings
import com.example.model.AuditLog
import com.example.model.UserProfile
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class AuthUserRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    constructor(context: Context) : this(getNexoraFirestore(context))

    private fun requireUserId(): String =
        auth.currentUser?.uid ?: throw IllegalStateException("Pengguna harus login terlebih dahulu.")

    fun observePublicAppSettings(): Flow<AppSettings> =
        db.collection("app_settings").document("config")
            .snapshots()
            .map { snap ->
                if (snap.exists()) {
                    snap.toObject(AppSettings::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        ?: AppSettings()
                } else {
                    AppSettings()
                }
            }
            .catch { error ->
                val fsErr = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (fsErr == null && error is CancellationException) throw error
                emit(AppSettings())
            }

    fun observeApiSettings(): Flow<ApiSettings> =
        db.collection("api_settings").document("public_config")
            .snapshots()
            .map { snap ->
                if (snap.exists()) {
                    snap.toObject(ApiSettings::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        ?: ApiSettings()
                } else {
                    ApiSettings()
                }
            }
            .catch { error ->
                val fsErr = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (fsErr == null && error is CancellationException) throw error
                emit(ApiSettings())
            }

    fun observeUserProfile(userId: String): Flow<UserProfile?> = flow {
        val docRef = db.collection("users").document(userId)
        docRef.snapshots()
            .map { snap ->
                if (snap.exists()) {
                    snap.toObject(UserProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                } else null
            }
            .catch { error ->
                val fsErr = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (fsErr == null && error is CancellationException) throw error
                if (auth.currentUser?.uid == userId) {
                    handleFirestoreError(fsErr ?: error, OperationType.GET, docRef.path)
                }
                throw error
            }
            .collect { emit(it) }
    }

    suspend fun ensureUserProfileExists(firebaseUser: FirebaseUser): Result<UserProfile> {
        val uid = firebaseUser.uid
        val path = "users/$uid"
        return try {
            val docRef = db.collection("users").document(uid)
            val snap = docRef.get().await()
            if (snap.exists()) {
                val existing = snap.toObject(
                    UserProfile::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                ) ?: UserProfile(userId = uid)
                return Result.success(existing)
            }

            val isBootstrap = firebaseUser.isEmailVerified &&
                firebaseUser.email.equals(BOOTSTRAP_ADMIN_EMAIL, ignoreCase = true)
            val initialRole = if (isBootstrap) "ADMIN" else "USER"
            val initialPremiumStatus = if (isBootstrap) "active" else "free"
            val initialPremiumType = if (isBootstrap) "lifetime" else "none"

            val payload = mapOf(
                "userId" to uid,
                "name" to (firebaseUser.displayName?.takeIf { it.isNotBlank() } ?: "Pengguna NEXORA").take(80),
                "email" to (firebaseUser.email ?: "$uid@nexorapos.id").take(160),
                "photoUrl" to firebaseUser.photoUrl?.toString()?.take(250_000),
                "role" to initialRole,
                "accountStatus" to "active",
                "premiumStatus" to initialPremiumStatus,
                "premiumType" to initialPremiumType,
                "storeName" to "Toko ${firebaseUser.displayName?.split(" ")?.firstOrNull() ?: "NEXORA"}".take(80),
                "darkMode" to false,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp(),
            ).filterValues { it != null } as Map<String, Any>

            docRef.set(payload).await()

            // Create welcome notification
            val notifRef = db.collection("notifications").document()
            notifRef.set(
                mapOf(
                    "userId" to uid,
                    "title" to "Selamat Datang di NEXORA POS",
                    "body" to "Akun Anda berhasil dibuat dan siap digunakan. Kelola produk & bisnis lebih cepat.",
                    "type" to "ACCOUNT_CREATED",
                    "read" to false,
                    "createdAt" to FieldValue.serverTimestamp()
                )
            ).await()

            if (isBootstrap) {
                db.collection("admins").document(uid).set(
                    mapOf(
                        "userId" to uid,
                        "email" to (firebaseUser.email ?: BOOTSTRAP_ADMIN_EMAIL),
                        "grantedBy" to "system_bootstrap",
                        "createdAt" to FieldValue.serverTimestamp()
                    )
                ).await()
                seedDefaultSettingsIfMissing()
            }

            val created = docRef.get().await()
                .toObject(UserProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                ?: UserProfile(userId = uid, name = payload["name"] as String, email = payload["email"] as String, role = initialRole)
            Result.success(created)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    private suspend fun seedDefaultSettingsIfMissing() {
        val appRef = db.collection("app_settings").document("config")
        if (!appRef.get().await().exists()) {
            val defaults = AppSettings()
            appRef.set(
                mapOf(
                    "appName" to defaults.appName,
                    "tagline" to defaults.tagline,
                    "description" to defaults.description,
                    "premiumPrice" to defaults.premiumPrice,
                    "paymentInstructions" to defaults.paymentInstructions,
                    "whatsappNumber" to defaults.whatsappNumber,
                    "supportContact" to defaults.supportContact,
                    "announcement" to "",
                    "maintenanceMode" to false,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        }
        val apiRef = db.collection("api_settings").document("public_config")
        if (!apiRef.get().await().exists()) {
            val defaults = ApiSettings()
            apiRef.set(
                mapOf(
                    "nexaSendConfigured" to defaults.nexaSendConfigured,
                    "nexaSendEndpoint" to defaults.nexaSendEndpoint,
                    "reactionConfigured" to defaults.reactionConfigured,
                    "reactionEndpoint" to defaults.reactionEndpoint,
                    "voteConfigured" to defaults.voteConfigured,
                    "voteEndpoint" to defaults.voteEndpoint,
                    "qrisConfigured" to defaults.qrisConfigured,
                    "qrisProviderName" to defaults.qrisProviderName,
                    "aiCsConfigured" to defaults.aiCsConfigured,
                    "aiModelName" to defaults.aiModelName,
                    "aiSystemPrompt" to defaults.aiSystemPrompt,
                    "aiMaxTokens" to defaults.aiMaxTokens,
                    "aiTemperature" to defaults.aiTemperature,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        }
    }

    suspend fun updateProfile(
        name: String,
        storeName: String,
        storeAddress: String,
        storePhone: String,
        photoUrl: String?,
        storeLogoUrl: String?,
        darkMode: Boolean? = null
    ): Result<Unit> {
        val uid = auth.currentUser?.uid
        val path = "users/${uid ?: "unauth"}"
        return try {
            val validUid = requireUserId()
            require(name.trim().isNotEmpty()) { "Nama tidak boleh kosong." }
            val updates = mutableMapOf<String, Any>(
                "name" to name.trim().take(80),
                "storeName" to storeName.trim().take(80),
                "storeAddress" to storeAddress.trim().take(200),
                "storePhone" to storePhone.trim().take(30),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            if (!photoUrl.isNullOrBlank()) updates["photoUrl"] = photoUrl.take(250_000)
            if (!storeLogoUrl.isNullOrBlank()) updates["storeLogoUrl"] = storeLogoUrl.take(250_000)
            if (darkMode != null) updates["darkMode"] = darkMode
            db.collection("users").document(validUid).update(updates).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun updateDarkMode(enabled: Boolean): Result<Unit> {
        val path = "users/${auth.currentUser?.uid ?: "unauth"}"
        return try {
            val uid = requireUserId()
            db.collection("users").document(uid).update(
                mapOf("darkMode" to enabled, "updatedAt" to FieldValue.serverTimestamp())
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    // --- ADMIN OPERATIONS ---

    fun observeAllUsers(): Flow<List<UserProfile>> =
        db.collection("users")
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .snapshots()
            .map { it.toObjects(UserProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }

    fun observeAuditLogs(): Flow<List<AuditLog>> =
        db.collection("audit_logs")
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .limit(100)
            .snapshots()
            .map { it.toObjects(AuditLog::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }

    suspend fun adminUpdateUserStatus(
        targetUid: String,
        role: String,
        accountStatus: String,
        premiumStatus: String,
        premiumType: String
    ): Result<Unit> {
        val path = "users/$targetUid"
        return try {
            val adminUid = requireUserId()
            val adminEmail = auth.currentUser?.email ?: "admin"
            val batch = db.batch()
            val userRef = db.collection("users").document(targetUid)
            val updates = mutableMapOf<String, Any>(
                "role" to role,
                "accountStatus" to accountStatus,
                "premiumStatus" to premiumStatus,
                "premiumType" to premiumType,
                "updatedAt" to FieldValue.serverTimestamp()
            )
            if (premiumStatus == "active" && premiumType == "lifetime") {
                updates["premiumActivatedAt"] = FieldValue.serverTimestamp()
            }
            batch.update(userRef, updates)

            val adminDocRef = db.collection("admins").document(targetUid)
            if (role == "ADMIN") {
                val targetSnap = userRef.get().await()
                val targetEmail = targetSnap.getString("email") ?: "admin@nexorapos.id"
                batch.set(
                    adminDocRef,
                    mapOf(
                        "userId" to targetUid,
                        "email" to targetEmail,
                        "grantedBy" to adminUid,
                        "createdAt" to FieldValue.serverTimestamp()
                    )
                )
            } else if (targetUid != adminUid) {
                batch.delete(adminDocRef)
            }

            val logRef = db.collection("audit_logs").document()
            batch.set(
                logRef,
                mapOf(
                    "actorUid" to adminUid,
                    "actorEmail" to adminEmail,
                    "action" to "UPDATE_USER_STATUS",
                    "targetId" to targetUid,
                    "detail" to "role=$role, accountStatus=$accountStatus, premium=$premiumStatus ($premiumType)",
                    "createdAt" to FieldValue.serverTimestamp()
                )
            )
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun adminSaveAppSettings(settings: AppSettings): Result<Unit> {
        val path = "app_settings/config"
        return try {
            val adminUid = requireUserId()
            val adminEmail = auth.currentUser?.email ?: "admin"
            val batch = db.batch()
            batch.set(
                db.document(path),
                mapOf(
                    "appName" to settings.appName.trim().take(60),
                    "tagline" to settings.tagline.trim().take(120),
                    "description" to settings.description.trim().take(500),
                    "premiumPrice" to settings.premiumPrice.coerceAtLeast(0.0),
                    "paymentInstructions" to settings.paymentInstructions.trim().take(1000),
                    "whatsappNumber" to settings.whatsappNumber.trim().take(30),
                    "supportContact" to settings.supportContact.trim().take(120),
                    "announcement" to settings.announcement.trim().take(500),
                    "maintenanceMode" to settings.maintenanceMode,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            batch.set(
                db.collection("audit_logs").document(),
                mapOf(
                    "actorUid" to adminUid,
                    "actorEmail" to adminEmail,
                    "action" to "UPDATE_APP_SETTINGS",
                    "targetId" to "config",
                    "detail" to "premiumPrice=${settings.premiumPrice}, maintenance=${settings.maintenanceMode}",
                    "createdAt" to FieldValue.serverTimestamp()
                )
            )
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun adminSaveApiSettings(settings: ApiSettings): Result<Unit> {
        val path = "api_settings/public_config"
        return try {
            val adminUid = requireUserId()
            val adminEmail = auth.currentUser?.email ?: "admin"
            val batch = db.batch()
            batch.set(
                db.document(path),
                mapOf(
                    "nexaSendConfigured" to settings.nexaSendConfigured,
                    "nexaSendEndpoint" to settings.nexaSendEndpoint.trim().take(300),
                    "reactionConfigured" to settings.reactionConfigured,
                    "reactionEndpoint" to settings.reactionEndpoint.trim().take(300),
                    "voteConfigured" to settings.voteConfigured,
                    "voteEndpoint" to settings.voteEndpoint.trim().take(300),
                    "qrisConfigured" to settings.qrisConfigured,
                    "qrisProviderName" to settings.qrisProviderName.trim().take(80),
                    "aiCsConfigured" to settings.aiCsConfigured,
                    "aiModelName" to settings.aiModelName.trim().ifBlank { "gemini-3.8-flash" }.take(80),
                    "aiSystemPrompt" to settings.aiSystemPrompt.trim().take(2000),
                    "aiMaxTokens" to settings.aiMaxTokens.coerceIn(64L, 8192L),
                    "aiTemperature" to settings.aiTemperature.coerceIn(0.0, 2.0),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            batch.set(
                db.collection("audit_logs").document(),
                mapOf(
                    "actorUid" to adminUid,
                    "actorEmail" to adminEmail,
                    "action" to "UPDATE_API_SETTINGS",
                    "targetId" to "public_config",
                    "detail" to "qris=${settings.qrisConfigured}, nexaSend=${settings.nexaSendConfigured}, aiModel=${settings.aiModelName}",
                    "createdAt" to FieldValue.serverTimestamp()
                )
            )
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun adminBroadcastAnnouncement(title: String, body: String, targetUids: List<String>): Result<Unit> {
        return try {
            val adminUid = requireUserId()
            val adminEmail = auth.currentUser?.email ?: "admin"
            val batch = db.batch()
            targetUids.take(200).forEach { uid ->
                val ref = db.collection("notifications").document()
                batch.set(
                    ref,
                    mapOf(
                        "userId" to uid,
                        "title" to title.trim().take(120),
                        "body" to body.trim().take(500),
                        "type" to "ANNOUNCEMENT",
                        "read" to false,
                        "createdAt" to FieldValue.serverTimestamp()
                    )
                )
            }
            batch.set(
                db.collection("audit_logs").document(),
                mapOf(
                    "actorUid" to adminUid,
                    "actorEmail" to adminEmail,
                    "action" to "BROADCAST_NOTIFICATION",
                    "targetId" to "${targetUids.size}_users",
                    "detail" to title.take(120),
                    "createdAt" to FieldValue.serverTimestamp()
                )
            )
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, "notifications")
            Result.failure(e)
        }
    }

    companion object {
        const val BOOTSTRAP_ADMIN_EMAIL = "hptra112@gmail.com"
    }
}
