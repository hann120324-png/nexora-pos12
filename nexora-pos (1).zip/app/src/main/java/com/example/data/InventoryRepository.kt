package com.example.data

import android.content.Context
import com.example.core.OperationType
import com.example.core.getNexoraFirestore
import com.example.core.handleFirestoreError
import com.example.model.Category
import com.example.model.Product
import com.example.model.StockMovement
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.flow.map

class InventoryRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    constructor(context: Context) : this(getNexoraFirestore(context))

    private fun requireUserId(): String =
        auth.currentUser?.uid ?: throw IllegalStateException("Pengguna harus login.")

    fun observeProducts(userId: String): Flow<List<Product>> = flow {
        val path = "products"
        db.collection(path)
            .whereEqualTo("userId", userId)
            .snapshots()
            .map { snap ->
                snap.toObjects(Product::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.updatedAt?.seconds ?: 0L }
            }
            .catch { error ->
                val fsErr = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (fsErr == null && error is CancellationException) throw error
                if (auth.currentUser?.uid == userId) {
                    handleFirestoreError(fsErr ?: error, OperationType.LIST, path)
                }
                throw error
            }
            .collect { emit(it) }
    }

    fun observeAllProductsAdmin(): Flow<List<Product>> =
        db.collection("products")
            .limit(300)
            .snapshots()
            .map { it.toObjects(Product::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }

    fun observeCategories(userId: String): Flow<List<Category>> = flow {
        val path = "categories"
        db.collection(path)
            .whereEqualTo("userId", userId)
            .snapshots()
            .map { snap ->
                snap.toObjects(Category::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedBy { it.name.lowercase() }
            }
            .catch { error ->
                val fsErr = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (fsErr == null && error is CancellationException) throw error
                if (auth.currentUser?.uid == userId) {
                    handleFirestoreError(fsErr ?: error, OperationType.LIST, path)
                }
                throw error
            }
            .collect { emit(it) }
    }

    fun observeStockMovements(userId: String, productId: String? = null): Flow<List<StockMovement>> = flow {
        val path = "stock_movements"
        var query: Query = db.collection(path).whereEqualTo("userId", userId)
        if (!productId.isNullOrBlank()) {
            query = query.whereEqualTo("productId", productId)
        }
        query.snapshots()
            .map { snap ->
                snap.toObjects(StockMovement::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt?.seconds ?: 0L }
            }
            .catch { error ->
                val fsErr = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (fsErr == null && error is CancellationException) throw error
                if (auth.currentUser?.uid == userId) {
                    handleFirestoreError(fsErr ?: error, OperationType.LIST, path)
                }
                throw error
            }
            .collect { emit(it) }
    }

    suspend fun saveProduct(product: Product): Result<String> {
        var path = "products"
        return try {
            val uid = requireUserId()
            require(product.name.trim().isNotEmpty()) { "Nama produk wajib diisi." }
            require(product.sku.trim().isNotEmpty()) { "SKU produk wajib diisi." }
            require(product.sellPrice >= 0.0 && product.costPrice >= 0.0) { "Harga tidak valid." }
            require(product.stock >= 0L) { "Stok tidak boleh negatif." }

            if (product.id.isBlank()) {
                val docRef = db.collection("products").document()
                path = docRef.path
                val qrValue = product.qrCode.ifBlank { "NEXORA:${docRef.id}:${product.sku.trim()}" }
                val payload = product.copy(qrCode = qrValue).toCreateMap(uid)
                val batch = db.batch()
                batch.set(docRef, payload)
                if (product.stock > 0L) {
                    val movRef = db.collection("stock_movements").document()
                    batch.set(
                        movRef,
                        mapOf(
                            "userId" to uid,
                            "productId" to docRef.id,
                            "productName" to product.name.trim().take(120),
                            "delta" to product.stock,
                            "stockAfter" to product.stock,
                            "reason" to "Stok awal produk",
                            "createdAt" to FieldValue.serverTimestamp()
                        )
                    )
                }
                batch.commit().await()
                Result.success(docRef.id)
            } else {
                val docRef = db.collection("products").document(product.id)
                path = docRef.path
                val updates = mapOf(
                    "name" to product.name.trim().take(120),
                    "sku" to product.sku.trim().take(64),
                    "barcode" to product.barcode.trim().take(128),
                    "qrCode" to product.qrCode.ifBlank { "NEXORA:${product.id}:${product.sku.trim()}" }.take(256),
                    "category" to product.category.trim().ifBlank { "Umum" }.take(60),
                    "description" to product.description.trim().take(500),
                    "costPrice" to product.costPrice.coerceAtLeast(0.0),
                    "sellPrice" to product.sellPrice.coerceAtLeast(0.0),
                    "stock" to product.stock.coerceAtLeast(0L),
                    "lowStockThreshold" to product.lowStockThreshold.coerceAtLeast(0L),
                    "unit" to product.unit.trim().ifBlank { "pcs" }.take(30),
                    "photoUrl" to product.photoUrl.take(250_000),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                docRef.update(updates).await()
                Result.success(product.id)
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun adjustStock(product: Product, delta: Long, reason: String): Result<Unit> {
        val path = "products/${product.id}"
        return try {
            val uid = requireUserId()
            require(product.id.isNotBlank()) { "ID produk tidak valid." }
            db.runTransaction { tx ->
                val prodRef = db.collection("products").document(product.id)
                val snap = tx.get(prodRef)
                val currentStock = snap.getLong("stock") ?: 0L
                val newStock = (currentStock + delta).coerceAtLeast(0L)
                tx.update(
                    prodRef,
                    mapOf(
                        "stock" to newStock,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
                val movRef = db.collection("stock_movements").document()
                tx.set(
                    movRef,
                    mapOf(
                        "userId" to uid,
                        "productId" to product.id,
                        "productName" to product.name.take(120),
                        "delta" to delta,
                        "stockAfter" to newStock,
                        "reason" to reason.trim().ifBlank { "Penyesuaian stok" }.take(100),
                        "createdAt" to FieldValue.serverTimestamp()
                    )
                )
            }.await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun deleteProduct(productId: String): Result<Unit> {
        val path = "products/$productId"
        return try {
            requireUserId()
            require(productId.isNotBlank()) { "ID produk kosong." }
            db.collection("products").document(productId).delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    suspend fun addCategory(name: String): Result<Unit> {
        val path = "categories"
        return try {
            val uid = requireUserId()
            val clean = name.trim().take(60)
            require(clean.isNotEmpty()) { "Nama kategori tidak boleh kosong." }
            db.collection(path).document().set(
                mapOf(
                    "userId" to uid,
                    "name" to clean,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun deleteCategory(categoryId: String): Result<Unit> {
        val path = "categories/$categoryId"
        return try {
            requireUserId()
            db.document(path).delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    suspend fun findProductByCode(userId: String, code: String): Product? {
        val clean = code.trim()
        if (clean.isBlank()) return null
        return try {
            val all = db.collection("products")
                .whereEqualTo("userId", userId)
                .get()
                .await()
                .toObjects(Product::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            all.firstOrNull {
                it.barcode.equals(clean, ignoreCase = true) ||
                    it.sku.equals(clean, ignoreCase = true) ||
                    it.qrCode.equals(clean, ignoreCase = true) ||
                    it.id.equals(clean, ignoreCase = true) ||
                    clean.startsWith("NEXORA:${it.id}:")
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.LIST, "products")
            null
        }
    }
}
