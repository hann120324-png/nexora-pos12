package com.example.data

import android.content.Context
import com.example.core.OperationType
import com.example.core.getNexoraFirestore
import com.example.core.handleFirestoreError
import com.example.model.AiConversation
import com.example.model.AiMessage
import com.example.model.AppNotification
import com.example.model.Complaint
import com.example.model.ComplaintMessage
import com.example.model.PremiumHistory
import com.example.model.PremiumRequest
import com.example.model.ToolHistory
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import com.google.firebase.functions.FirebaseFunctions
import com.google.firebase.functions.FirebaseFunctionsException
import com.google.firebase.functions.functions
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

class SupportPremiumRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth,
    private val functions: FirebaseFunctions = Firebase.functions
) {
    constructor(context: Context) : this(getNexoraFirestore(context))

    private val okHttp = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    private fun requireUserId(): String =
        auth.currentUser?.uid ?: throw IllegalStateException("Pengguna harus login.")

    // --- PREMIUM REQUESTS & APPROVAL ---

    fun observeUserPremiumRequests(userId: String): Flow<List<PremiumRequest>> = flow {
        val path = "premium_requests"
        db.collection(path)
            .whereEqualTo("userId", userId)
            .snapshots()
            .map { snap ->
                snap.toObjects(PremiumRequest::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt?.seconds ?: 0L }
            }
            .catch { error ->
                val fsErr = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (fsErr == null && error is CancellationException) throw error
                if (auth.currentUser?.uid == userId) {
                    handleFirestoreError(fsErr ?: error, OperationType.LIST, path)
                }
                throw error
            }
            .collect { emit(it) }
    }

    fun observeAllPremiumRequestsAdmin(): Flow<List<PremiumRequest>> =
        db.collection("premium_requests")
            .snapshots()
            .map { snap ->
                snap.toObjects(PremiumRequest::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt?.seconds ?: 0L }
            }

    fun observePremiumHistoryAdmin(): Flow<List<PremiumHistory>> =
        db.collection("premium_history")
            .snapshots()
            .map { snap ->
                snap.toObjects(PremiumHistory::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt?.seconds ?: 0L }
            }

    suspend fun submitPremiumRequest(
        userName: String,
        userEmail: String,
        amount: Double,
        paymentMethod: String,
        proofUrl: String?,
        note: String?
    ): Result<String> {
        val path = "premium_requests"
        return try {
            val uid = requireUserId()
            require(amount > 0.0) { "Nominal Premium tidak valid." }
            val safeEmail = userEmail.trim()
                .ifBlank { auth.currentUser?.email ?: "$uid@nexorapos.id" }
                .take(160)
            val safeMethod = paymentMethod.trim()
                .ifBlank { "Transfer Bank" }
                .take(60)
            val reqRef = db.collection(path).document()
            val batch = db.batch()
            val payload = mapOf(
                "userId" to uid,
                "userName" to userName.trim().ifBlank { "User" }.take(80),
                "userEmail" to safeEmail,
                "amount" to amount,
                "paymentMethod" to safeMethod,
                "proofUrl" to proofUrl?.takeIf { it.isNotBlank() }?.take(250_000),
                "note" to note?.trim()?.takeIf { it.isNotBlank() }?.take(300),
                "status" to "PENDING",
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            ).filterValues { it != null } as Map<String, Any>
            batch.set(reqRef, payload)

            batch.update(
                db.collection("users").document(uid),
                mapOf(
                    "premiumStatus" to "pending",
                    "premiumRequestId" to reqRef.id,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )

            batch.set(
                db.collection("notifications").document(),
                mapOf(
                    "userId" to uid,
                    "title" to "Permintaan Premium Diterima",
                    "body" to "Permintaan upgrade Premium Lifetime (${reqRef.id.take(8)}) menunggu verifikasi Admin.",
                    "type" to "PREMIUM_REQUESTED",
                    "read" to false,
                    "referenceId" to reqRef.id,
                    "createdAt" to FieldValue.serverTimestamp()
                )
            )
            batch.commit().await()
            Result.success(reqRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun updatePendingPremiumProof(requestId: String, proofUrl: String, note: String?): Result<Unit> {
        val path = "premium_requests/$requestId"
        return try {
            requireUserId()
            val updates = mutableMapOf<String, Any>(
                "proofUrl" to proofUrl.take(250_000),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            if (!note.isNullOrBlank()) updates["note"] = note.trim().take(300)
            db.document(path).update(updates).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun adminApprovePremiumRequest(request: PremiumRequest): Result<Unit> {
        val path = "premium_requests/${request.id}"
        return try {
            val adminUid = requireUserId()
            val adminEmail = auth.currentUser?.email ?: "admin"
            db.runTransaction { tx ->
                val reqRef = db.collection("premium_requests").document(request.id)
                val reqSnap = tx.get(reqRef)
                val currentStatus = reqSnap.getString("status")
                if (currentStatus != "PENDING") {
                    throw IllegalStateException("Permintaan ini sudah diproses ($currentStatus).")
                }

                tx.update(
                    reqRef,
                    mapOf(
                        "status" to "APPROVED",
                        "reviewedBy" to adminUid,
                        "reviewedAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )

                val userRef = db.collection("users").document(request.userId)
                tx.update(
                    userRef,
                    mapOf(
                        "premiumStatus" to "active",
                        "premiumType" to "lifetime",
                        "premiumActivatedAt" to FieldValue.serverTimestamp(),
                        "premiumExpiresAt" to null,
                        "premiumRequestId" to request.id,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )

                val histRef = db.collection("premium_history").document()
                tx.set(
                    histRef,
                    mapOf(
                        "userId" to request.userId,
                        "requestId" to request.id,
                        "action" to "APPROVED",
                        "amount" to request.amount,
                        "adminUid" to adminUid,
                        "reason" to "Disetujui Admin",
                        "createdAt" to FieldValue.serverTimestamp()
                    )
                )

                val notifRef = db.collection("notifications").document()
                tx.set(
                    notifRef,
                    mapOf(
                        "userId" to request.userId,
                        "title" to "Premium Lifetime Aktif!",
                        "body" to "Selamat! Pembayaran Premium Lifetime Anda telah disetujui. Semua fitur POS, struk, laporan, tools, dan AI CS kini aktif selamanya.",
                        "type" to "PREMIUM_APPROVED",
                        "read" to false,
                        "referenceId" to request.id,
                        "createdAt" to FieldValue.serverTimestamp()
                    )
                )

                val logRef = db.collection("audit_logs").document()
                tx.set(
                    logRef,
                    mapOf(
                        "actorUid" to adminUid,
                        "actorEmail" to adminEmail,
                        "action" to "APPROVE_PREMIUM",
                        "targetId" to request.userId,
                        "detail" to "Approved request ${request.id} (Rp${request.amount.toLong()})",
                        "createdAt" to FieldValue.serverTimestamp()
                    )
                )
            }.await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun adminRejectPremiumRequest(request: PremiumRequest, reason: String): Result<Unit> {
        val path = "premium_requests/${request.id}"
        return try {
            val adminUid = requireUserId()
            val adminEmail = auth.currentUser?.email ?: "admin"
            val cleanReason = reason.trim()
            require(cleanReason.isNotEmpty()) { "Alasan penolakan wajib diisi." }

            db.runTransaction { tx ->
                val reqRef = db.collection("premium_requests").document(request.id)
                val reqSnap = tx.get(reqRef)
                val currentStatus = reqSnap.getString("status")
                if (currentStatus != "PENDING") {
                    throw IllegalStateException("Permintaan ini sudah diproses ($currentStatus).")
                }

                tx.update(
                    reqRef,
                    mapOf(
                        "status" to "REJECTED",
                        "rejectionReason" to cleanReason.take(300),
                        "reviewedBy" to adminUid,
                        "reviewedAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )

                tx.update(
                    db.collection("users").document(request.userId),
                    mapOf(
                        "premiumStatus" to "rejected",
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )

                tx.set(
                    db.collection("premium_history").document(),
                    mapOf(
                        "userId" to request.userId,
                        "requestId" to request.id,
                        "action" to "REJECTED",
                        "amount" to request.amount,
                        "adminUid" to adminUid,
                        "reason" to cleanReason.take(300),
                        "createdAt" to FieldValue.serverTimestamp()
                    )
                )

                tx.set(
                    db.collection("notifications").document(),
                    mapOf(
                        "userId" to request.userId,
                        "title" to "Permintaan Premium Ditolak",
                        "body" to "Alasan: $cleanReason. Anda dapat mengajukan ulang atau menghubungi Admin via WhatsApp.",
                        "type" to "PREMIUM_REJECTED",
                        "read" to false,
                        "referenceId" to request.id,
                        "createdAt" to FieldValue.serverTimestamp()
                    )
                )

                tx.set(
                    db.collection("audit_logs").document(),
                    mapOf(
                        "actorUid" to adminUid,
                        "actorEmail" to adminEmail,
                        "action" to "REJECT_PREMIUM",
                        "targetId" to request.userId,
                        "detail" to "Rejected request ${request.id}: $cleanReason",
                        "createdAt" to FieldValue.serverTimestamp()
                    )
                )
            }.await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    // --- COMPLAINTS & CHAT ---

    fun observeUserComplaints(userId: String): Flow<List<Complaint>> = flow {
        val path = "complaints"
        db.collection(path)
            .whereEqualTo("userId", userId)
            .snapshots()
            .map { snap ->
                snap.toObjects(Complaint::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.updatedAt?.seconds ?: 0L }
            }
            .catch { error ->
                val fsErr = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (fsErr == null && error is CancellationException) throw error
                if (auth.currentUser?.uid == userId) {
                    handleFirestoreError(fsErr ?: error, OperationType.LIST, path)
                }
                throw error
            }
            .collect { emit(it) }
    }

    fun observeAllComplaintsAdmin(): Flow<List<Complaint>> =
        db.collection("complaints")
            .snapshots()
            .map { snap ->
                snap.toObjects(Complaint::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.updatedAt?.seconds ?: 0L }
            }

    fun observeComplaintMessages(complaintId: String, complaintUserId: String, isAdmin: Boolean): Flow<List<ComplaintMessage>> = flow {
        val path = "complaint_messages"
        var query = db.collection(path).whereEqualTo("complaintId", complaintId)
        if (!isAdmin) {
            query = query.whereEqualTo("complaintUserId", complaintUserId)
        }
        query.snapshots()
            .map { snap ->
                snap.toObjects(ComplaintMessage::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedBy { it.createdAt?.seconds ?: Long.MAX_VALUE }
            }
            .catch { error ->
                val fsErr = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (fsErr == null && error is CancellationException) throw error
                handleFirestoreError(fsErr ?: error, OperationType.LIST, path)
                throw error
            }
            .collect { emit(it) }
    }

    suspend fun createComplaint(
        userName: String,
        userEmail: String,
        category: String,
        title: String,
        detail: String,
        attachmentUrl: String?
    ): Result<String> {
        val path = "complaints"
        return try {
            val uid = requireUserId()
            require(title.trim().isNotEmpty() && detail.trim().isNotEmpty()) {
                "Judul dan detail komplain wajib diisi."
            }
            val ref = db.collection(path).document()
            val batch = db.batch()
            val payload = mapOf(
                "userId" to uid,
                "userName" to userName.trim().ifBlank { "User" }.take(80),
                "userEmail" to userEmail.trim().take(160),
                "category" to category.trim().ifBlank { "Umum" }.take(60),
                "title" to title.trim().take(120),
                "detail" to detail.trim().take(2000),
                "attachmentUrl" to attachmentUrl?.takeIf { it.isNotBlank() }?.take(250_000),
                "status" to "PENDING",
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            ).filterValues { it != null } as Map<String, Any>
            batch.set(ref, payload)

            val msgRef = db.collection("complaint_messages").document()
            val msgPayload = mapOf(
                "complaintId" to ref.id,
                "complaintUserId" to uid,
                "senderUid" to uid,
                "senderName" to userName.trim().ifBlank { "User" }.take(80),
                "senderRole" to "USER",
                "message" to detail.trim().take(2000),
                "attachmentUrl" to attachmentUrl?.takeIf { it.isNotBlank() }?.take(250_000),
                "createdAt" to FieldValue.serverTimestamp()
            ).filterValues { it != null } as Map<String, Any>
            batch.set(msgRef, msgPayload)

            batch.commit().await()
            Result.success(ref.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun sendComplaintMessage(
        complaint: Complaint,
        senderName: String,
        senderRole: String,
        message: String,
        newStatus: String? = null,
        rejectionReason: String? = null
    ): Result<Unit> {
        val path = "complaint_messages"
        return try {
            val uid = requireUserId()
            require(message.trim().isNotEmpty()) { "Pesan tidak boleh kosong." }
            val batch = db.batch()
            val msgRef = db.collection(path).document()
            batch.set(
                msgRef,
                mapOf(
                    "complaintId" to complaint.id,
                    "complaintUserId" to complaint.userId,
                    "senderUid" to uid,
                    "senderName" to senderName.trim().take(80),
                    "senderRole" to senderRole,
                    "message" to message.trim().take(2000),
                    "createdAt" to FieldValue.serverTimestamp()
                )
            )
            val compUpdates = mutableMapOf<String, Any>(
                "lastReply" to message.trim().take(500),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            if (senderRole == "ADMIN" && !newStatus.isNullOrBlank()) {
                compUpdates["status"] = newStatus
                if (!rejectionReason.isNullOrBlank()) {
                    compUpdates["rejectionReason"] = rejectionReason.trim().take(300)
                }
            }
            batch.update(db.collection("complaints").document(complaint.id), compUpdates)

            if (senderRole == "ADMIN") {
                batch.set(
                    db.collection("notifications").document(),
                    mapOf(
                        "userId" to complaint.userId,
                        "title" to "Komplain Dibalas Admin",
                        "body" to "${complaint.title}: ${message.trim().take(120)}",
                        "type" to "COMPLAINT_REPLIED",
                        "read" to false,
                        "referenceId" to complaint.id,
                        "createdAt" to FieldValue.serverTimestamp()
                    )
                )
            }
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    // --- NOTIFICATIONS ---

    fun observeNotifications(userId: String): Flow<List<AppNotification>> = flow {
        val path = "notifications"
        db.collection(path)
            .whereEqualTo("userId", userId)
            .snapshots()
            .map { snap ->
                snap.toObjects(AppNotification::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt?.seconds ?: 0L }
            }
            .catch { error ->
                val fsErr = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (fsErr == null && error is CancellationException) throw error
                if (auth.currentUser?.uid == userId) {
                    handleFirestoreError(fsErr ?: error, OperationType.LIST, path)
                }
                throw error
            }
            .collect { emit(it) }
    }

    suspend fun markNotificationRead(notificationId: String): Result<Unit> {
        val path = "notifications/$notificationId"
        return try {
            requireUserId()
            db.document(path).update("read", true).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun markAllNotificationsRead(notifications: List<AppNotification>): Result<Unit> {
        return try {
            requireUserId()
            val unread = notifications.filter { !it.read && it.id.isNotBlank() }
            if (unread.isEmpty()) return Result.success(Unit)
            val batch = db.batch()
            unread.take(100).forEach { notif ->
                batch.update(db.collection("notifications").document(notif.id), "read", true)
            }
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, "notifications")
            Result.failure(e)
        }
    }

    // --- TOOLS HISTORY & NEXA HTTP ---

    fun observeToolsHistory(userId: String): Flow<List<ToolHistory>> = flow {
        val path = "tools_history"
        db.collection(path)
            .whereEqualTo("userId", userId)
            .snapshots()
            .map { snap ->
                snap.toObjects(ToolHistory::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt?.seconds ?: 0L }
            }
            .catch { error ->
                val fsErr = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (fsErr == null && error is CancellationException) throw error
                if (auth.currentUser?.uid == userId) {
                    handleFirestoreError(fsErr ?: error, OperationType.LIST, path)
                }
                throw error
            }
            .collect { emit(it) }
    }

    suspend fun recordToolHistory(
        toolName: String,
        inputSummary: String,
        outputSummary: String,
        status: String = "SUCCESS"
    ): Result<Unit> {
        val path = "tools_history"
        return try {
            val uid = requireUserId()
            db.collection(path).document().set(
                mapOf(
                    "userId" to uid,
                    "toolName" to toolName.take(80),
                    "inputSummary" to inputSummary.take(500),
                    "outputSummary" to outputSummary.take(2000),
                    "status" to status.take(40),
                    "createdAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun callConfiguredNexaTool(
        endpoint: String,
        queryParams: Map<String, String>
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val encodedParams = queryParams.entries.joinToString("&") { (k, v) ->
                "${URLEncoder.encode(k, "UTF-8")}=${URLEncoder.encode(v, "UTF-8")}"
            }
            val separator = if (endpoint.contains("?")) "&" else "?"
            val fullUrl = "$endpoint$separator$encodedParams"
            val request = Request.Builder().url(fullUrl).get().build()
            okHttp.newCall(request).execute().use { resp ->
                val body = resp.body?.string().orEmpty()
                if (resp.isSuccessful) {
                    Result.success(body.ifBlank { "HTTP ${resp.code} OK" })
                } else {
                    Result.failure(IllegalStateException("HTTP ${resp.code}: ${body.take(300)}"))
                }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // --- AI CONVERSATIONS ---

    fun observeAiConversations(userId: String): Flow<List<AiConversation>> = flow {
        val path = "ai_conversations"
        db.collection(path)
            .whereEqualTo("userId", userId)
            .snapshots()
            .map { snap ->
                snap.toObjects(AiConversation::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.updatedAt?.seconds ?: 0L }
            }
            .catch { error ->
                val fsErr = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (fsErr == null && error is CancellationException) throw error
                if (auth.currentUser?.uid == userId) {
                    handleFirestoreError(fsErr ?: error, OperationType.LIST, path)
                }
                throw error
            }
            .collect { emit(it) }
    }

    fun observeAiMessages(userId: String, conversationId: String): Flow<List<AiMessage>> = flow {
        val path = "ai_messages"
        db.collection(path)
            .whereEqualTo("userId", userId)
            .whereEqualTo("conversationId", conversationId)
            .snapshots()
            .map { snap ->
                snap.toObjects(AiMessage::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedBy { it.createdAt?.seconds ?: Long.MAX_VALUE }
            }
            .catch { error ->
                val fsErr = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (fsErr == null && error is CancellationException) throw error
                if (auth.currentUser?.uid == userId) {
                    handleFirestoreError(fsErr ?: error, OperationType.LIST, path)
                }
                throw error
            }
            .collect { emit(it) }
    }

    suspend fun createOrUpdateAiExchange(
        conversationId: String?,
        userText: String,
        modelText: String
    ): Result<String> {
        return try {
            val uid = requireUserId()
            val convRef = if (conversationId.isNullOrBlank()) {
                db.collection("ai_conversations").document()
            } else {
                db.collection("ai_conversations").document(conversationId)
            }
            val batch = db.batch()
            if (conversationId.isNullOrBlank()) {
                batch.set(
                    convRef,
                    mapOf(
                        "userId" to uid,
                        "title" to userText.trim().take(60).ifBlank { "Sesi AI CS" },
                        "lastMessage" to modelText.trim().take(500),
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            } else {
                batch.update(
                    convRef,
                    mapOf(
                        "lastMessage" to modelText.trim().take(500),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            }
            batch.set(
                db.collection("ai_messages").document(),
                mapOf(
                    "userId" to uid,
                    "conversationId" to convRef.id,
                    "role" to "user",
                    "text" to userText.trim().take(12_000),
                    "createdAt" to FieldValue.serverTimestamp()
                )
            )
            batch.set(
                db.collection("ai_messages").document(),
                mapOf(
                    "userId" to uid,
                    "conversationId" to convRef.id,
                    "role" to "model",
                    "text" to modelText.trim().take(12_000),
                    "createdAt" to FieldValue.serverTimestamp()
                )
            )
            batch.commit().await()
            Result.success(convRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, "ai_conversations")
            Result.failure(e)
        }
    }

    suspend fun askBusinessAi(question: String): Result<String> = withContext(Dispatchers.IO) {
        val cleanQuestion = question.trim()
        if (cleanQuestion.isEmpty()) {
            return@withContext Result.failure(
                IllegalArgumentException("Pertanyaan tidak boleh kosong.")
            )
        }
        try {
            requireUserId()
            val payload = hashMapOf("question" to cleanQuestion)
            val result = functions
                .getHttpsCallable("askBusinessAI")
                .withTimeout(30L, TimeUnit.SECONDS)
                .call(payload)
                .await()

            val responseMap = result.getData() as? Map<*, *>
            val statusOk = responseMap?.get("status") == true
            val answer = (responseMap?.get("message") as? String)?.trim().orEmpty()

            if (!statusOk || answer.isEmpty()) {
                return@withContext Result.failure(
                    IllegalStateException("Respons dari server AI tidak valid atau kosong. Silakan coba lagi.")
                )
            }
            Result.success(answer)
        } catch (e: CancellationException) {
            throw e
        } catch (e: FirebaseFunctionsException) {
            val friendlyMessage = when (e.code) {
                FirebaseFunctionsException.Code.UNAUTHENTICATED ->
                    "Sesi login tidak valid. Silakan masuk ulang dengan akun Google Anda."
                FirebaseFunctionsException.Code.PERMISSION_DENIED ->
                    e.message?.takeIf { it.isNotBlank() }
                        ?: "Layanan AI Customer Service khusus untuk pengguna Premium Lifetime."
                FirebaseFunctionsException.Code.INVALID_ARGUMENT ->
                    e.message?.takeIf { it.isNotBlank() }
                        ?: "Pertanyaan tidak valid. Periksa kembali pertanyaan Anda."
                FirebaseFunctionsException.Code.DEADLINE_EXCEEDED ->
                    "Waktu tunggu AI habis. Periksa koneksi internet dan coba lagi."
                FirebaseFunctionsException.Code.NOT_FOUND ->
                    "Fungsi backend AI (askBusinessAI) belum terpasang di Firebase Cloud Functions."
                FirebaseFunctionsException.Code.FAILED_PRECONDITION ->
                    e.message?.takeIf { it.isNotBlank() }
                        ?: "Layanan AI Customer Service sedang dinonaktifkan sementara."
                FirebaseFunctionsException.Code.UNAVAILABLE ->
                    e.message?.takeIf { it.isNotBlank() }
                        ?: "Server AI sedang sibuk atau jaringan bermasalah. Silakan coba beberapa saat lagi."
                else ->
                    e.message?.takeIf { it.isNotBlank() }
                        ?: "Gagal terhubung ke AI Customer Service. Gunakan tombol WhatsApp Admin di bawah."
            }
            Result.failure(IllegalStateException(friendlyMessage, e))
        } catch (e: Exception) {
            Result.failure(
                IllegalStateException(
                    "Tidak dapat terhubung ke layanan AI Customer Service. Periksa koneksi internet Anda.",
                    e
                )
            )
        }
    }
}
