package com.example.data

import android.content.Context
import com.example.core.OperationType
import com.example.core.getNexoraFirestore
import com.example.core.handleFirestoreError
import com.example.model.CartItem
import com.example.model.PosTransaction
import com.example.model.TransactionItem
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import java.util.UUID

class PosRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    constructor(context: Context) : this(getNexoraFirestore(context))

    private fun requireUserId(): String =
        auth.currentUser?.uid ?: throw IllegalStateException("Pengguna harus login.")

    fun observeTransactions(userId: String): Flow<List<PosTransaction>> = flow {
        val path = "transactions"
        db.collection(path)
            .whereEqualTo("userId", userId)
            .snapshots()
            .map { snap ->
                snap.toObjects(PosTransaction::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt?.seconds ?: 0L }
            }
            .catch { error ->
                val fsErr = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (fsErr == null && error is CancellationException) throw error
                if (auth.currentUser?.uid == userId) {
                    handleFirestoreError(fsErr ?: error, OperationType.LIST, path)
                }
                throw error
            }
            .collect { emit(it) }
    }

    fun observeAllTransactionsAdmin(): Flow<List<PosTransaction>> =
        db.collection("transactions")
            .limit(300)
            .snapshots()
            .map { snap ->
                snap.toObjects(PosTransaction::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt?.seconds ?: 0L }
            }

    suspend fun getTransactionItems(userId: String, transactionId: String): Result<List<TransactionItem>> {
        val path = "transaction_items"
        return try {
            val items = db.collection(path)
                .whereEqualTo("userId", userId)
                .whereEqualTo("transactionId", transactionId)
                .get()
                .await()
                .toObjects(TransactionItem::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            Result.success(items)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.LIST, path)
            Result.failure(e)
        }
    }

    suspend fun checkoutTransaction(
        cashierName: String,
        cartItems: List<CartItem>,
        discount: Double,
        taxPercent: Double,
        paymentMethod: String,
        paidAmount: Double,
        note: String = ""
    ): Result<String> {
        val path = "transactions"
        return try {
            val uid = requireUserId()
            require(cartItems.isNotEmpty()) { "Keranjang masih kosong." }
            val cleanMethod = paymentMethod.uppercase()
            require(cleanMethod in listOf("CASH", "TRANSFER", "QRIS", "OTHER")) {
                "Metode pembayaran tidak valid."
            }

            val txRef = db.collection("transactions").document()
            val txId = txRef.id

            db.runTransaction { tx ->
                // 1. Read & validate all products atomically from Firestore
                val snapshots = cartItems.map { item ->
                    val prodRef = db.collection("products").document(item.product.id)
                    val snap = tx.get(prodRef)
                    if (!snap.exists()) {
                        throw IllegalStateException("Produk '${item.product.name}' tidak ditemukan.")
                    }
                    val owner = snap.getString("userId")
                    if (owner != uid) {
                        throw IllegalStateException("Produk bukan milik akun Anda.")
                    }
                    val currentStock = snap.getLong("stock") ?: 0L
                    if (currentStock < item.quantity) {
                        throw IllegalStateException("Stok '${item.product.name}' tidak mencukupi (tersedia $currentStock).")
                    }
                    val serverSellPrice = snap.getDouble("sellPrice") ?: item.product.sellPrice
                    val serverCostPrice = snap.getDouble("costPrice") ?: item.product.costPrice
                    val lowThreshold = snap.getLong("lowStockThreshold") ?: 5L
                    Triple(prodRef, snap, Triple(serverSellPrice, serverCostPrice, currentStock - item.quantity to lowThreshold))
                }

                var subtotal = 0.0
                var costTotal = 0.0
                var itemsCount = 0L
                val summaryParts = mutableListOf<String>()

                snapshots.forEachIndexed { idx, triple ->
                    val cartItem = cartItems[idx]
                    val (sellPrice, costPrice, _) = triple.third
                    subtotal += sellPrice * cartItem.quantity
                    costTotal += costPrice * cartItem.quantity
                    itemsCount += cartItem.quantity
                    summaryParts += "${cartItem.quantity}x ${cartItem.product.name}"
                }

                val safeDiscount = discount.coerceIn(0.0, subtotal)
                val taxable = (subtotal - safeDiscount).coerceAtLeast(0.0)
                val taxAmount = (taxable * (taxPercent.coerceIn(0.0, 100.0) / 100.0))
                val total = (taxable + taxAmount).coerceAtLeast(0.0)
                val totalProfit = (total - taxAmount - costTotal)

                val effectivePaid = if (cleanMethod == "CASH") paidAmount else total
                if (cleanMethod == "CASH" && effectivePaid < total) {
                    throw IllegalStateException("Uang tunai diterima kurang dari total pembayaran.")
                }
                val changeAmount = (effectivePaid - total).coerceAtLeast(0.0)
                val initialStatus = if (cleanMethod == "QRIS") "PENDING" else "PAID"

                // 2. Write transaction document
                val txPayload = mapOf(
                    "userId" to uid,
                    "cashierName" to cashierName.trim().ifBlank { "Kasir" }.take(80),
                    "subtotal" to subtotal,
                    "discount" to safeDiscount,
                    "tax" to taxAmount,
                    "total" to total,
                    "totalProfit" to totalProfit,
                    "paidAmount" to effectivePaid,
                    "changeAmount" to changeAmount,
                    "paymentMethod" to cleanMethod,
                    "paymentStatus" to initialStatus,
                    "itemsCount" to itemsCount,
                    "itemsSummary" to summaryParts.joinToString(", ").take(500),
                    "note" to note.trim().take(300).ifBlank { null },
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                ).filterValues { it != null } as Map<String, Any>
                tx.set(txRef, txPayload)

                // 3. Decrement stocks, create transaction_items & stock_movements & low-stock alerts
                snapshots.forEachIndexed { idx, triple ->
                    val cartItem = cartItems[idx]
                    val prodRef = triple.first
                    val (sellPrice, costPrice, stockPair) = triple.third
                    val (newStock, lowThreshold) = stockPair

                    tx.update(
                        prodRef,
                        mapOf("stock" to newStock, "updatedAt" to FieldValue.serverTimestamp())
                    )

                    val itemRef = db.collection("transaction_items").document()
                    tx.set(
                        itemRef,
                        mapOf(
                            "userId" to uid,
                            "transactionId" to txId,
                            "productId" to cartItem.product.id,
                            "productName" to cartItem.product.name.take(120),
                            "quantity" to cartItem.quantity,
                            "costPrice" to costPrice,
                            "unitPrice" to sellPrice,
                            "lineTotal" to (sellPrice * cartItem.quantity),
                            "createdAt" to FieldValue.serverTimestamp()
                        )
                    )

                    val movRef = db.collection("stock_movements").document()
                    tx.set(
                        movRef,
                        mapOf(
                            "userId" to uid,
                            "productId" to cartItem.product.id,
                            "productName" to cartItem.product.name.take(120),
                            "delta" to -cartItem.quantity,
                            "stockAfter" to newStock,
                            "reason" to "Penjualan POS",
                            "referenceId" to txId,
                            "createdAt" to FieldValue.serverTimestamp()
                        )
                    )

                    if (newStock <= lowThreshold) {
                        val notifRef = db.collection("notifications").document()
                        tx.set(
                            notifRef,
                            mapOf(
                                "userId" to uid,
                                "title" to if (newStock == 0L) "Stok Habis: ${cartItem.product.name}" else "Stok Menipis: ${cartItem.product.name}",
                                "body" to "Sisa stok saat ini $newStock ${cartItem.product.unit}. Segera lakukan restock.",
                                "type" to "LOW_STOCK",
                                "read" to false,
                                "referenceId" to cartItem.product.id,
                                "createdAt" to FieldValue.serverTimestamp()
                            )
                        )
                    }
                }

                // 4. Write payment record
                val payRef = db.collection("payments").document()
                tx.set(
                    payRef,
                    mapOf(
                        "userId" to uid,
                        "transactionId" to txId,
                        "method" to cleanMethod,
                        "amount" to total,
                        "status" to initialStatus,
                        "idempotencyKey" to UUID.randomUUID().toString(),
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )

                // 5. Write transaction success notification
                val txNotifRef = db.collection("notifications").document()
                tx.set(
                    txNotifRef,
                    mapOf(
                        "userId" to uid,
                        "title" to "Transaksi Berhasil",
                        "body" to "Transaksi #${txId.take(8)} berhasil dicatat (${summaryParts.joinToString(", ").take(120)}).",
                        "type" to "TRANSACTION_SUCCESS",
                        "read" to false,
                        "referenceId" to txId,
                        "createdAt" to FieldValue.serverTimestamp()
                    )
                )
            }.await()

            Result.success(txId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }
}
