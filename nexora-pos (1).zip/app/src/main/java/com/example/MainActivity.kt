package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.windowsizeclass.ExperimentalMaterial3WindowSizeClassApi
import androidx.compose.material3.windowsizeclass.calculateWindowSizeClass
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.credentials.CredentialManager
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.attemptAutoSignIn
import com.example.core.authStateFlow
import com.example.core.configureAppCheck
import com.example.core.signOutUser
import com.example.data.AuthUserRepository
import com.example.model.AppSettings
import com.example.ui.navigation.NexoraAuthenticatedApp
import com.example.ui.screens.LandingAuthScreen
import com.example.ui.theme.NexoraPosTheme
import com.google.firebase.Firebase
import com.google.firebase.auth.auth

class MainActivity : ComponentActivity() {

    @OptIn(ExperimentalMaterial3WindowSizeClassApi::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        configureAppCheck(this, intent)

        setContent {
            val windowSizeClass = calculateWindowSizeClass(this)
            val scope = rememberCoroutineScope()
            val credentialManager = remember(this) { CredentialManager.create(this) }
            val authRepo = remember(this) { AuthUserRepository(applicationContext) }

            val currentUser by Firebase.auth.authStateFlow()
                .collectAsStateWithLifecycle(initialValue = Firebase.auth.currentUser)

            val publicAppSettings by authRepo.observePublicAppSettings()
                .collectAsStateWithLifecycle(initialValue = AppSettings())

            val systemDark = isSystemInDarkTheme()
            var userDarkOverride by remember { mutableStateOf<Boolean?>(null) }

            LaunchedEffect(currentUser?.uid) {
                if (currentUser == null) {
                    userDarkOverride = null
                }
            }

            LaunchedEffect(Unit) {
                if (Firebase.auth.currentUser == null) {
                    attemptAutoSignIn(
                        context = this@MainActivity,
                        credentialManager = credentialManager,
                        onAuthSuccess = {},
                        onUnauthenticated = {},
                        scope = scope
                    )
                }
            }

            NexoraPosTheme(darkTheme = userDarkOverride ?: systemDark) {
                val signedInUser = currentUser
                if (signedInUser == null) {
                    LandingAuthScreen(
                        appSettings = publicAppSettings,
                        onAuthSuccess = {},
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    androidx.compose.runtime.key(signedInUser.uid) {
                        NexoraAuthenticatedApp(
                            firebaseUser = signedInUser,
                            widthSizeClass = windowSizeClass.widthSizeClass,
                            onDarkThemeResolved = { userDarkOverride = it },
                            onSignOut = {
                                signOutUser(
                                    credentialManager = credentialManager,
                                    scope = scope
                                )
                            },
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }
            }
        }
    }
}
