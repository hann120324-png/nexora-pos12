package com.example.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.unwrapFirestoreMessage
import com.example.data.PosRepository
import com.example.model.CartItem
import com.example.model.PosTransaction
import com.example.model.Product
import com.example.model.TransactionItem
import com.example.model.UiState
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class PosViewModel(
    private val repo: PosRepository,
    private val currentUserId: String
) : ViewModel() {

    val transactionsState: StateFlow<UiState<List<PosTransaction>>> = repo.observeTransactions(currentUserId)
        .map<List<PosTransaction>, UiState<List<PosTransaction>>> { UiState.Success(it) }
        .catch { error ->
            val fsErr = generateSequence(error) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull()
            if (fsErr == null && error is CancellationException) throw error
            Log.w(TAG, "Error observing transactions", fsErr ?: error)
            emit(UiState.Error((fsErr ?: error).unwrapFirestoreMessage("Gagal memuat transaksi.")))
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    private val _cart = MutableStateFlow<List<CartItem>>(emptyList())
    val cart: StateFlow<List<CartItem>> = _cart.asStateFlow()

    private val _selectedItems = MutableStateFlow<List<TransactionItem>>(emptyList())
    val selectedItems: StateFlow<List<TransactionItem>> = _selectedItems.asStateFlow()

    private val _isCheckingOut = MutableStateFlow(false)
    val isCheckingOut: StateFlow<Boolean> = _isCheckingOut.asStateFlow()

    fun addToCart(product: Product): Boolean {
        if (product.stock <= 0L) return false
        val current = _cart.value.toMutableList()
        val idx = current.indexOfFirst { it.product.id == product.id }
        if (idx >= 0) {
            val existing = current[idx]
            if (existing.quantity + 1L > product.stock) return false
            current[idx] = existing.copy(quantity = existing.quantity + 1L)
        } else {
            current.add(CartItem(product = product, quantity = 1L))
        }
        _cart.value = current
        return true
    }

    fun updateQuantity(productId: String, newQty: Long) {
        val current = _cart.value.toMutableList()
        val idx = current.indexOfFirst { it.product.id == productId }
        if (idx < 0) return
        if (newQty <= 0L) {
            current.removeAt(idx)
        } else {
            val item = current[idx]
            val capped = newQty.coerceAtMost(item.product.stock.coerceAtLeast(1L))
            current[idx] = item.copy(quantity = capped)
        }
        _cart.value = current
    }

    fun removeFromCart(productId: String) {
        _cart.value = _cart.value.filterNot { it.product.id == productId }
    }

    fun clearCart() {
        _cart.value = emptyList()
    }

    fun checkout(
        cashierName: String,
        discount: Double,
        taxPercent: Double,
        paymentMethod: String,
        paidAmount: Double,
        note: String,
        onResult: (Result<String>) -> Unit
    ) {
        viewModelScope.launch {
            _isCheckingOut.value = true
            val res = repo.checkoutTransaction(
                cashierName = cashierName,
                cartItems = _cart.value,
                discount = discount,
                taxPercent = taxPercent,
                paymentMethod = paymentMethod,
                paidAmount = paidAmount,
                note = note
            )
            _isCheckingOut.value = false
            res.onSuccess { _cart.value = emptyList() }
            onResult(res)
        }
    }

    fun loadTransactionItems(transactionId: String) {
        viewModelScope.launch {
            _selectedItems.value = emptyList()
            repo.getTransactionItems(currentUserId, transactionId).onSuccess { items ->
                _selectedItems.value = items
            }
        }
    }

    fun buildTransactionsCsv(): String {
        val list = (transactionsState.value as? UiState.Success)?.data ?: emptyList()
        val sb = StringBuilder("transactionId,cashierName,subtotal,discount,tax,total,totalProfit,paymentMethod,paymentStatus,itemsSummary\n")
        list.forEach { t ->
            sb.append("\"${t.id}\",\"${t.cashierName}\",${t.subtotal},${t.discount},${t.tax},${t.total},${t.totalProfit},\"${t.paymentMethod}\",\"${t.paymentStatus}\",\"${t.itemsSummary.replace("\"", "\"\"")}\"\n")
        }
        return sb.toString()
    }

    private companion object {
        const val TAG = "PosVM"
    }
}
