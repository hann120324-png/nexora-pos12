package com.example.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.unwrapFirestoreMessage
import com.example.data.InventoryRepository
import com.example.model.Category
import com.example.model.Product
import com.example.model.StockMovement
import com.example.model.UiState
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class StockFilter(val label: String) {
    ALL("Semua"),
    READY("Tersedia"),
    LOW("Menipis"),
    OUT("Habis")
}

enum class ProductSort(val label: String) {
    NEWEST("Terbaru"),
    NAME_ASC("Nama A-Z"),
    PRICE_HIGH("Harga Tertinggi"),
    STOCK_LOW("Stok Terendah")
}

class InventoryViewModel(
    private val repo: InventoryRepository,
    private val currentUserId: String
) : ViewModel() {

    val productsState: StateFlow<UiState<List<Product>>> = repo.observeProducts(currentUserId)
        .map<List<Product>, UiState<List<Product>>> { UiState.Success(it) }
        .catch { error ->
            val fsErr = generateSequence(error) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull()
            if (fsErr == null && error is CancellationException) throw error
            Log.w(TAG, "Error observing products", fsErr ?: error)
            emit(UiState.Error((fsErr ?: error).unwrapFirestoreMessage("Gagal memuat produk.")))
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    val categories: StateFlow<List<Category>> = repo.observeCategories(currentUserId)
        .catch { error ->
            val fsErr = generateSequence(error) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull()
            if (fsErr == null && error is CancellationException) throw error
            emit(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val movements: StateFlow<List<StockMovement>> = repo.observeStockMovements(currentUserId)
        .catch { error ->
            val fsErr = generateSequence(error) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull()
            if (fsErr == null && error is CancellationException) throw error
            emit(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedCategory = MutableStateFlow("Semua")
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    private val _stockFilter = MutableStateFlow(StockFilter.ALL)
    val stockFilter: StateFlow<StockFilter> = _stockFilter.asStateFlow()

    private val _sortOrder = MutableStateFlow(ProductSort.NEWEST)
    val sortOrder: StateFlow<ProductSort> = _sortOrder.asStateFlow()

    private val _isBusy = MutableStateFlow(false)
    val isBusy: StateFlow<Boolean> = _isBusy.asStateFlow()

    val filteredProducts: StateFlow<List<Product>> = combine(
        productsState,
        _searchQuery,
        _selectedCategory,
        _stockFilter,
        _sortOrder
    ) { state, query, cat, filter, sort ->
        val list = (state as? UiState.Success)?.data ?: emptyList()
        val q = query.trim().lowercase()
        val filtered = list.filter { p ->
            val matchQuery = q.isEmpty() ||
                p.name.lowercase().contains(q) ||
                p.sku.lowercase().contains(q) ||
                p.barcode.lowercase().contains(q) ||
                p.category.lowercase().contains(q)
            val matchCat = cat == "Semua" || p.category.equals(cat, ignoreCase = true)
            val matchStock = when (filter) {
                StockFilter.ALL -> true
                StockFilter.READY -> p.stock > p.lowStockThreshold
                StockFilter.LOW -> p.lowStock
                StockFilter.OUT -> p.outOfStock
            }
            matchQuery && matchCat && matchStock
        }
        when (sort) {
            ProductSort.NEWEST -> filtered.sortedByDescending { it.updatedAt?.seconds ?: 0L }
            ProductSort.NAME_ASC -> filtered.sortedBy { it.name.lowercase() }
            ProductSort.PRICE_HIGH -> filtered.sortedByDescending { it.sellPrice }
            ProductSort.STOCK_LOW -> filtered.sortedBy { it.stock }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    fun setSearchQuery(q: String) { _searchQuery.value = q }
    fun setSelectedCategory(cat: String) { _selectedCategory.value = cat }
    fun setStockFilter(f: StockFilter) { _stockFilter.value = f }
    fun setSortOrder(s: ProductSort) { _sortOrder.value = s }

    fun saveProduct(product: Product, onResult: (Result<String>) -> Unit) {
        viewModelScope.launch {
            _isBusy.value = true
            val res = repo.saveProduct(product)
            _isBusy.value = false
            onResult(res)
        }
    }

    fun adjustStock(product: Product, delta: Long, reason: String, onResult: (Result<Unit>) -> Unit) {
        viewModelScope.launch {
            _isBusy.value = true
            val res = repo.adjustStock(product, delta, reason)
            _isBusy.value = false
            onResult(res)
        }
    }

    fun deleteProduct(productId: String, onResult: (Result<Unit>) -> Unit) {
        viewModelScope.launch {
            _isBusy.value = true
            val res = repo.deleteProduct(productId)
            _isBusy.value = false
            onResult(res)
        }
    }

    fun addCategory(name: String, onResult: (Result<Unit>) -> Unit) {
        viewModelScope.launch {
            val res = repo.addCategory(name)
            onResult(res)
        }
    }

    fun deleteCategory(categoryId: String, onResult: (Result<Unit>) -> Unit) {
        viewModelScope.launch {
            val res = repo.deleteCategory(categoryId)
            onResult(res)
        }
    }

    fun lookupProductByCode(code: String, onFound: (Product?) -> Unit) {
        viewModelScope.launch {
            val found = repo.findProductByCode(currentUserId, code)
            onFound(found)
        }
    }

    fun buildProductsCsv(): String {
        val list = (productsState.value as? UiState.Success)?.data ?: emptyList()
        val sb = StringBuilder("id,name,sku,barcode,category,costPrice,sellPrice,stock,unit\n")
        list.forEach { p ->
            sb.append("\"${p.id}\",\"${p.name.replace("\"", "\"\"")}\",\"${p.sku}\",\"${p.barcode}\",\"${p.category}\",${p.costPrice},${p.sellPrice},${p.stock},\"${p.unit}\"\n")
        }
        return sb.toString()
    }

    private companion object {
        const val TAG = "InventoryVM"
    }
}
