package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.SupportPremiumRepository
import com.example.model.ApiSettings
import com.example.model.Complaint
import com.example.model.ComplaintMessage
import com.example.model.PremiumRequest
import com.example.model.ToolHistory
import com.example.model.UiState
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SupportToolsViewModel(
    private val repo: SupportPremiumRepository,
    private val currentUserId: String
) : ViewModel() {

    val premiumRequests: StateFlow<List<PremiumRequest>> = repo.observeUserPremiumRequests(currentUserId)
        .catch { error ->
            val fsErr = generateSequence(error) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull()
            if (fsErr == null && error is CancellationException) throw error
            emit(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val complaints: StateFlow<List<Complaint>> = repo.observeUserComplaints(currentUserId)
        .catch { error ->
            val fsErr = generateSequence(error) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull()
            if (fsErr == null && error is CancellationException) throw error
            emit(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val toolsHistory: StateFlow<List<ToolHistory>> = repo.observeToolsHistory(currentUserId)
        .catch { error ->
            val fsErr = generateSequence(error) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull()
            if (fsErr == null && error is CancellationException) throw error
            emit(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    private val _complaintMessages = MutableStateFlow<List<ComplaintMessage>>(emptyList())
    val complaintMessages: StateFlow<List<ComplaintMessage>> = _complaintMessages.asStateFlow()
    private var messageObserverJob: Job? = null

    private val _toolState = MutableStateFlow<UiState<String>?>(null)
    val toolState: StateFlow<UiState<String>?> = _toolState.asStateFlow()

    private val _isSubmitting = MutableStateFlow(false)
    val isSubmitting: StateFlow<Boolean> = _isSubmitting.asStateFlow()

    fun observeComplaintThread(complaint: Complaint, isAdmin: Boolean) {
        messageObserverJob?.cancel()
        messageObserverJob = viewModelScope.launch {
            repo.observeComplaintMessages(complaint.id, complaint.userId, isAdmin)
                .catch { error ->
                    val fsErr = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (fsErr == null && error is CancellationException) throw error
                    emit(emptyList())
                }
                .collect { _complaintMessages.value = it }
        }
    }

    fun submitPremiumRequest(
        userName: String,
        userEmail: String,
        amount: Double,
        paymentMethod: String,
        proofUrl: String?,
        note: String?,
        onResult: (Result<String>) -> Unit
    ) {
        viewModelScope.launch {
            _isSubmitting.value = true
            val res = repo.submitPremiumRequest(userName, userEmail, amount, paymentMethod, proofUrl, note)
            _isSubmitting.value = false
            onResult(res)
        }
    }

    fun updatePendingProof(requestId: String, proofUrl: String, note: String?, onResult: (Result<Unit>) -> Unit) {
        viewModelScope.launch {
            _isSubmitting.value = true
            val res = repo.updatePendingPremiumProof(requestId, proofUrl, note)
            _isSubmitting.value = false
            onResult(res)
        }
    }

    fun createComplaint(
        userName: String,
        userEmail: String,
        category: String,
        title: String,
        detail: String,
        attachmentUrl: String?,
        onResult: (Result<String>) -> Unit
    ) {
        viewModelScope.launch {
            _isSubmitting.value = true
            val res = repo.createComplaint(userName, userEmail, category, title, detail, attachmentUrl)
            _isSubmitting.value = false
            onResult(res)
        }
    }

    fun sendComplaintReply(
        complaint: Complaint,
        senderName: String,
        senderRole: String,
        message: String,
        newStatus: String? = null,
        rejectionReason: String? = null,
        onResult: (Result<Unit>) -> Unit
    ) {
        viewModelScope.launch {
            _isSubmitting.value = true
            val res = repo.sendComplaintMessage(
                complaint, senderName, senderRole, message, newStatus, rejectionReason
            )
            _isSubmitting.value = false
            onResult(res)
        }
    }

    fun runGenerationAmTool(apiSettings: ApiSettings, email: String, proxyKeyInput: String) {
        if (!apiSettings.nexaSendConfigured || apiSettings.nexaSendEndpoint.isBlank()) {
            _toolState.value = UiState.Error(
                "Integrasi Generation AM Premium (Nexa API) berstatus Belum Dikonfigurasi oleh Admin. Hubungi Admin atau aktifkan endpoint proxy backend terlebih dahulu."
            )
            return
        }
        viewModelScope.launch {
            _toolState.value = UiState.Loading
            val params = buildMap {
                put("email", email.trim())
                if (proxyKeyInput.isNotBlank()) put("key", proxyKeyInput.trim())
            }
            val result = repo.callConfiguredNexaTool(apiSettings.nexaSendEndpoint, params)
            result.onSuccess { body ->
                repo.recordToolHistory("Generation AM Premium", "email=$email", body, "SUCCESS")
                _toolState.value = UiState.Success(body)
            }.onFailure { err ->
                val msg = err.localizedMessage ?: "Gagal memanggil endpoint Nexa."
                repo.recordToolHistory("Generation AM Premium", "email=$email", msg, "ERROR")
                _toolState.value = UiState.Error(msg)
            }
        }
    }

    fun runVoteChannelTool(apiSettings: ApiSettings, email: String, link: String, proxyKeyInput: String) {
        if (!apiSettings.voteConfigured || apiSettings.voteEndpoint.isBlank()) {
            _toolState.value = UiState.Error(
                "Integrasi Vote Channel (Nexa Verif API) berstatus Belum Dikonfigurasi oleh Admin."
            )
            return
        }
        viewModelScope.launch {
            _toolState.value = UiState.Loading
            val params = buildMap {
                put("email", email.trim())
                put("link", link.trim())
                if (proxyKeyInput.isNotBlank()) put("key", proxyKeyInput.trim())
            }
            val result = repo.callConfiguredNexaTool(apiSettings.voteEndpoint, params)
            result.onSuccess { body ->
                repo.recordToolHistory("Vote Channel", "email=$email, link=$link", body, "SUCCESS")
                _toolState.value = UiState.Success(body)
            }.onFailure { err ->
                val msg = err.localizedMessage ?: "Gagal memanggil endpoint Vote Channel."
                repo.recordToolHistory("Vote Channel", "email=$email, link=$link", msg, "ERROR")
                _toolState.value = UiState.Error(msg)
            }
        }
    }

    fun runFakeLobbySimulation(game: String, nickname: String, rankLabel: String, playersCount: Int) {
        viewModelScope.launch {
            _toolState.value = UiState.Loading
            val code = "SIM-${game.take(2).uppercase()}-${(100000..999999).random()}"
            val output = """
                [SIMULASI VISUAL — BUKAN DATA SERVER RESMI]
                Game      : $game
                Kode Room : $code
                Host      : ${nickname.trim().ifBlank { "NexoraPlayer" }}
                Tier/Rank : ${rankLabel.trim().ifBlank { "Mythic / Ace" }}
                Slot Tim  : $playersCount Pemain
                Catatan   : Output ini dibuat secara lokal sebagai generator simulasi UI.
            """.trimIndent()
            repo.recordToolHistory("Fake Lobby ($game)", "$nickname | $rankLabel", output, "SIMULATION")
            _toolState.value = UiState.Success(output)
        }
    }

    fun clearToolState() {
        _toolState.value = null
    }
}
