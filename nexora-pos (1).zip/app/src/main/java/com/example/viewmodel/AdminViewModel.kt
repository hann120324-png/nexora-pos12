package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.unwrapFirestoreMessage
import com.example.data.AuthUserRepository
import com.example.data.InventoryRepository
import com.example.data.PosRepository
import com.example.data.SupportPremiumRepository
import com.example.model.ApiSettings
import com.example.model.AppSettings
import com.example.model.AuditLog
import com.example.model.Complaint
import com.example.model.PosTransaction
import com.example.model.PremiumHistory
import com.example.model.PremiumRequest
import com.example.model.Product
import com.example.model.UserProfile
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class AdminViewModel(
    private val authRepo: AuthUserRepository,
    private val inventoryRepo: InventoryRepository,
    private val posRepo: PosRepository,
    private val supportRepo: SupportPremiumRepository,
) : ViewModel() {

    val allUsers: StateFlow<List<UserProfile>> = authRepo.observeAllUsers()
        .catch { e -> handleStreamError(e); emit(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val allRequests: StateFlow<List<PremiumRequest>> = supportRepo.observeAllPremiumRequestsAdmin()
        .catch { e -> handleStreamError(e); emit(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val premiumHistory: StateFlow<List<PremiumHistory>> = supportRepo.observePremiumHistoryAdmin()
        .catch { e -> handleStreamError(e); emit(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val allProducts: StateFlow<List<Product>> = inventoryRepo.observeAllProductsAdmin()
        .catch { e -> handleStreamError(e); emit(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val allTransactions: StateFlow<List<PosTransaction>> = posRepo.observeAllTransactionsAdmin()
        .catch { e -> handleStreamError(e); emit(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val allComplaints: StateFlow<List<Complaint>> = supportRepo.observeAllComplaintsAdmin()
        .catch { e -> handleStreamError(e); emit(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val auditLogs: StateFlow<List<AuditLog>> = authRepo.observeAuditLogs()
        .catch { e -> handleStreamError(e); emit(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    private val _isBusy = MutableStateFlow(false)
    val isBusy: StateFlow<Boolean> = _isBusy.asStateFlow()

    private fun handleStreamError(error: Throwable) {
        val fsErr = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (fsErr == null && error is CancellationException) throw error
    }

    fun approvePremium(req: PremiumRequest, onFeedback: (String) -> Unit) {
        viewModelScope.launch {
            _isBusy.value = true
            val res = supportRepo.adminApprovePremiumRequest(req)
            _isBusy.value = false
            res.onSuccess { onFeedback("Permintaan Premium disetujui (Lifetime aktif).") }
                .onFailure { onFeedback(it.unwrapFirestoreMessage("Gagal menyetujui Premium.")) }
        }
    }

    fun rejectPremium(req: PremiumRequest, reason: String, onFeedback: (String) -> Unit) {
        viewModelScope.launch {
            _isBusy.value = true
            val res = supportRepo.adminRejectPremiumRequest(req, reason)
            _isBusy.value = false
            res.onSuccess { onFeedback("Permintaan Premium ditolak.") }
                .onFailure { onFeedback(it.unwrapFirestoreMessage("Gagal menolak Premium.")) }
        }
    }

    fun updateUserStatus(
        targetUid: String,
        role: String,
        accountStatus: String,
        premiumStatus: String,
        premiumType: String,
        onFeedback: (String) -> Unit
    ) {
        viewModelScope.launch {
            _isBusy.value = true
            val res = authRepo.adminUpdateUserStatus(targetUid, role, accountStatus, premiumStatus, premiumType)
            _isBusy.value = false
            res.onSuccess { onFeedback("Status pengguna diperbarui.") }
                .onFailure { onFeedback(it.unwrapFirestoreMessage("Gagal memperbarui pengguna.")) }
        }
    }

    fun saveAppSettings(settings: AppSettings, onFeedback: (String) -> Unit) {
        viewModelScope.launch {
            _isBusy.value = true
            val res = authRepo.adminSaveAppSettings(settings)
            _isBusy.value = false
            res.onSuccess { onFeedback("Pengaturan aplikasi disimpan.") }
                .onFailure { onFeedback(it.unwrapFirestoreMessage("Gagal menyimpan pengaturan.")) }
        }
    }

    fun saveApiSettings(settings: ApiSettings, onFeedback: (String) -> Unit) {
        viewModelScope.launch {
            _isBusy.value = true
            val res = authRepo.adminSaveApiSettings(settings)
            _isBusy.value = false
            res.onSuccess { onFeedback("Konfigurasi API disimpan.") }
                .onFailure { onFeedback(it.unwrapFirestoreMessage("Gagal menyimpan konfigurasi API.")) }
        }
    }

    fun broadcastAnnouncement(title: String, body: String, onFeedback: (String) -> Unit) {
        viewModelScope.launch {
            _isBusy.value = true
            val uids = allUsers.value.map { it.userId }.distinct()
            val res = authRepo.adminBroadcastAnnouncement(title, body, uids)
            _isBusy.value = false
            res.onSuccess { onFeedback("Pengumuman dikirim ke ${uids.size} pengguna.") }
                .onFailure { onFeedback(it.unwrapFirestoreMessage("Gagal mengirim pengumuman.")) }
        }
    }
}
