package com.example.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.SupportPremiumRepository
import com.example.model.AiConversation
import com.example.model.AiMessage
import com.example.model.ApiSettings
import com.example.model.UiState
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeout

class AiCsViewModel(
    private val repo: SupportPremiumRepository,
    private val currentUserId: String
) : ViewModel() {

    val conversations: StateFlow<List<AiConversation>> = repo.observeAiConversations(currentUserId)
        .catch { error ->
            val fsErr = generateSequence(error) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull()
            if (fsErr == null && error is CancellationException) throw error
            emit(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    private val _activeConversationId = MutableStateFlow<String?>(null)
    val activeConversationId: StateFlow<String?> = _activeConversationId.asStateFlow()

    private val _messages = MutableStateFlow<List<AiMessage>>(emptyList())
    val messages: StateFlow<List<AiMessage>> = _messages.asStateFlow()

    private val _aiState = MutableStateFlow<UiState<String>?>(null)
    val aiState: StateFlow<UiState<String>?> = _aiState.asStateFlow()

    private val _streamingText = MutableStateFlow("")
    val streamingText: StateFlow<String> = _streamingText.asStateFlow()

    private var messagesJob: Job? = null

    fun selectConversation(conversationId: String?) {
        _activeConversationId.value = conversationId
        messagesJob?.cancel()
        if (conversationId.isNullOrBlank()) {
            _messages.value = emptyList()
            return
        }
        messagesJob = viewModelScope.launch {
            repo.observeAiMessages(currentUserId, conversationId)
                .catch { error ->
                    val fsErr = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (fsErr == null && error is CancellationException) throw error
                    emit(emptyList())
                }
                .collect { _messages.value = it }
        }
    }

    fun sendQuestion(prompt: String, apiSettings: ApiSettings) {
        val cleanPrompt = prompt.trim()
        if (cleanPrompt.isEmpty()) return

        if (!apiSettings.aiCsConfigured) {
            _aiState.value = UiState.Error(
                "Layanan AI Customer Service sedang dinonaktifkan oleh Admin. Silakan hubungi Admin via WhatsApp."
            )
            return
        }

        viewModelScope.launch {
            _aiState.value = UiState.Loading
            _streamingText.value = ""
            try {
                val aiResult = withTimeout(35_000L) {
                    repo.askBusinessAi(cleanPrompt)
                }

                aiResult.onSuccess { reply ->
                    val convIdResult = repo.createOrUpdateAiExchange(
                        conversationId = _activeConversationId.value,
                        userText = cleanPrompt,
                        modelText = reply
                    )
                    convIdResult.onSuccess { newId ->
                        if (_activeConversationId.value == null) {
                            selectConversation(newId)
                        }
                    }
                    _aiState.value = UiState.Success(reply)
                }.onFailure { err ->
                    Log.e(TAG, "AI CS failed", err)
                    _aiState.value = UiState.Error(
                        err.message ?: "Gagal terhubung ke AI Customer Service. Gunakan tombol WhatsApp Admin di bawah."
                    )
                }
            } catch (e: TimeoutCancellationException) {
                Log.e(TAG, "AI CS timed out", e)
                _aiState.value = UiState.Error(
                    "Permintaan ke AI Customer Service melebihi batas waktu. Silakan coba lagi atau hubungi Admin."
                )
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "AI CS unexpected error", e)
                _aiState.value = UiState.Error(
                    "Gagal terhubung ke AI Customer Service. Gunakan tombol WhatsApp Admin di bawah."
                )
            }
        }
    }

    fun clearError() {
        _aiState.value = null
    }

    private companion object {
        const val TAG = "AiCsVM"
    }
}
