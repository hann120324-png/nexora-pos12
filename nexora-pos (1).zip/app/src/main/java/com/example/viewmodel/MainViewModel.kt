package com.example.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.unwrapFirestoreMessage
import com.example.data.AuthUserRepository
import com.example.data.SupportPremiumRepository
import com.example.model.ApiSettings
import com.example.model.AppNotification
import com.example.model.AppSettings
import com.example.model.UiState
import com.example.model.UserProfile
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(
    private val authRepo: AuthUserRepository,
    private val supportRepo: SupportPremiumRepository,
    private val currentUserId: String,
) : ViewModel() {

    val userProfileState: StateFlow<UiState<UserProfile?>> = authRepo.observeUserProfile(currentUserId)
        .map<UserProfile?, UiState<UserProfile?>> { UiState.Success(it) }
        .catch { error ->
            val fsErr = generateSequence(error) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull()
            if (fsErr == null && error is CancellationException) throw error
            Log.w(TAG, "Error observing user profile", fsErr ?: error)
            emit(UiState.Error((fsErr ?: error).unwrapFirestoreMessage("Gagal memuat profil pengguna.")))
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000L),
            initialValue = UiState.Loading
        )

    val appSettings: StateFlow<AppSettings> = authRepo.observePublicAppSettings()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), AppSettings())

    val apiSettings: StateFlow<ApiSettings> = authRepo.observeApiSettings()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), ApiSettings())

    val notifications: StateFlow<List<AppNotification>> = supportRepo.observeNotifications(currentUserId)
        .catch { error ->
            val fsErr = generateSequence(error) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull()
            if (fsErr == null && error is CancellationException) throw error
            emit(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

    private val _isSaving = MutableStateFlow(false)
    val isSaving: StateFlow<Boolean> = _isSaving.asStateFlow()

    fun ensureProfile(firebaseUser: FirebaseUser) {
        viewModelScope.launch {
            authRepo.ensureUserProfileExists(firebaseUser).onFailure { err ->
                _toastMessage.value = err.unwrapFirestoreMessage("Gagal menyiapkan profil akun.")
            }
        }
    }

    fun updateProfile(
        name: String,
        storeName: String,
        storeAddress: String,
        storePhone: String,
        photoUrl: String?,
        storeLogoUrl: String?,
    ) {
        viewModelScope.launch {
            _isSaving.value = true
            val result = authRepo.updateProfile(
                name = name,
                storeName = storeName,
                storeAddress = storeAddress,
                storePhone = storePhone,
                photoUrl = photoUrl,
                storeLogoUrl = storeLogoUrl
            )
            _isSaving.value = false
            result.onSuccess {
                _toastMessage.value = "Profil dan informasi toko berhasil disimpan."
            }.onFailure { err ->
                _toastMessage.value = err.unwrapFirestoreMessage("Gagal menyimpan profil.")
            }
        }
    }

    fun toggleDarkMode(enabled: Boolean) {
        viewModelScope.launch {
            authRepo.updateDarkMode(enabled).onFailure { err ->
                _toastMessage.value = err.unwrapFirestoreMessage("Gagal mengubah tema.")
            }
        }
    }

    fun markNotificationRead(notificationId: String) {
        viewModelScope.launch {
            supportRepo.markNotificationRead(notificationId)
        }
    }

    fun markAllNotificationsRead() {
        viewModelScope.launch {
            supportRepo.markAllNotificationsRead(notifications.value).onSuccess {
                _toastMessage.value = "Semua notifikasi ditandai dibaca."
            }
        }
    }

    fun showToast(msg: String) {
        _toastMessage.value = msg
    }

    fun clearToast() {
        _toastMessage.value = null
    }

    private companion object {
        const val TAG = "MainVM"
    }
}
