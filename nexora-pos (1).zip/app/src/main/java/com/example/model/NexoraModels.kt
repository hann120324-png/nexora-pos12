package com.example.model

import androidx.annotation.Keep
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}

@Keep
@IgnoreExtraProperties
data class UserProfile(
    @DocumentId val id: String = "",
    val userId: String = "",
    val name: String = "",
    val email: String = "",
    val photoUrl: String = "",
    val role: String = "USER",
    val accountStatus: String = "active",
    val premiumStatus: String = "free",
    val premiumType: String = "none",
    @ServerTimestamp val premiumActivatedAt: Timestamp? = null,
    @ServerTimestamp val premiumExpiresAt: Timestamp? = null,
    val premiumRequestId: String = "",
    val storeName: String = "",
    val storeAddress: String = "",
    val storePhone: String = "",
    val storeLogoUrl: String = "",
    val darkMode: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
) {
    val isAdminRole: Boolean get() = role == "ADMIN"
    val isPremiumActive: Boolean get() = premiumStatus == "active" || isAdminRole
    val isDisabledAccount: Boolean get() = accountStatus == "disabled"
}

@Keep
@IgnoreExtraProperties
data class Product(
    @DocumentId val id: String = "",
    val userId: String = "",
    val name: String = "",
    val sku: String = "",
    val barcode: String = "",
    val qrCode: String = "",
    val category: String = "Umum",
    val description: String = "",
    val costPrice: Double = 0.0,
    val sellPrice: Double = 0.0,
    val stock: Long = 0L,
    val lowStockThreshold: Long = 5L,
    val unit: String = "pcs",
    val photoUrl: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
) {
    val lowStock: Boolean get() = stock in 1..lowStockThreshold
    val outOfStock: Boolean get() = stock <= 0L

    fun toCreateMap(ownerUid: String): Map<String, Any> {
        return mapOf(
            "userId" to ownerUid,
            "name" to name.trim().take(120),
            "sku" to sku.trim().take(64),
            "barcode" to barcode.trim().take(128).ifBlank { null },
            "qrCode" to qrCode.trim().take(256).ifBlank { null },
            "category" to category.trim().ifBlank { "Umum" }.take(60),
            "description" to description.trim().take(500).ifBlank { null },
            "costPrice" to costPrice.coerceAtLeast(0.0),
            "sellPrice" to sellPrice.coerceAtLeast(0.0),
            "stock" to stock.coerceAtLeast(0L),
            "lowStockThreshold" to lowStockThreshold.coerceAtLeast(0L),
            "unit" to unit.trim().ifBlank { "pcs" }.take(30),
            "photoUrl" to photoUrl.ifBlank { null },
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        ).filterValues { it != null } as Map<String, Any>
    }
}

@Keep
@IgnoreExtraProperties
data class Category(
    @DocumentId val id: String = "",
    val userId: String = "",
    val name: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
)

@Keep
@IgnoreExtraProperties
data class StockMovement(
    @DocumentId val id: String = "",
    val userId: String = "",
    val productId: String = "",
    val productName: String = "",
    val delta: Long = 0L,
    val stockAfter: Long = 0L,
    val reason: String = "",
    val referenceId: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
)

@Keep
@IgnoreExtraProperties
data class PosTransaction(
    @DocumentId val id: String = "",
    val userId: String = "",
    val cashierName: String = "",
    val subtotal: Double = 0.0,
    val discount: Double = 0.0,
    val tax: Double = 0.0,
    val total: Double = 0.0,
    val totalProfit: Double = 0.0,
    val paidAmount: Double = 0.0,
    val changeAmount: Double = 0.0,
    val paymentMethod: String = "CASH",
    val paymentStatus: String = "PAID",
    val itemsCount: Long = 0L,
    val itemsSummary: String = "",
    val note: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
)

@Keep
@IgnoreExtraProperties
data class TransactionItem(
    @DocumentId val id: String = "",
    val userId: String = "",
    val transactionId: String = "",
    val productId: String = "",
    val productName: String = "",
    val quantity: Long = 1L,
    val costPrice: Double = 0.0,
    val unitPrice: Double = 0.0,
    val lineTotal: Double = 0.0,
    @ServerTimestamp val createdAt: Timestamp? = null,
)

@Keep
@IgnoreExtraProperties
data class PaymentRecord(
    @DocumentId val id: String = "",
    val userId: String = "",
    val transactionId: String = "",
    val method: String = "CASH",
    val amount: Double = 0.0,
    val status: String = "PAID",
    val idempotencyKey: String = "",
    val providerTxId: String = "",
    val qrisPayload: String = "",
    @ServerTimestamp val expiresAt: Timestamp? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
)

@Keep
@IgnoreExtraProperties
data class PremiumRequest(
    @DocumentId val id: String = "",
    val userId: String = "",
    val userName: String = "",
    val userEmail: String = "",
    val amount: Double = 30000.0,
    val paymentMethod: String = "Transfer Bank",
    val proofUrl: String = "",
    val note: String = "",
    val status: String = "PENDING",
    val rejectionReason: String = "",
    val reviewedBy: String = "",
    @ServerTimestamp val reviewedAt: Timestamp? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
)

@Keep
@IgnoreExtraProperties
data class PremiumHistory(
    @DocumentId val id: String = "",
    val userId: String = "",
    val requestId: String = "",
    val action: String = "APPROVED",
    val amount: Double = 0.0,
    val adminUid: String = "",
    val reason: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
)

@Keep
@IgnoreExtraProperties
data class Complaint(
    @DocumentId val id: String = "",
    val userId: String = "",
    val userName: String = "",
    val userEmail: String = "",
    val category: String = "Umum",
    val title: String = "",
    val detail: String = "",
    val attachmentUrl: String = "",
    val status: String = "PENDING",
    val rejectionReason: String = "",
    val lastReply: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
)

@Keep
@IgnoreExtraProperties
data class ComplaintMessage(
    @DocumentId val id: String = "",
    val complaintId: String = "",
    val complaintUserId: String = "",
    val senderUid: String = "",
    val senderName: String = "",
    val senderRole: String = "USER",
    val message: String = "",
    val attachmentUrl: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
)

@Keep
@IgnoreExtraProperties
data class AppNotification(
    @DocumentId val id: String = "",
    val userId: String = "",
    val title: String = "",
    val body: String = "",
    val type: String = "SYSTEM",
    val read: Boolean = false,
    val referenceId: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
)

@Keep
@IgnoreExtraProperties
data class ToolHistory(
    @DocumentId val id: String = "",
    val userId: String = "",
    val toolName: String = "",
    val inputSummary: String = "",
    val outputSummary: String = "",
    val status: String = "SUCCESS",
    @ServerTimestamp val createdAt: Timestamp? = null,
)

@Keep
@IgnoreExtraProperties
data class AiConversation(
    @DocumentId val id: String = "",
    val userId: String = "",
    val title: String = "",
    val lastMessage: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
)

@Keep
@IgnoreExtraProperties
data class AiMessage(
    @DocumentId val id: String = "",
    val userId: String = "",
    val conversationId: String = "",
    val role: String = "user",
    val text: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
)

@Keep
@IgnoreExtraProperties
data class AppSettings(
    @DocumentId val id: String = "config",
    val appName: String = "NEXORA POS",
    val tagline: String = "Manage Smart. Sell Faster.",
    val description: String = "Aplikasi kasir POS & manajemen bisnis modern dengan sinkronisasi cloud Firebase, scanner QR/Barcode, struk thermal, dan AI Customer Service.",
    val premiumPrice: Double = 30000.0,
    val paymentInstructions: String = "Transfer ke Bank BCA 1234567890 a.n. NEXORA POS atau hubungi Admin via WhatsApp 083854160449 untuk konfirmasi.",
    val whatsappNumber: String = "6283854160449",
    val supportContact: String = "cs@nexorapos.id",
    val announcement: String = "",
    val maintenanceMode: Boolean = false,
    @ServerTimestamp val updatedAt: Timestamp? = null,
)

@Keep
@IgnoreExtraProperties
data class ApiSettings(
    @DocumentId val id: String = "public_config",
    val nexaSendConfigured: Boolean = false,
    val nexaSendEndpoint: String = "https://api.nexadev.my.id/am/send/",
    val reactionConfigured: Boolean = false,
    val reactionEndpoint: String = "",
    val voteConfigured: Boolean = false,
    val voteEndpoint: String = "https://api.nexadev.my.id/am/verif/",
    val qrisConfigured: Boolean = false,
    val qrisProviderName: String = "",
    val aiCsConfigured: Boolean = true,
    val aiModelName: String = "gemini-3.8-flash",
    val aiSystemPrompt: String = "Anda adalah AI Customer Service resmi NEXORA POS yang ramah, ringkas, dan membantu pengguna dalam bahasa Indonesia terkait kasir, inventaris, struk, QR scanner, dan paket Premium Lifetime.",
    val aiMaxTokens: Long = 1024L,
    val aiTemperature: Double = 0.7,
    @ServerTimestamp val updatedAt: Timestamp? = null,
)

@Keep
@IgnoreExtraProperties
data class AuditLog(
    @DocumentId val id: String = "",
    val actorUid: String = "",
    val actorEmail: String = "",
    val action: String = "",
    val targetId: String = "",
    val detail: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
)

data class CartItem(
    val product: Product,
    val quantity: Long
) {
    val lineTotal: Double get() = product.sellPrice * quantity
    val lineProfit: Double get() = (product.sellPrice - product.costPrice) * quantity
}
