package com.example

import com.example.core.RupiahFormatter
import com.example.model.CartItem
import com.example.model.Product
import com.example.model.UserProfile
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun rupiahFormatter_formatsIndonesianCurrencyWithoutDecimals() {
        assertEquals("Rp30.000", RupiahFormatter.format(30000.0))
        assertEquals("Rp0", RupiahFormatter.format(0L))
    }

    @Test
    fun cartItem_calculatesLineTotalAndProfitCorrectly() {
        val product = Product(id = "p1", name = "Teh Botol", costPrice = 3000.0, sellPrice = 5000.0, stock = 20)
        val item = CartItem(product = product, quantity = 3)
        assertEquals(15000.0, item.lineTotal, 0.01)
        assertEquals(6000.0, item.lineProfit, 0.01)
    }

    @Test
    fun userProfile_enforcesFreeVsPremiumAndAdminFlags() {
        val freeUser = UserProfile(userId = "u1", role = "USER", premiumStatus = "free")
        val premUser = UserProfile(userId = "u2", role = "USER", premiumStatus = "active", premiumType = "lifetime")
        val adminUser = UserProfile(userId = "a1", role = "ADMIN", premiumStatus = "free")

        assertFalse(freeUser.isPremiumActive)
        assertTrue(premUser.isPremiumActive)
        assertTrue(adminUser.isAdminRole)
        assertTrue(adminUser.isPremiumActive)
    }
}
