package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.core.QrCodeHelper
import com.example.core.ReceiptPrintHelper
import com.example.model.PosTransaction
import com.example.model.TransactionItem
import com.example.model.UserProfile
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read app name from context matches NEXORA POS`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("NEXORA POS", appName)
    }

    @Test
    fun `generateQrBitmap returns valid bitmap for product SKU`() {
        val bmp = QrCodeHelper.generateQrBitmap("NEXORA:PROD1:SKU-1001", 128)
        assertNotNull(bmp)
        assertEquals(128, bmp?.width)
        assertEquals(128, bmp?.height)
    }

    @Test
    fun `receipt builder formats store and total lines`() {
        val user = UserProfile(userId = "u1", name = "Kasir Andi", storeName = "Toko Maju")
        val tx = PosTransaction(id = "TX12345678", cashierName = "Kasir Andi", subtotal = 50000.0, total = 50000.0, paidAmount = 50000.0)
        val items = listOf(TransactionItem(id = "i1", productName = "Kopi Arabika", quantity = 2, unitPrice = 25000.0, lineTotal = 50000.0))
        val lines = ReceiptPrintHelper.buildReceiptLines(user, tx, items)
        assertTrue(lines.any { it.contains("TOKO MAJU") })
        assertTrue(lines.any { it.contains("Kopi Arabika") })
        assertTrue(lines.any { it.contains("50.000") })
    }
}
