"use strict";

const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { initializeApp, getApps } = require("firebase-admin/app");
const { getFirestore } = require("firebase-admin/firestore");
const {
  BOOTSTRAP_ADMIN_EMAIL,
  handleAskBusinessAi,
} = require("./askBusinessAiHandler");

if (getApps().length === 0) {
  initializeApp();
}

const db = getFirestore();

async function verifyNexoraAiAccess(auth) {
  const token = auth.token || {};
  const isBootstrapAdmin =
    token.email_verified === true &&
    typeof token.email === "string" &&
    token.email.toLowerCase() === BOOTSTRAP_ADMIN_EMAIL;

  const apiConfigSnap = await db.collection("api_settings").doc("public_config").get();
  if (apiConfigSnap.exists && apiConfigSnap.data()?.aiCsConfigured === false) {
    return {
      allowed: false,
      code: "failed-precondition",
      reason: "Layanan AI Customer Service sedang dinonaktifkan sementara oleh Admin.",
    };
  }

  if (isBootstrapAdmin) {
    return { allowed: true };
  }

  const adminSnap = await db.collection("admins").doc(auth.uid).get();
  if (adminSnap.exists) {
    return { allowed: true };
  }

  const userSnap = await db.collection("users").doc(auth.uid).get();
  const userData = userSnap.exists ? userSnap.data() : null;
  if (
    userData &&
    (userData.role === "ADMIN" || userData.premiumStatus === "active") &&
    userData.accountStatus !== "disabled"
  ) {
    return { allowed: true };
  }

  return {
    allowed: false,
    code: "permission-denied",
    reason: "Layanan AI Customer Service Al hanya tersedia untuk pengguna Premium Lifetime atau Admin.",
  };
}

exports.askBusinessAI = onCall(
  {
    region: "us-central1",
    timeoutSeconds: 60,
    memory: "256MiB",
  },
  async (request) => {
    try {
      return await handleAskBusinessAi({
        auth: request.auth,
        data: request.data,
        checkAccess: verifyNexoraAiAccess,
      });
    } catch (err) {
      if (err instanceof HttpsError) {
        throw err;
      }
      if (err && typeof err.code === "string" && typeof err.message === "string") {
        throw new HttpsError(err.code, err.message);
      }
      throw new HttpsError(
        "internal",
        "Terjadi gangguan pada layanan AI Customer Service. Silakan coba beberapa saat lagi."
      );
    }
  }
);
