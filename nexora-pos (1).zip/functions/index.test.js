"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const {
  NEXADEV_AI_ENDPOINT,
  buildNexaDevUrl,
  handleAskBusinessAi,
} = require("./askBusinessAiHandler");

const VALID_AUTH = {
  uid: "user_123",
  token: { email: "kasir@example.com", email_verified: true },
};

const ALLOW_ACCESS = async () => ({ allowed: true });

test("buildNexaDevUrl encodes question and embeds Al persona instructions", () => {
  const url = buildNexaDevUrl("Cara cetak struk 58mm?");
  assert.ok(url.startsWith(`${NEXADEV_AI_ENDPOINT}?q=`));
  assert.ok(!url.includes(" "), "URL must not contain unencoded spaces");
  const decoded = decodeURIComponent(url.split("?q=")[1]);
  assert.ok(decoded.includes("Al"));
  assert.ok(decoded.includes("NEXORA POS"));
  assert.ok(decoded.includes("Cara cetak struk 58mm?"));
});

test("rejects unauthenticated caller", async () => {
  await assert.rejects(
    () =>
      handleAskBusinessAi({
        auth: null,
        data: { question: "Halo Al" },
        checkAccess: ALLOW_ACCESS,
      }),
    (err) => err.code === "unauthenticated"
  );
});

test("rejects empty question", async () => {
  await assert.rejects(
    () =>
      handleAskBusinessAi({
        auth: VALID_AUTH,
        data: { question: "   " },
        checkAccess: ALLOW_ACCESS,
      }),
    (err) => err.code === "invalid-argument"
  );
});

test("rejects non-premium user when checkAccess denies", async () => {
  await assert.rejects(
    () =>
      handleAskBusinessAi({
        auth: VALID_AUTH,
        data: { question: "Halo" },
        checkAccess: async () => ({
          allowed: false,
          code: "permission-denied",
          reason: "Khusus Premium",
        }),
      }),
    (err) => err.code === "permission-denied"
  );
});

test("returns data.message when NexaDev returns status === true", async () => {
  let calledUrl = "";
  const mockFetch = async (url) => {
    calledUrl = url;
    return {
      ok: true,
      status: 200,
      text: async () =>
        JSON.stringify({
          author: "NexaDev",
          status: true,
          data: { message: "Halo! Untuk cetak struk 58mm, buka Riwayat Transaksi lalu tekan Cetak Struk." },
        }),
    };
  };

  const res = await handleAskBusinessAi({
    auth: VALID_AUTH,
    data: { question: "Cara cetak struk 58mm?" },
    checkAccess: ALLOW_ACCESS,
    fetchImpl: mockFetch,
  });

  assert.ok(calledUrl.startsWith(`${NEXADEV_AI_ENDPOINT}?q=`));
  assert.equal(res.status, true);
  assert.equal(res.author, "NexaDev");
  assert.ok(res.message.includes("58mm"));
});

test("rejects when status !== true", async () => {
  const mockFetch = async () => ({
    ok: true,
    status: 200,
    text: async () =>
      JSON.stringify({
        author: "NexaDev",
        status: false,
        data: { message: "Should be ignored" },
      }),
  });

  await assert.rejects(
    () =>
      handleAskBusinessAi({
        auth: VALID_AUTH,
        data: { question: "Tes" },
        checkAccess: ALLOW_ACCESS,
        fetchImpl: mockFetch,
      }),
    (err) => err.code === "unavailable"
  );
});

test("rejects invalid JSON response gracefully", async () => {
  const mockFetch = async () => ({
    ok: true,
    status: 200,
    text: async () => "<html>Bad Gateway</html>",
  });

  await assert.rejects(
    () =>
      handleAskBusinessAi({
        auth: VALID_AUTH,
        data: { question: "Tes" },
        checkAccess: ALLOW_ACCESS,
        fetchImpl: mockFetch,
      }),
    (err) => err.code === "internal"
  );
});

test("handles timeout / AbortError cleanly", async () => {
  const mockFetch = (_url, options) =>
    new Promise((_resolve, reject) => {
      options.signal.addEventListener("abort", () => {
        const abortErr = new Error("Aborted");
        abortErr.name = "AbortError";
        reject(abortErr);
      });
    });

  await assert.rejects(
    () =>
      handleAskBusinessAi({
        auth: VALID_AUTH,
        data: { question: "Tes timeout" },
        checkAccess: ALLOW_ACCESS,
        fetchImpl: mockFetch,
        timeoutMs: 20,
      }),
    (err) => err.code === "deadline-exceeded"
  );
});
