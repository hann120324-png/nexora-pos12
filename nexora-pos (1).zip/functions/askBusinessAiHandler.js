"use strict";

const NEXADEV_AI_ENDPOINT = "https://api.nexadev.my.id/ai/gpt4";
const BOOTSTRAP_ADMIN_EMAIL = "hptra112@gmail.com";
const MAX_QUESTION_LENGTH = 1500;
const DEFAULT_TIMEOUT_MS = 25000;

const AL_SYSTEM_CONTEXT = [
  "Kamu adalah Al, AI Customer Service resmi aplikasi NEXORA POS.",
  "Jawablah dalam bahasa Indonesia yang ramah, jelas, profesional, ringkas, dan mudah dipahami.",
  "Fokus bantuanmu meliputi: cara menggunakan kasir, cara menambah dan mengelola produk, cara scan barcode dan QR, cara mencetak struk 58mm, cara transaksi dan pembayaran, cara melihat laporan penjualan, serta perbedaan fitur Free dan Premium Lifetime NEXORA POS.",
  "PENTING: Kamu TIDAK memiliki akses langsung ke database, stok, atau data transaksi pengguna. Jangan pernah mengarang atau membuat jawaban palsu seolah-olah bisa membaca data transaksi atau database toko pengguna; jika ditanya tentang data pribadi atau transaksi toko mereka, jelaskan keterbatasannya dengan jujur dan arahkan ke menu Laporan atau Riwayat di aplikasi.",
].join(" ");

class AiFunctionError extends Error {
  constructor(code, message) {
    super(message);
    this.name = "AiFunctionError";
    this.code = code;
  }
}

function buildNexaDevUrl(question) {
  const fullPrompt = `${AL_SYSTEM_CONTEXT}\n\nPertanyaan pengguna: ${question}`;
  const encodedQuestion = encodeURIComponent(fullPrompt);
  return `${NEXADEV_AI_ENDPOINT}?q=${encodedQuestion}`;
}

async function handleAskBusinessAi({
  auth,
  data,
  checkAccess,
  fetchImpl = globalThis.fetch,
  timeoutMs = DEFAULT_TIMEOUT_MS,
}) {
  if (!auth || !auth.uid) {
    throw new AiFunctionError(
      "unauthenticated",
      "Silakan masuk terlebih dahulu untuk menggunakan layanan AI Customer Service."
    );
  }

  const rawQuestion = data && typeof data.question === "string" ? data.question : "";
  const cleanQuestion = rawQuestion.trim();

  if (!cleanQuestion) {
    throw new AiFunctionError(
      "invalid-argument",
      "Pertanyaan tidak boleh kosong. Silakan tulis pertanyaan Anda."
    );
  }

  if (cleanQuestion.length > MAX_QUESTION_LENGTH) {
    throw new AiFunctionError(
      "invalid-argument",
      `Pertanyaan terlalu panjang (maksimal ${MAX_QUESTION_LENGTH} karakter).`
    );
  }

  if (typeof checkAccess === "function") {
    const access = await checkAccess(auth);
    if (!access.allowed) {
      throw new AiFunctionError(
        access.code || "permission-denied",
        access.reason || "Layanan AI Customer Service hanya tersedia untuk akun Premium Lifetime."
      );
    }
  }

  if (typeof fetchImpl !== "function") {
    throw new AiFunctionError(
      "internal",
      "Layanan jaringan backend belum tersedia."
    );
  }

  const targetUrl = buildNexaDevUrl(cleanQuestion);
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  let response;
  try {
    response = await fetchImpl(targetUrl, {
      method: "GET",
      headers: {
        Accept: "application/json",
      },
      signal: controller.signal,
    });
  } catch (err) {
    if (err && err.name === "AbortError") {
      throw new AiFunctionError(
        "deadline-exceeded",
        "Permintaan ke AI Customer Service melebihi batas waktu. Silakan coba lagi."
      );
    }
    throw new AiFunctionError(
      "unavailable",
      "Gagal menghubungi server AI Customer Service. Periksa koneksi dan coba beberapa saat lagi."
    );
  } finally {
    clearTimeout(timer);
  }

  if (!response || !response.ok) {
    const statusCode = response ? response.status : "unknown";
    throw new AiFunctionError(
      "unavailable",
      `Server AI sedang sibuk atau tidak merespons (HTTP ${statusCode}). Silakan coba lagi nanti.`
    );
  }

  let rawBody;
  try {
    rawBody = await response.text();
  } catch {
    throw new AiFunctionError(
      "internal",
      "Gagal membaca respons dari server AI. Silakan coba lagi."
    );
  }

  let parsed;
  try {
    parsed = JSON.parse(rawBody);
  } catch {
    throw new AiFunctionError(
      "internal",
      "Respons dari server AI tidak dalam format JSON yang valid. Silakan coba lagi."
    );
  }

  if (!parsed || parsed.status !== true) {
    throw new AiFunctionError(
      "unavailable",
      "Layanan AI belum dapat memproses pertanyaan Anda saat ini. Silakan coba lagi."
    );
  }

  const message =
    parsed.data && typeof parsed.data.message === "string"
      ? parsed.data.message.trim()
      : "";

  if (!message) {
    throw new AiFunctionError(
      "internal",
      "AI mengembalikan jawaban kosong. Silakan coba kirim ulang pertanyaan Anda."
    );
  }

  return {
    status: true,
    author: typeof parsed.author === "string" ? parsed.author : "NexaDev",
    message,
  };
}

module.exports = {
  NEXADEV_AI_ENDPOINT,
  BOOTSTRAP_ADMIN_EMAIL,
  MAX_QUESTION_LENGTH,
  AL_SYSTEM_CONTEXT,
  AiFunctionError,
  buildNexaDevUrl,
  handleAskBusinessAi,
};
